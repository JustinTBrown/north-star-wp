# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 8. October 2014 20:02 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 8. October 2014 20:02 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (1 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-09-25 20:16:33', '2014-09-25 20:16:33', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, 'post-trashed', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 8. October 2014 20:02 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 8. October 2014 20:02 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=503 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (158 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost:8888', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'home', 'http://localhost:8888', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogname', 'North Star Counselling', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'blogdescription', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'admin_email', 'cheryl@localhost:8888', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (33, 'active_plugins', 'a:3:{i:0;s:51:"all-in-one-wp-migration/all-in-one-wp-migration.php";i:1;s:39:"backup-with-restore/backupwordpress.php";i:2;s:36:"contact-form-7/wp-contact-form-7.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'gmt_offset', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'recently_edited', 'a:2:{i:0;s:85:"/Users/justinbrown/Documents/Code/wordpress/wp-content/themes/north-star-wp/style.css";i:2;s:0:"";}', 'no') ; 
INSERT INTO `wp_options` VALUES (41, 'template', 'north-star-wp', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'stylesheet', 'north-star-wp', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'db_version', '29630', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'blog_public', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'widget_text', 'a:3:{i:1;a:0:{}s:12:"_multiwidget";i:1;i:3;a:3:{s:5:"title";s:6:"hello?";s:4:"text";s:9:"test test";s:6:"filter";b:0;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'uninstall_plugins', 'a:1:{s:38:"simple-backup/simple-backup-loader.php";s:23:"simple_backup_uninstall";}', 'no') ; 
INSERT INTO `wp_options` VALUES (83, 'timezone_string', 'America/Edmonton', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'page_on_front', '13', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'initial_db_version', '29630', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'WPLANG', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:6:{i:0;s:12:"categories-2";i:1;s:10:"archives-2";i:2;s:17:"recent-comments-2";i:3;s:8:"search-2";i:4;s:14:"recent-posts-2";i:5;s:6:"meta-2";}s:15:"sidebar-widgets";a:0:{}s:14:"footer-widgets";a:1:{i:0;s:6:"text-3";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'cron', 'a:11:{i:1412756242;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1412767268;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1412767320;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1412773680;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1412786087;a:1:{s:12:"bup_cron_day";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1412796954;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1412801525;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1412810608;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1412830800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1413262800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (100, '_transient_random_seed', 'deb39014d5a2d9dc9833a95429da452a', 'yes') ; 
INSERT INTO `wp_options` VALUES (113, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (132, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:57:"https://downloads.wordpress.org/release/wordpress-4.0.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:57:"https://downloads.wordpress.org/release/wordpress-4.0.zip";s:10:"no_content";s:68:"https://downloads.wordpress.org/release/wordpress-4.0-no-content.zip";s:11:"new_bundled";s:69:"https://downloads.wordpress.org/release/wordpress-4.0-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"4.0";s:7:"version";s:3:"4.0";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1412730488;s:15:"version_checked";s:3:"4.0";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (134, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1412730489;s:7:"checked";a:1:{s:13:"north-star-wp";s:5:"5.4.3";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (137, '_transient_twentyfourteen_category_count', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (138, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1411678840;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (139, 'current_theme', 'FoundationPress', 'yes') ; 
INSERT INTO `wp_options` VALUES (140, 'theme_mods_north-star-wp', 'a:1:{i:0;b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (141, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (161, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (162, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (163, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (164, 'widget_nav_menu', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (216, 'recently_activated', 'a:2:{s:38:"simple-backup/simple-backup-loader.php";i:1412613587;s:29:"ready-backup/backup-ready.php";i:1412613357;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (238, '_site_transient_timeout_browser_3a0daf6e042b28d4d8a48c4f87720f52', '1412792714', 'yes') ; 
INSERT INTO `wp_options` VALUES (239, '_site_transient_browser_3a0daf6e042b28d4d8a48c4f87720f52', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"37.0.2062.124";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (302, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (303, 'wpcf7', 'a:1:{s:7:"version";s:5:"3.9.3";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (323, 'ai1wm_messages', 'a:1:{s:17:"SiteURLDepricated";b:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (324, 'ai1wm_export_options', 'a:15:{s:7:"replace";a:2:{s:9:"old-value";a:1:{i:0;s:14:"localhost:8888";}s:9:"new-value";a:1:{i:0;s:23:"northstarcounselling.ca";}}s:6:"action";s:6:"export";s:14:"plugin_version";s:5:"2.0.2";s:10:"wp_version";s:3:"4.0";s:11:"php_version";s:6:"5.5.14";s:9:"php_uname";s:143:"Darwin Justins-MacBook-Air.local 13.4.0 Darwin Kernel Version 13.4.0: Sun Aug 17 19:50:11 PDT 2014; root:xnu-2422.115.4~1/RELEASE_X86_64 x86_64";s:18:"max_execution_time";s:1:"0";s:12:"memory_limit";s:4:"128M";s:21:"memory_get_peak_usage";i:15408336;s:16:"memory_get_usage";i:15360616;s:10:"ZipArchive";i:1;s:14:"ZLIB_installed";i:1;s:13:"PDO_available";i:1;s:8:"site_url";s:21:"http://localhost:8888";s:8:"home_url";s:21:"http://localhost:8888";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (325, 'ai1wm_maintenance_mode', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (326, 'ai1wm_error_handler', 'a:11:{i:0;a:5:{s:4:"code";i:2;s:7:"message";s:20:"mkdir(): File exists";s:4:"file";s:152:"/Users/justinbrown/Documents/Code/wordpress/wp-content/plugins/all-in-one-wp-migration/lib/vendor/storage-factory/storage-factory/lib/StorageUtility.php";s:4:"line";i:103;s:4:"time";i:1412709356;}i:1;a:5:{s:4:"code";i:2;s:7:"message";s:20:"mkdir(): File exists";s:4:"file";s:152:"/Users/justinbrown/Documents/Code/wordpress/wp-content/plugins/all-in-one-wp-migration/lib/vendor/storage-factory/storage-factory/lib/StorageUtility.php";s:4:"line";i:103;s:4:"time";i:1412709357;}i:2;a:5:{s:4:"code";i:2;s:7:"message";s:20:"mkdir(): File exists";s:4:"file";s:152:"/Users/justinbrown/Documents/Code/wordpress/wp-content/plugins/all-in-one-wp-migration/lib/vendor/storage-factory/storage-factory/lib/StorageUtility.php";s:4:"line";i:103;s:4:"time";i:1412709357;}i:3;a:5:{s:4:"code";i:2;s:7:"message";s:179:"copy(/Users/justinbrown/Documents/Code/wordpress/wp-content/themes/north-star-wp/node_modules/node-sass/node_modules/.bin/_mocha): failed to open stream: No such file or directory";s:4:"file";s:152:"/Users/justinbrown/Documents/Code/wordpress/wp-content/plugins/all-in-one-wp-migration/lib/vendor/storage-factory/storage-factory/lib/StorageUtility.php";s:4:"line";i:105;s:4:"time";i:1412709357;}i:4;a:5:{s:4:"code";i:2;s:7:"message";s:178:"copy(/Users/justinbrown/Documents/Code/wordpress/wp-content/themes/north-star-wp/node_modules/node-sass/node_modules/.bin/mocha): failed to open stream: No such file or directory";s:4:"file";s:152:"/Users/justinbrown/Documents/Code/wordpress/wp-content/plugins/all-in-one-wp-migration/lib/vendor/storage-factory/storage-factory/lib/StorageUtility.php";s:4:"line";i:105;s:4:"time";i:1412709357;}i:5;a:5:{s:4:"code";i:2;s:7:"message";s:20:"mkdir(): File exists";s:4:"file";s:152:"/Users/justinbrown/Documents/Code/wordpress/wp-content/plugins/all-in-one-wp-migration/lib/vendor/storage-factory/storage-factory/lib/StorageUtility.php";s:4:"line";i:103;s:4:"time";i:1412709357;}i:6;a:5:{s:4:"code";i:2;s:7:"message";s:20:"mkdir(): File exists";s:4:"file";s:152:"/Users/justinbrown/Documents/Code/wordpress/wp-content/plugins/all-in-one-wp-migration/lib/vendor/storage-factory/storage-factory/lib/StorageUtility.php";s:4:"line";i:103;s:4:"time";i:1412709357;}i:7;a:5:{s:4:"code";i:2;s:7:"message";s:20:"mkdir(): File exists";s:4:"file";s:152:"/Users/justinbrown/Documents/Code/wordpress/wp-content/plugins/all-in-one-wp-migration/lib/vendor/storage-factory/storage-factory/lib/StorageUtility.php";s:4:"line";i:103;s:4:"time";i:1412709357;}i:8;a:5:{s:4:"code";i:2;s:7:"message";s:196:"copy(/Users/justinbrown/Documents/Code/wordpress/wp-content/themes/north-star-wp/node_modules/node-sass/node_modules/mocha/node_modules/.bin/jade): failed to open stream: No such file or directory";s:4:"file";s:152:"/Users/justinbrown/Documents/Code/wordpress/wp-content/plugins/all-in-one-wp-migration/lib/vendor/storage-factory/storage-factory/lib/StorageUtility.php";s:4:"line";i:105;s:4:"time";i:1412709357;}i:9;a:5:{s:4:"code";i:8;s:7:"message";s:60:"ob_end_clean(): failed to delete buffer. No buffer to delete";s:4:"file";s:135:"/Users/justinbrown/Documents/Code/wordpress/wp-content/plugins/all-in-one-wp-migration/lib/controller/class-ai1wm-export-controller.php";s:4:"line";i:74;s:4:"time";i:1412723053;}i:10;a:5:{s:4:"code";i:8;s:7:"message";s:60:"ob_end_clean(): failed to delete buffer. No buffer to delete";s:4:"file";s:135:"/Users/justinbrown/Documents/Code/wordpress/wp-content/plugins/all-in-one-wp-migration/lib/controller/class-ai1wm-export-controller.php";s:4:"line";i:74;s:4:"time";i:1412730462;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (388, 'gd_system_first_login', '1412551408', 'yes') ; 
INSERT INTO `wp_options` VALUES (395, '_site_transient_timeout_browser_50c54d33e06cc624f76168787f95f678', '1413157518', 'yes') ; 
INSERT INTO `wp_options` VALUES (396, '_site_transient_browser_50c54d33e06cc624f76168787f95f678', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"37.0.2062.124";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (397, 'gd_system_first_publish', '1412552758', 'yes') ; 
INSERT INTO `wp_options` VALUES (398, 'gd_system_last_cache_flush', '1412707180', 'yes') ; 
INSERT INTO `wp_options` VALUES (425, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1412623940', 'yes') ; 
INSERT INTO `wp_options` VALUES (426, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"4690";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2907";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2823";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"2344";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2238";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1804";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1619";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1591";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1569";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1533";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1496";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1485";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1403";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1236";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1183";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1133";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:4:"1081";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:4:"1027";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:4:"1018";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"849";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"844";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"838";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"806";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"798";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"747";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"710";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"709";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"673";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"663";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"631";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"626";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"623";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"619";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"613";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"600";}s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";s:3:"572";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"564";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"561";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"554";}s:5:"share";a:3:{s:4:"name";s:5:"Share";s:4:"slug";s:5:"share";s:5:"count";s:3:"553";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (432, 'bup_re_used', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (439, '_site_transient_timeout_gd_system_blacklist', '1412613749', 'yes') ; 
INSERT INTO `wp_options` VALUES (440, '_site_transient_gd_system_blacklist', 'a:45:{i:0;a:8:{s:2:"id";i:1;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:56:"https://api.servicemanager.godaddy.com/v1/blacklistapi/1";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:7:"adminer";s:13:"threatLevelId";i:1;}i:1;a:8:{s:2:"id";i:4;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:56:"https://api.servicemanager.godaddy.com/v1/blacklistapi/4";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:15:"backupwordpress";s:13:"threatLevelId";i:1;}i:2;a:8:{s:2:"id";i:5;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:56:"https://api.servicemanager.godaddy.com/v1/blacklistapi/5";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:8:"backwpup";s:13:"threatLevelId";i:1;}i:3;a:8:{s:2:"id";i:6;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:56:"https://api.servicemanager.godaddy.com/v1/blacklistapi/6";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:19:"broken-link-checker";s:13:"threatLevelId";i:1;}i:4;a:8:{s:2:"id";i:7;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:56:"https://api.servicemanager.godaddy.com/v1/blacklistapi/7";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:24:"contextual-related-posts";s:13:"threatLevelId";i:1;}i:5;a:8:{s:2:"id";i:9;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:56:"https://api.servicemanager.godaddy.com/v1/blacklistapi/9";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:21:"ezpz-one-click-backup";s:13:"threatLevelId";i:1;}i:6;a:8:{s:2:"id";i:11;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/11";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:17:"fuzzy-seo-booster";s:13:"threatLevelId";i:1;}i:7;a:8:{s:2:"id";i:12;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/12";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:3:"3.9";s:10:"minVersion";s:3:"0.0";s:4:"name";s:24:"google-sitemap-generator";s:13:"threatLevelId";i:1;}i:8;a:8:{s:2:"id";i:13;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/13";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:42:"google-xml-sitemaps-with-multisite-support";s:13:"threatLevelId";i:1;}i:9;a:8:{s:2:"id";i:17;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/17";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:11:"jr-referrer";s:13:"threatLevelId";i:1;}i:10;a:8:{s:2:"id";i:22;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/22";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:19:"portable-phpmyadmin";s:13:"threatLevelId";i:1;}i:11;a:8:{s:2:"id";i:23;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/23";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:11:"quick-cache";s:13:"threatLevelId";i:1;}i:12;a:8:{s:2:"id";i:24;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/24";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:8:"seo-alrp";s:13:"threatLevelId";i:1;}i:13;a:8:{s:2:"id";i:25;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/25";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:13:"similar-posts";s:13:"threatLevelId";i:1;}i:14;a:8:{s:2:"id";i:28;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/28";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:19:"the-codetree-backup";s:13:"threatLevelId";i:1;}i:15;a:8:{s:2:"id";i:29;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/29";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:9:"toolspack";s:13:"threatLevelId";i:1;}i:16;a:8:{s:2:"id";i:31;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/31";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:14:"w3-total-cache";s:13:"threatLevelId";i:1;}i:17;a:8:{s:2:"id";i:32;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/32";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:26:"wordpress-gzip-compression";s:13:"threatLevelId";i:1;}i:18;a:8:{s:2:"id";i:33;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/33";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:8:"wp-cache";s:13:"threatLevelId";i:1;}i:19;a:8:{s:2:"id";i:37;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/37";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:18:"wp-engine-snapshot";s:13:"threatLevelId";i:1;}i:20;a:8:{s:2:"id";i:38;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/38";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:13:"wp-file-cache";s:13:"threatLevelId";i:1;}i:21;a:8:{s:2:"id";i:41;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/41";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:13:"wp-phpmyadmin";s:13:"threatLevelId";i:1;}i:22;a:8:{s:2:"id";i:42;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/42";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:12:"wp-postviews";s:13:"threatLevelId";i:1;}i:23;a:8:{s:2:"id";i:43;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/43";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:11:"wp-slimstat";s:13:"threatLevelId";i:1;}i:24;a:8:{s:2:"id";i:44;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/44";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:14:"wp-super-cache";s:13:"threatLevelId";i:1;}i:25;a:8:{s:2:"id";i:45;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/45";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:14:"wponlinebackup";s:13:"threatLevelId";i:1;}i:26;a:8:{s:2:"id";i:46;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/46";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:33:"yet-another-featured-posts-plugin";s:13:"threatLevelId";i:1;}i:27;a:8:{s:2:"id";i:47;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/47";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:32:"yet-another-related-posts-plugin";s:13:"threatLevelId";i:1;}i:28;a:8:{s:2:"id";i:48;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/48";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:12:"sgcachepress";s:13:"threatLevelId";i:1;}i:29;a:8:{s:2:"id";i:49;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/49";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:9:"synthesis";s:13:"threatLevelId";i:1;}i:30;a:8:{s:2:"id";i:50;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/50";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:15:"wpengine-common";s:13:"threatLevelId";i:1;}i:31;a:8:{s:2:"id";i:51;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/51";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:16:"6scan-protection";s:13:"threatLevelId";i:1;}i:32;a:8:{s:2:"id";i:52;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/52";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:12:"6scan-backup";s:13:"threatLevelId";i:1;}i:33;a:8:{s:2:"id";i:53;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/53";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:9:"statpress";s:13:"threatLevelId";i:1;}i:34;a:8:{s:2:"id";i:54;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/54";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:13:"wp-fast-cache";s:13:"threatLevelId";i:1;}i:35;a:8:{s:2:"id";i:55;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/55";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:16:"wp-fastest-cache";s:13:"threatLevelId";i:1;}i:36;a:8:{s:2:"id";i:56;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/56";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:11:"wp-cachecom";s:13:"threatLevelId";i:1;}i:37;a:8:{s:2:"id";i:57;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/57";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:11:"referrer-wp";s:13:"threatLevelId";i:1;}i:38;a:8:{s:2:"id";i:58;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/58";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:30:"adsense-click-fraud-monitoring";s:13:"threatLevelId";i:1;}i:39;a:8:{s:2:"id";i:59;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/59";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:21:"wordpress-beta-tester";s:13:"threatLevelId";i:1;}i:40;a:8:{s:2:"id";i:60;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/60";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:15:"wp-copysafe-web";s:13:"threatLevelId";i:1;}i:41;a:8:{s:2:"id";i:61;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/61";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:8:"999999.0";s:10:"minVersion";s:3:"0.0";s:4:"name";s:15:"wp-copysafe-pdf";s:13:"threatLevelId";i:1;}i:42;a:8:{s:2:"id";i:62;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/62";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:5:"2.6.7";s:10:"minVersion";s:3:"0.0";s:4:"name";s:18:"wysija-newsletters";s:13:"threatLevelId";i:1;}i:43;a:8:{s:2:"id";i:63;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/63";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:5:"3.4.2";s:10:"minVersion";s:3:"0.0";s:4:"name";s:7:"wptouch";s:13:"threatLevelId";i:1;}i:44;a:8:{s:2:"id";i:64;s:4:"type";s:9:"blacklist";s:5:"links";a:1:{s:4:"self";s:57:"https://api.servicemanager.godaddy.com/v1/blacklistapi/64";}s:11:"description";s:18:"Remove Immediately";s:10:"maxVersion";s:7:"5.1.0.3";s:10:"minVersion";s:3:"0.0";s:4:"name";s:20:"custom-contact-forms";s:13:"threatLevelId";i:1;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (450, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1412730489;s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:4:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.0.2";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.0.2.zip";}s:51:"all-in-one-wp-migration/all-in-one-wp-migration.php";O:8:"stdClass":6:{s:2:"id";s:5:"46859";s:4:"slug";s:23:"all-in-one-wp-migration";s:6:"plugin";s:51:"all-in-one-wp-migration/all-in-one-wp-migration.php";s:11:"new_version";s:5:"2.0.2";s:3:"url";s:54:"https://wordpress.org/plugins/all-in-one-wp-migration/";s:7:"package";s:72:"https://downloads.wordpress.org/plugin/all-in-one-wp-migration.2.0.2.zip";}s:36:"contact-form-7/wp-contact-form-7.php";O:8:"stdClass":6:{s:2:"id";s:3:"790";s:4:"slug";s:14:"contact-form-7";s:6:"plugin";s:36:"contact-form-7/wp-contact-form-7.php";s:11:"new_version";s:5:"3.9.3";s:3:"url";s:45:"https://wordpress.org/plugins/contact-form-7/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/contact-form-7.3.9.3.zip";}s:39:"backup-with-restore/backupwordpress.php";O:8:"stdClass":6:{s:2:"id";s:5:"47073";s:4:"slug";s:19:"backup-with-restore";s:6:"plugin";s:39:"backup-with-restore/backupwordpress.php";s:11:"new_version";s:3:"1.1";s:3:"url";s:50:"https://wordpress.org/plugins/backup-with-restore/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/backup-with-restore.zip";}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (451, 'hmbkp_dropbox_settings', 'a:2:{s:7:"enabled";s:2:"no";s:12:"access_token";N;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (452, 'hmbkp_default_path', '/Users/justinbrown/Documents/Code/wordpress/wp-content/uploads/backupwordpress-7c717d1b3f-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (453, 'hmbkp_path', '/Users/justinbrown/Documents/Code/wordpress/wp-content/uploads/backupwordpress-7c717d1b3f-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (454, 'hmbkp_schedule_default-1', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:11:"hmbkp_daily";s:11:"max_backups";i:30;s:19:"HMBKP_Email_Service";a:1:{s:5:"email";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (455, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (456, 'hmbkp_plugin_version', '1.1', 'yes') ; 
INSERT INTO `wp_options` VALUES (459, '_transient_timeout_hmbkp_schedule_default-1_filesize', '2825313816', 'no') ; 
INSERT INTO `wp_options` VALUES (460, '_transient_hmbkp_schedule_default-1_filesize', '177307399', 'no') ; 
INSERT INTO `wp_options` VALUES (467, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1412752309', 'no') ; 
INSERT INTO `wp_options` VALUES (468, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:26:"https://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 18 Sep 2014 16:20:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:42:"http://wordpress.org/?v=4.1-alpha-20141002";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 4.0 “Benny”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"https://wordpress.org/news/2014/09/benny/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"https://wordpress.org/news/2014/09/benny/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 04 Sep 2014 17:05:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3296";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:370:"Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleader Benny Goodman, is available for download or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we&#8217;ve put a little extra polish into it. This release brings you a smoother writing and management experience [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23566:"<p>Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleader <a href="http://en.wikipedia.org/wiki/Benny_Goodman">Benny Goodman</a>, is available <a href="https://wordpress.org/download/">for download</a> or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we&#8217;ve put a little extra polish into it. This release brings you a smoother writing and management experience we think you&#8217;ll enjoy.</p>
<div id="v-bUdzKMro-1" class="video-player"><embed id="v-bUdzKMro-1-video" src="https://v0.wordpress.com/player.swf?v=1.03&amp;guid=bUdzKMro&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" title="Introducing WordPress 4.0 &quot;Benny&quot;" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<hr />
<h2 style="text-align: center">Manage your media with style</h2>
<p><img class="alignnone size-full wp-image-3316" src="https://wordpress.org/news/files/2014/09/media.jpg" alt="Media Library" width="1000" height="586" />Explore your uploads in a beautiful, endless grid. A new details preview makes viewing and editing any amount of media in sequence a snap.</p>
<hr />
<h2 style="text-align: center">Working with embeds has never been easier</h2>
<div style="width: 632px; height: 445px; " class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3296-1" width="632" height="445" autoplay="true" preload="metadata" controls="controls"><source type="video/mp4" src="//s.w.org/images/core/4.0/embed.mp4?_=1" /><source type="video/webm" src="//s.w.org/images/core/4.0/embed.webm?_=1" /><source type="video/ogg" src="//s.w.org/images/core/4.0/embed.ogv?_=1" /><a href="//s.w.org/images/core/4.0/embed.mp4">//s.w.org/images/core/4.0/embed.mp4</a></video></div>
<p>Paste in a YouTube URL on a new line, and watch it magically become an embedded video. Now try it with a tweet. Oh yeah — embedding has become a visual experience. The editor shows a true preview of your embedded content, saving you time and giving you confidence.</p>
<p>We’ve expanded the services supported by default, too — you can embed videos from CollegeHumor, playlists from YouTube, and talks from TED. <a href="https://codex.wordpress.org/Embeds">Check out all of the embeds</a> that WordPress supports.</p>
<hr />
<h2 style="text-align: center">Focus on your content</h2>
<div style="width: 632px; height: 356px; " class="wp-video"><video class="wp-video-shortcode" id="video-3296-2" width="632" height="356" autoplay="true" preload="metadata" controls="controls"><source type="video/mp4" src="//s.w.org/images/core/4.0/focus.mp4?_=2" /><source type="video/webm" src="//s.w.org/images/core/4.0/focus.webm?_=2" /><source type="video/ogg" src="//s.w.org/images/core/4.0/focus.ogv?_=2" /><a href="//s.w.org/images/core/4.0/focus.mp4">//s.w.org/images/core/4.0/focus.mp4</a></video></div>
<p>Writing and editing is smoother and more immersive with an editor that expands to fit your content as you write, and keeps the formatting tools available at all times.</p>
<hr />
<h2 style="text-align: center">Finding the right plugin</h2>
<p><img class="aligncenter size-large wp-image-3309" src="https://wordpress.org/news/files/2014/09/add-plugin1-1024x600.png" alt="Add plugins" width="692" height="405" /></p>
<p>There are more than 30,000 free and open source plugins in the WordPress plugin directory. WordPress 4.0 makes it easier to find the right one for your needs, with new metrics, improved search, and a more visual browsing experience.</p>
<hr />
<h2 style="text-align: center">The Ensemble</h2>
<p>This release was led by <a href="http://helenhousandi.com">Helen Hou-Sandí</a>, with the help of these fine individuals. There are 275 contributors with props in this release, a new high. Pull up some Benny Goodman on your music service of choice, as a bandleader or in one of his turns as a classical clarinetist, and check out some of their profiles:</p>
<p><a href="https://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="https://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="https://profiles.wordpress.org/alexanderrohmann">Alexander Rohmann</a>, <a href="https://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="https://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="https://profiles.wordpress.org/amit">Amit Gupta</a>, <a href="https://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/andrezrv">Andres Villarreal</a>, <a href="https://profiles.wordpress.org/zamfeer">Andrew Mowe</a>, <a href="https://profiles.wordpress.org/sumobi">Andrew Munro (sumobi)</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="https://profiles.wordpress.org/ankit-k-gupta">Ankit K Gupta</a>, <a href="https://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="https://profiles.wordpress.org/arnee">arnee</a>, <a href="https://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="https://profiles.wordpress.org/filosofo">Austin Matzko</a>, <a href="https://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="https://profiles.wordpress.org/kau-boy">Bernhard Kau</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="https://profiles.wordpress.org/bramd">bramd</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/brianlayman">Brian Layman</a>, <a href="https://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="https://profiles.wordpress.org/camdensegal">Camden Segal</a>, <a href="https://profiles.wordpress.org/sixhours">Caroline Moore</a>, <a href="https://profiles.wordpress.org/mackensen">Charles Fulton</a>, <a href="https://profiles.wordpress.org/chouby">Chouby</a>, <a href="https://profiles.wordpress.org/chrico">ChriCo</a>, <a href="https://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="https://profiles.wordpress.org/chrisl27">chrisl27</a>, <a href="https://profiles.wordpress.org/caxelsson">Christian Axelsson</a>, <a href="https://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="https://profiles.wordpress.org/boda1982">Christopher Spires</a>, <a href="https://profiles.wordpress.org/clifgriffin">Clifton Griffin</a>, <a href="https://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="https://profiles.wordpress.org/corphi">Corphi</a>, <a href="https://profiles.wordpress.org/extendwings">Daisuke Takahashi</a>, <a href="https://profiles.wordpress.org/ghost1227">Dan Griffiths</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/danielhuesken">Daniel Husken</a>, <a href="https://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="https://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="https://profiles.wordpress.org/dkotter">Darin Kotter</a>, <a href="https://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="https://profiles.wordpress.org/dllh">Daryl L. L. Houston (dllh)</a>, <a href="https://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="https://profiles.wordpress.org/dlh">David Herrera</a>, <a href="https://profiles.wordpress.org/dnaber-de">David Naber</a>, <a href="https://profiles.wordpress.org/davidthemachine">DavidTheMachine</a>, <a href="https://profiles.wordpress.org/debaat">DeBAAT</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/donncha">Donncha O Caoimh</a>, <a href="https://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/dustyn">Dustyn Doyle</a>, <a href="https://profiles.wordpress.org/eddiemoya">Eddie Moya</a>, <a href="https://profiles.wordpress.org/oso96_2000">Eduardo Reveles</a>, <a href="https://profiles.wordpress.org/edwin-at-studiojoyocom">Edwin Siebel</a>, <a href="https://profiles.wordpress.org/ehg">ehg</a>, <a href="https://profiles.wordpress.org/tmeister">Enrique Chavez</a>, <a href="https://profiles.wordpress.org/erayalakese">erayalakese</a>, <a href="https://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="https://profiles.wordpress.org/ebinnion">Eric Binnion</a>, <a href="https://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="https://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="https://profiles.wordpress.org/eherman24">Evan Herman</a>, <a href="https://profiles.wordpress.org/fab1en">Fab1en</a>, <a href="https://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="https://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="https://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="https://profiles.wordpress.org/garhdez">garhdez</a>, <a href="https://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="https://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/garza">garza</a>, <a href="https://profiles.wordpress.org/gauravmittal1995">gauravmittal1995</a>, <a href="https://profiles.wordpress.org/gavra">Gavrisimo</a>, <a href="https://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="https://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="https://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="https://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="https://profiles.wordpress.org/bordoni">Gustavo Bordoni</a>, <a href="https://profiles.wordpress.org/harrym">harrym</a>, <a href="https://profiles.wordpress.org/hebbet">hebbet</a>, <a href="https://profiles.wordpress.org/hinnerk">Hinnerk Altenburg</a>, <a href="https://profiles.wordpress.org/hlashbrooke">Hugh Lashbrooke</a>, <a href="https://profiles.wordpress.org/iljoja">iljoja</a>, <a href="https://profiles.wordpress.org/imath">imath</a>, <a href="https://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="https://profiles.wordpress.org/issuu">issuu</a>, <a href="https://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="https://profiles.wordpress.org/jacklenox">Jack Lenox</a>, <a href="https://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="https://profiles.wordpress.org/jacobdubail">Jacob Dubail</a>, <a href="https://profiles.wordpress.org/janhenkg">JanHenkG</a>, <a href="https://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="https://profiles.wordpress.org/jwenerd">Jared Wenerd</a>, <a href="https://profiles.wordpress.org/jaza613">Jaza613</a>, <a href="https://profiles.wordpress.org/jeffstieler">Jeff Stieler</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jpry">Jeremy Pry</a>, <a href="https://profiles.wordpress.org/slimndap">Jeroen Schmit</a>, <a href="https://profiles.wordpress.org/jerrysarcastic">Jerry Bates (jerrysarcastic)</a>, <a href="https://profiles.wordpress.org/jesin">Jesin A</a>, <a href="https://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="https://profiles.wordpress.org/engelen">Jesper van Engelen</a>, <a href="https://profiles.wordpress.org/jesper800">Jesper van Engelen</a>, <a href="https://profiles.wordpress.org/jessepollak">Jesse Pollak</a>, <a href="https://profiles.wordpress.org/jgadbois">jgadbois</a>, <a href="https://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="https://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="https://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="https://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="https://profiles.wordpress.org/johnzanussi">John Zanussi</a>, <a href="https://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="https://profiles.wordpress.org/jonnyauk">jonnyauk</a>, <a href="https://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="https://profiles.wordpress.org/softmodeling">Jordi Cabot</a>, <a href="https://profiles.wordpress.org/jjeaton">Josh Eaton</a>, <a href="https://profiles.wordpress.org/tai">JOTAKI Taisuke</a>, <a href="https://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="https://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="https://profiles.wordpress.org/jtsternberg">Justin Sternberg</a>, <a href="https://profiles.wordpress.org/greenshady">Justin Tadlock</a>, <a href="https://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="https://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="https://profiles.wordpress.org/ixkaito">Kaito</a>, <a href="https://profiles.wordpress.org/kapeels">kapeels</a>, <a href="https://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="https://profiles.wordpress.org/kevinlangleyjr">Kevin Langley</a>, <a href="https://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="https://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="https://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="https://profiles.wordpress.org/kitchin">kitchin</a>, <a href="https://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="https://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/krogsgard">krogsgard</a>, <a href="https://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="https://profiles.wordpress.org/lessbloat">lessbloat</a>, <a href="https://profiles.wordpress.org/layotte">Lew Ayotte</a>, <a href="https://profiles.wordpress.org/lritter">lritter</a>, <a href="https://profiles.wordpress.org/lukecarbis">Luke Carbis</a>, <a href="https://profiles.wordpress.org/lgedeon">Luke Gedeon</a>, <a href="https://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="https://profiles.wordpress.org/funkatronic">Manny Fleurmond</a>, <a href="https://profiles.wordpress.org/targz-1">Manuel Schmalstieg</a>, <a href="https://profiles.wordpress.org/clorith">Marius (Clorith)</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="https://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="https://profiles.wordpress.org/sivel">Matt Martz</a>, <a href="https://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="https://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="https://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="https://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="https://profiles.wordpress.org/mattheweppelsheimer">Matthew Eppelsheimer</a>, <a href="https://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="https://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="https://profiles.wordpress.org/meekyhwang">meekyhwang</a>, <a href="https://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="https://profiles.wordpress.org/midxcat">mi_cat</a>, <a href="https://profiles.wordpress.org/mdawaffe">Michael Adams (mdawaffe)</a>, <a href="https://profiles.wordpress.org/michalzuber">michalzuber</a>, <a href="https://profiles.wordpress.org/mauteri">Mike Auteri</a>, <a href="https://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="https://profiles.wordpress.org/mikejolley">Mike Jolley</a>, <a href="https://profiles.wordpress.org/mikelittle">Mike Little</a>, <a href="https://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="https://profiles.wordpress.org/mnelson4">Mike Nelson</a>, <a href="https://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="https://profiles.wordpress.org/mikeyarce">Mikey Arce</a>, <a href="https://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="https://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="https://profiles.wordpress.org/usermrpapa">Mr Papa</a>, <a href="https://profiles.wordpress.org/mrmist">mrmist</a>, <a href="https://profiles.wordpress.org/m_uysl">Mustafa Uysal</a>, <a href="https://profiles.wordpress.org/muvimotv">MuViMoTV</a>, <a href="https://profiles.wordpress.org/nabil_kadimi">nabil_kadimi</a>, <a href="https://profiles.wordpress.org/namibia">Namibia</a>, <a href="https://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="https://profiles.wordpress.org/nd987">nd987</a>, <a href="https://profiles.wordpress.org/neil_pie">Neil Pie</a>, <a href="https://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/schoenwaldnils">Nils Schonwald</a>, <a href="https://profiles.wordpress.org/ninos-ego">Ninos</a>, <a href="https://profiles.wordpress.org/nvwd">Nowell VanHoesen</a>, <a href="https://profiles.wordpress.org/compute">Patrick Hesselberg</a>, <a href="https://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="https://profiles.wordpress.org/pdclark">Paul Clark</a>, <a href="https://profiles.wordpress.org/paulschreiber">Paul Schreiber</a>, <a href="https://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="https://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="https://profiles.wordpress.org/philipjohn">Philip John</a>, <a href="https://profiles.wordpress.org/senlin">Piet</a>, <a href="https://profiles.wordpress.org/psoluch">Piotr Soluch</a>, <a href="https://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="https://profiles.wordpress.org/purzlbaum">purzlbaum</a>, <a href="https://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="https://profiles.wordpress.org/rclations">RC Lations</a>, <a href="https://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="https://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="https://profiles.wordpress.org/rob1n">rob1n</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="https://profiles.wordpress.org/harmr">RobertHarm</a>, <a href="https://profiles.wordpress.org/rohan013">Rohan Rawat</a>, <a href="https://profiles.wordpress.org/rhurling">Rouven Hurling</a>, <a href="https://profiles.wordpress.org/ruudjoyo">Ruud Laan</a>, <a href="https://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="https://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="https://profiles.wordpress.org/sammybeats">Sam Brodie</a>, <a href="https://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="https://profiles.wordpress.org/sathishn">Sathish Nagarajan</a>, <a href="https://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="https://profiles.wordpress.org/scribu">scribu</a>, <a href="https://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="https://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="https://profiles.wordpress.org/sergejmueller">Sergej Muller</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/shanebp">shanebp</a>, <a href="https://profiles.wordpress.org/sharonaustin">Sharon Austin</a>, <a href="https://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="https://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="https://profiles.wordpress.org/simonp303">simonp303</a>, <a href="https://profiles.wordpress.org/slobodanmanic">Slobodan Manic</a>, <a href="https://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="https://profiles.wordpress.org/sphoid">sphoid</a>, <a href="https://profiles.wordpress.org/stephdau">Stephane Daury</a>, <a href="https://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="https://profiles.wordpress.org/stompweb">Steven Jones</a>, <a href="https://profiles.wordpress.org/strangerstudios">strangerstudios</a>, <a href="https://profiles.wordpress.org/5um17">Sumit Singh</a>, <a href="https://profiles.wordpress.org/t4k1s">t4k1s</a>, <a href="https://profiles.wordpress.org/iamtakashi">Takashi Irie</a>, <a href="https://profiles.wordpress.org/taylorde">Taylor Dewey</a>, <a href="https://profiles.wordpress.org/thomasvanderbeek">Thomas van der Beek</a>, <a href="https://profiles.wordpress.org/tillkruess">Till Kruss</a>, <a href="https://profiles.wordpress.org/codenameeli">Tim \'Eli\' Dalbey</a>, <a href="https://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="https://profiles.wordpress.org/tjnowell">Tom J Nowell</a>, <a href="https://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="https://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="https://profiles.wordpress.org/torresga">torresga</a>, <a href="https://profiles.wordpress.org/liljimmi">Tracy Levesque</a>, <a href="https://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="https://profiles.wordpress.org/treyhunner">treyhunner</a>, <a href="https://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="https://profiles.wordpress.org/vinod-dalvi">Vinod Dalvi</a>, <a href="https://profiles.wordpress.org/vlajos">vlajos</a>, <a href="https://profiles.wordpress.org/voldemortensen">voldemortensen</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="https://profiles.wordpress.org/winterdev">winterDev</a>, <a href="https://profiles.wordpress.org/wojtekszkutnik">Wojtek Szkutnik</a>, <a href="https://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="https://profiles.wordpress.org/katzwebdesign">Zack Katz</a>, <a href="https://profiles.wordpress.org/tollmanz">Zack Tollman</a>, and <a href="https://profiles.wordpress.org/zoerooney">Zoe Rooney</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video, and Helen with <a href="http://adriansandi.com">Adrián Sandí</a> for the music.</p>
<p>If you want to follow along or help out, check out <a href="https://make.wordpress.org/">Make WordPress</a> and our <a href="https://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.1!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/news/2014/09/benny/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 4.0 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"https://wordpress.org/news/2014/08/wordpress-4-0-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:76:"https://wordpress.org/news/2014/08/wordpress-4-0-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Aug 2014 12:20:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3287";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:321:"The first release candidate for WordPress 4.0 is now available! In RC 1, we’ve made refinements to what we&#8217;ve been working on for this release. Check out the Beta 1 announcement post for more details on those features. We hope to ship WordPress 4.0 next week, but we need your help to get there. If you [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2134:"<p>The first release candidate for WordPress 4.0 is now available!</p>
<p>In RC 1, we’ve made refinements to what we&#8217;ve been working on for this release. Check out the <a href="https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">Beta 1 announcement post</a> for more details on those features. We hope to ship WordPress 4.0 <em>next week</em>, but we need your help to get there. If you haven’t tested 4.0 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="https://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="https://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>To test WordPress 4.0 RC1, try the <a href="https://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 4.0, visit the awesome About screen in your dashboard (<strong><img src="https://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar).</p>
<p><strong>Developers,</strong> please test your plugins and themes against WordPress 4.0 and update your plugin&#8217;s <em>Tested up to</em> version in the readme to 4.0 before next week. If you find compatibility problems, please be sure to post any issues to the support forums so we can figure those out before the final release. You also may want to <a href="https://make.wordpress.org/core/2014/08/21/introducing-plugin-icons-in-the-plugin-installer/">give your plugin an icon</a>, which we launched last week and will appear in the dashboard along with banners.</p>
<p><em>It is almost time</em><br />
<em> For the 4.0 release</em><br />
<em> And its awesomeness</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:72:"https://wordpress.org/news/2014/08/wordpress-4-0-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/08/wordpress-4-0-beta-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2014/08/wordpress-4-0-beta-4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 05:06:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3280";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:353:"The fourth and likely final beta for WordPress 4.0 is now available. We&#8217;ve made more than 250 changes in the past month, including: Further improvements to the editor scrolling experience, especially when it comes to the second column of boxes. Better handling of small screens in the media library modals. A separate bulk selection mode [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2003:"<p>The fourth and likely final beta for WordPress 4.0 is now available. We&#8217;ve made <a href="https://core.trac.wordpress.org/log?rev=29496&amp;stop_rev=29229&amp;limit=300">more than 250 changes</a> in the past month, including:</p>
<ul>
<li>Further improvements to the editor scrolling experience, especially when it comes to the second column of boxes.</li>
<li>Better handling of small screens in the media library modals.</li>
<li>A separate bulk selection mode for the media library grid view.</li>
<li>Improvements to the installation language selector.</li>
<li>Visual tweaks to plugin details and customizer panels.</li>
</ul>
<p><strong>We need your help</strong>. We’re still aiming for a release this month, which means the next week will be critical for identifying and squashing bugs. If you’re just joining us, please see <a href="https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven’t tested WordPress 4.0 yet, now is the time — and be sure to update the “tested up to” version for your plugins so they’re listed as compatible with 4.0.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="https://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta4.zip">download the beta here</a> (zip).</p>
<p><em>We are working hard</em><br />
<em>To finish up 4.0<br />
</em><em>Will you help us too?</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2014/08/wordpress-4-0-beta-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.9.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2014/08/wordpress-3-9-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2014/08/wordpress-3-9-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Aug 2014 19:04:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3269";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:377:"WordPress 3.9.2 is now available as a security release for all previous versions. We strongly encourage you to update your sites immediately. This release fixes a possible denial of service issue in PHP&#8217;s XML processing, reported by Nir Goldshlager of the Salesforce.com Product Security Team. It  was fixed by Michael Adams and Andrew Nacin of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2353:"<p>WordPress 3.9.2 is now available as a security release for all previous versions. We strongly encourage you to update your sites immediately.</p>
<p>This release fixes a possible denial of service issue in PHP&#8217;s XML processing, reported by <a href="https://twitter.com/nirgoldshlager">Nir Goldshlager</a> of the Salesforce.com Product Security Team. It  was fixed by Michael Adams and Andrew Nacin of the WordPress security team and David Rothstein of the <a href="https://www.drupal.org/SA-CORE-2014-004">Drupal security team</a>. This is the first time our two projects have coordinated joint security releases.</p>
<p>WordPress 3.9.2 also contains other security changes:</p>
<ul>
<li>Fixes a possible but unlikely code execution when processing widgets (WordPress is not affected by default), discovered by <a href="http://www.buayacorp.com/">Alex Concha</a> of the WordPress security team.</li>
<li>Prevents information disclosure via XML entity attacks in the external GetID3 library, reported by <a href="http://onsec.ru/en/">Ivan Novikov</a> of ONSec.</li>
<li>Adds protections against brute attacks against CSRF tokens, reported by <a href="http://systemoverlord.com/">David Tomaschik</a> of the Google Security Team.</li>
<li>Contains some additional security hardening, like preventing cross-site scripting that could be triggered only by administrators.</li>
</ul>
<p>We appreciated responsible disclosure of these issues directly to our security team. For more information, see the <a href="https://codex.wordpress.org/Version_3.9.2">release notes</a> or consult the <a href="https://core.trac.wordpress.org/log/branches/3.9?stop_rev=29383&amp;rev=29411">list of changes</a>.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 3.9.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now&#8221;.</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.9.2 within 12 hours. (If you are still on WordPress 3.8.3 or 3.7.3, you will also be updated to 3.8.4 or 3.7.4. We don&#8217;t support older versions, so please update to 3.9.2 for the latest and greatest.)</p>
<p>Already testing WordPress 4.0? The third beta is <a href="https://wordpress.org/wordpress-4.0-beta3.zip">now available</a> (zip) and it contains these security fixes.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/08/wordpress-3-9-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Jul 2014 21:15:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3261";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:374:"WordPress 4.0 Beta 2 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. To get the beta, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can download the beta here (zip). For more of what’s new in version 4.0, check out [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1745:"<p>WordPress 4.0 Beta 2 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. To get the beta, try the <a href="https://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta2.zip">download the beta here</a> (zip).</p>
<p>For more of what’s new in version 4.0, <a href="https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">check out the Beta 1 blog post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Further refinements for the the plugin installation and media library experiences.</li>
<li>Updated TinyMCE, which now includes better indentation for lists and the restoration of the color picker.</li>
<li>Cookies are now tied to a session internally, so if you have trouble logging in, <a href="https://core.trac.wordpress.org/ticket/20276">#20276</a> may be the culprit.</li>
<li>Various bug fixes (there were <a href="https://core.trac.wordpress.org/log?rev=29228&amp;stop_rev=29060&amp;limit=200">nearly 170 changes</a> since last week).</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="https://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.0">everything we’ve fixed</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 10:17:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3248";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"WordPress 4.0 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4031:"<p>WordPress 4.0 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta1.zip">download the beta here</a> (zip).</p>
<p>4.0 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Previews of <a href="https://codex.wordpress.org/Embeds">embedding via URLs</a></strong> in the visual editor and the &#8220;Insert from URL&#8221; tab in the media modal. Try pasting a URL (such as a <a href="http://wordpress.tv/">WordPress.tv</a> or YouTube video) onto its own line in the visual editor. (<a href="https://core.trac.wordpress.org/ticket/28195">#28195</a>, <a href="https://core.trac.wordpress.org/ticket/15490">#15490</a>)</li>
<li>The <strong>Media Library</strong> now has a &#8220;grid&#8221; view in addition to the existing list view. Clicking on an item takes you into a modal where you can see a larger preview and edit information about that attachment, and you can navigate between items right from the modal without closing it. (<a href="https://core.trac.wordpress.org/ticket/24716">#24716</a>)</li>
<li>We&#8217;re freshening up the <strong>plugin install experience</strong>. You&#8217;ll see some early visual changes as well as more information when searching for plugins and viewing details. (<a href="https://core.trac.wordpress.org/ticket/28785">#28785</a>, <a href="https://core.trac.wordpress.org/ticket/27440">#27440</a>)</li>
<li><strong>Selecting a language</strong> when you run the installation process. (<a href="https://core.trac.wordpress.org/ticket/28577">#28577</a>)</li>
<li>The <strong>editor</strong> intelligently resizes and its top and bottom bars pin when needed. Browsers don&#8217;t like to agree on where to put things like cursors, so if you find a bug here, please also let us know your browser and operating system. (<a href="https://core.trac.wordpress.org/ticket/28328">#28328</a>)</li>
<li>We&#8217;ve made some improvements to how your keyboard and cursor interact with <strong>TinyMCE views</strong> such as the gallery preview. Much like the editor resizing and scrolling improvements, knowing about your setup is particularly important for bug reports here. (<a href="https://core.trac.wordpress.org/ticket/28595">#28595</a>)</li>
<li><strong>Widgets in the Customizer</strong> are now loaded in a separate panel. (<a href="https://core.trac.wordpress.org/ticket/27406">#27406</a>)</li>
<li>We&#8217;ve also made some changes to some <strong>formatting</strong> functions, so if you see quotes curling in the wrong direction, please file a bug report.</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.0">everything we’ve fixed</a> so far.</p>
<p><strong>Developers:</strong> Never fear, we haven&#8217;t forgotten you. There&#8217;s plenty for you, too &#8211; more on that in upcoming posts. In the meantime, check out the <a href="https://make.wordpress.org/core/2014/07/08/customizer-improvements-in-4-0/#customizer-panels">API for panels in the Customizer</a>.</p>
<p>Happy testing!</p>
<p><em>Plugins, editor</em><br />
<em>Media, things in between</em><br />
<em>Please help look for bugs</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.9.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2014/05/wordpress-3-9-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2014/05/wordpress-3-9-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3241";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:385:"After three weeks and more than 9 million downloads of WordPress 3.9, we&#8217;re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3106:"<p>After three weeks and more than 9 million downloads of <a title="WordPress 3.9 “Smith”" href="https://wordpress.org/news/2014/04/smith/">WordPress 3.9</a>, we&#8217;re pleased to announce that WordPress 3.9.1 is now available.</p>
<p>This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video playlists feature and made some adjustments to improve performance. For a full list of changes, consult the <a href="https://core.trac.wordpress.org/query?milestone=3.9.1">list of tickets</a> and the <a href="https://core.trac.wordpress.org/log/branches/3.9?rev=28353&amp;stop_rev=28154">changelog</a>.</p>
<p>If you are one of the millions already running WordPress 3.9, we&#8217;ve started rolling out automatic background updates for 3.9.1. For sites <a href="https://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 3.9.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.9.1: <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="https://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="https://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="https://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="https://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="https://profiles.wordpress.org/imath">imath</a>, <a href="https://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="https://profiles.wordpress.org/clorith">Marius Jensen</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/dimadin">Milan Dinić</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, and <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/05/wordpress-3-9-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"https://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"https://wordpress.org/news/2014/04/smith/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:411:"Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23206:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="https://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>

<h2 class="about-headline-callout" style="text-align: center">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="//wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3170" src="//wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3187" src="//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="//wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2 style="text-align: center">Do more with audio and video</h2>

<a href=\'https://wordpress.org/news/files/2014/04/AintMisbehavin.mp3\'>Ain\'t Misbehavin\'</a>
<a href=\'https://wordpress.org/news/files/2014/04/DavenportBlues.mp3\'>Davenport Blues</a>
<a href=\'https://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3\'>Buddy Bolden\'s Blues</a>
<a href=\'https://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3\'>Squaty Roo</a>
<a href=\'https://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3\'>Dixie Blues</a>
<a href=\'https://wordpress.org/news/files/2014/04/WolverineBlues.mp3\'>Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2 style="text-align: center">Live widget and header previews</h2>
<div style="width: 692px; height: 448px; " class="wp-video"><video class="wp-video-shortcode" id="video-3154-3" width="692" height="448" preload="metadata" controls="controls"><source type="video/mp4" src="//wordpress.org/news/files/2014/04/widgets.mp4?_=3" /><a href="//wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></video></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2 style="text-align: center">Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="//wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2 style="text-align: center">The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="https://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/adelval">adelval</a>, <a href="https://profiles.wordpress.org/ajay">Ajay</a>, <a href="https://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="https://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="https://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="https://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="https://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="https://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="https://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="https://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="https://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="https://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="https://profiles.wordpress.org/barry">Barry</a>, <a href="https://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="https://profiles.wordpress.org/bassgang">bassgang</a>, <a href="https://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="https://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="https://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="https://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="https://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="https://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="https://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="https://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="https://profiles.wordpress.org/bramd">bramd</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="https://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="https://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="https://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="https://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="https://profiles.wordpress.org/chouby">Chouby</a>, <a href="https://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="https://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="https://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="https://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="https://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="https://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="https://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="https://profiles.wordpress.org/ciantic">ciantic</a>, <a href="https://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="https://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="https://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="https://profiles.wordpress.org/corphi">Corphi</a>, <a href="https://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="https://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="https://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="https://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="https://profiles.wordpress.org/dpe415">DaveE</a>, <a href="https://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="https://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="https://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="https://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="https://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="https://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="https://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="https://profiles.wordpress.org/plocha">edik</a>, <a href="https://profiles.wordpress.org/oso96_2000">Eduardo Reveles</a>, <a href="https://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="https://profiles.wordpress.org/enej">enej</a>, <a href="https://profiles.wordpress.org/ericlewis">Eric Lewis</a>, <a href="https://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="https://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="https://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="https://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="https://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="https://profiles.wordpress.org/fboender">fboender</a>, <a href="https://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="https://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="https://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/genkisan">genkisan</a>, <a href="https://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="https://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="https://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="https://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="https://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="https://profiles.wordpress.org/tivnet">Gregory Karpinsky (@tivnet)</a>, <a href="https://profiles.wordpress.org/hakre">hakre</a>, <a href="https://profiles.wordpress.org/hanni">hanni</a>, <a href="https://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="https://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="https://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="https://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="https://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="https://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="https://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="https://profiles.wordpress.org/janrenn">janrenn</a>, <a href="https://profiles.wordpress.org/jaycc">JayCC</a>, <a href="https://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="https://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jesin">Jesin A</a>, <a href="https://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="https://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="https://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="https://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="https://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="https://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="https://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="https://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="https://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="https://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="https://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="https://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="https://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="https://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="https://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="https://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="https://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="https://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="https://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="https://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="https://profiles.wordpress.org/kerikae">kerikae</a>, <a href="https://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="https://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="https://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="https://profiles.wordpress.org/kitchin">kitchin</a>, <a href="https://profiles.wordpress.org/klihelp">klihelp</a>, <a href="https://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="https://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/ldebrouwer">ldebrouwer</a>, <a href="https://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="https://profiles.wordpress.org/lpointet">lpointet</a>, <a href="https://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="https://profiles.wordpress.org/lkwdwrd">Luke Woodward</a>, <a href="https://profiles.wordpress.org/nofearinc">Mario Peshev</a>, <a href="https://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="https://profiles.wordpress.org/marventus">Marventus</a>, <a href="https://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="https://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="https://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="https://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="https://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="https://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="https://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="https://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="https://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="https://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="https://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="https://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="https://profiles.wordpress.org/meloniq">meloniq</a>, <a href="https://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="https://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="https://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="https://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="https://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="https://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="https://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="https://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="https://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="https://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="https://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="https://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="https://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="https://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="https://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="https://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="https://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="https://profiles.wordpress.org/nivijah">Nivi Jah</a>, <a href="https://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="https://profiles.wordpress.org/olivm">olivM</a>, <a href="https://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="https://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="https://profiles.wordpress.org/patricknami">patricknami</a>, <a href="https://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="https://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="https://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="https://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="https://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="https://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="https://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="https://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="https://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="https://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="https://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="https://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="https://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="https://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="https://profiles.wordpress.org/richard2222">Richard</a>, <a href="https://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="https://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="https://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/robmiller">robmiller</a>, <a href="https://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="https://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="https://profiles.wordpress.org/roothorick">roothorick</a>, <a href="https://profiles.wordpress.org/ruudjoyo">Ruud Laan</a>, <a href="https://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="https://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="https://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="https://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="https://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="https://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="https://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="https://profiles.wordpress.org/scribu">scribu</a>, <a href="https://profiles.wordpress.org/sdasse">sdasse</a>, <a href="https://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="https://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="https://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="https://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="https://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="https://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="https://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="https://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="https://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="https://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="https://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="https://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="https://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="https://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="https://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="https://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="https://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="https://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="https://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="https://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="https://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="https://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="https://profiles.wordpress.org/tbrams">tbrams</a>, <a href="https://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="https://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="https://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="https://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="https://profiles.wordpress.org/topquarky">topquarky</a>, <a href="https://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="https://profiles.wordpress.org/toru">Toru Miki</a>, <a href="https://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="https://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="https://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="https://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="https://profiles.wordpress.org/wawco">wawco</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="https://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="https://profiles.wordpress.org/xsonic">xsonic</a>, <a href="https://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="https://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="https://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="https://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="https://make.wordpress.org/">Make WordPress</a> and our <a href="https://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/news/2014/04/smith/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.9 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"https://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"https://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 09:47:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3151";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:356:"The second release candidate for WordPress 3.9 is now available for testing. If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the first release candidate, and those changes are all helpfully summarized in our weekly post on the development blog. Probably the biggest fixes are to live [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2273:"<p>The second release candidate for WordPress 3.9 is now available for testing.</p>
<p>If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the <a title="WordPress 3.9 Release Candidate" href="//wordpress.org/news/2014/04/wordpress-3-9-release-candidate/">first release candidate</a>, and those changes are all helpfully summarized <a href="//make.wordpress.org/core/?p=10237">in our weekly post</a> on the development blog. Probably the biggest fixes are to live widget previews and the new theme browser, along with some extra TinyMCE compatibility and some RTL fixes.</p>
<p><strong>Plugin authors:</strong> Could you test your plugins against 3.9, and if they&#8217;re compatible, make sure they are marked as tested up to 3.9? It only takes a few minutes and this really helps make launch easier. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example: <a href="//make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5</a>, <a href="//make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">symlinks</a>, <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL</a>, <a href="//make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload</a>.)</p>
<p>To test WordPress 3.9 RC2, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC2.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the nearly complete About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><em>This is for testing,</em><br />
<em>so not recommended for<br />
production sites—yet.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:74:"https://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.3 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2014/04/wordpress-3-8-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2014/04/wordpress-3-8-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 19:29:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3145";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"WordPress 3.8.3 is now available to fix a small but unfortunate bug in the WordPress 3.8.2 security release. The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2341:"<p>WordPress 3.8.3 is now available to fix a small but unfortunate bug in the <a title="WordPress 3.8.2 Security Release" href="https://wordpress.org/news/2014/04/wordpress-3-8-2/">WordPress 3.8.2 security release</a>.</p>
<p>The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using this tool, <em>any</em> loss of content is unacceptable to us.</p>
<p>We recognize how much trust you place in us to safeguard your content, and we take this responsibility very seriously. We&#8217;re sorry we let you down.</p>
<p>We&#8217;ve all lost words we&#8217;ve written before, like an email thanks to a cat on the keyboard or a term paper to a blue screen of death. Over the last few WordPress releases, we&#8217;ve made a number of improvements to features like autosaves and revisions. With revisions, an old edit can always be restored. We&#8217;re trying our hardest to save your content somewhere even if your power goes out or your browser crashes. We even monitor your internet connection and prevent you from hitting that &#8220;Publish&#8221; button at the exact moment the coffee shop Wi-Fi has a hiccup.</p>
<p>It&#8217;s <em>possible</em> that the quick draft you lost last week is still in the database, and just hidden from view. As an added complication, these &#8220;discarded drafts&#8221; normally get deleted after seven days, and it&#8217;s already been six days since the release. If we were able to rescue your draft, you&#8217;ll see it on the &#8220;All Posts&#8221; screen after you update to 3.8.3. (We&#8217;ll also be pushing 3.8.3 out as a background update, so you may just see a draft appear.)</p>
<p>So, if you tried to jot down a quick idea last week, I hope WordPress has recovered it for you. Maybe it&#8217;ll turn into that novella.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 3.8.3</a> or click &#8220;Update Now&#8221; on Dashboard → Updates.</p>
<p><em>This affected version 3.7.2 as well, so we&#8217;re pushing a 3.7.3 to these installs, but we&#8217;d encourage you to update to the latest and greatest.</em></p>
<hr />
<p><em>Now for some good news:<br />
WordPress 3.9 is near.<br />
Expect it this week</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/04/wordpress-3-8-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:32:"https://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Tue, 07 Oct 2014 19:11:49 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:37:"https://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 18 Sep 2014 16:20:10 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911040210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (469, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1412752309', 'no') ; 
INSERT INTO `wp_options` VALUES (470, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1412709109', 'no') ; 
INSERT INTO `wp_options` VALUES (471, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1412752309', 'no') ; 
INSERT INTO `wp_options` VALUES (472, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Matt: Tavern Interview";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44238";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://ma.tt/2014/10/tavern-interview/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:276:"<p>Sarah Gooding of the WordPress inside baseball blog <a href="http://wptavern.com/">WP Tavern</a> has an interview with me she titled <a href="http://wptavern.com/matt-mullenweg-on-ensuring-the-future-of-wordpress">Matt Mullenweg on Ensuring the Future of WordPress</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 07 Oct 2014 13:55:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"Post Status: Is WordPress right for eCommerce?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=7165";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"http://www.poststat.us/wordpress-right-ecommerce/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:11868:"<p><img class="aligncenter size-large wp-image-7170" src="http://www.poststat.us/wp-content/uploads/2014/10/wordpress-ecommerce-discussion-752x352.jpg" alt="wordpress-ecommerce-discussion" width="627" height="293" /></p>
<p>I&#8217;m going to take a leaf out of <a href="http://www.chrislema.com/">Chris Lema&#8217;s</a> book right now to answer whether WordPress should be used for eCommerce: <strong>It depends</strong>.</p>
<p>There are camps of thought that think WordPress isn&#8217;t right for eCommerce, and there are people that think it&#8217;s the only way to go. Having worked with and used several different eCommerce platforms (both hosted and self-hosted), I&#8217;ve definitely developed the mindset that there are use cases for each. WordPress can be the right choice in a lot of circumstances, but not all.</p>
<h3>Hosted vs. self-hosted</h3>
<p>If you&#8217;re not sure about the major differences between hosted vs self hosted platforms, I recommend reading <em>Patrick Rauland&#8217;s</em> <a href="http://speakinginbytes.com/2014/08/hosted-vs-self-hosted-e-commerce/">overview of the major differences</a>. WordPress eCommerce usually falls under self-hosted eCommerce (I don&#8217;t count WordPress.com since it uses external eCommerce solutions). Forbes also <a href="http://www.forbes.com/sites/allbusiness/2014/09/26/which-e-commerce-platform-is-the-best-choice-for-your-online-store/">recently wrote about this</a>, though I don&#8217;t necessarily agree with their conclusions.</p>
<p>The <a href="http://www.practicalecommerce.com/articles/70101-When-to-Avoid-WordPress-Ecommerce">typical viewpoint</a> is that WordPress plugins like WooCommerce or Easy Digital Downloads are great for small stores or people that just want to quickly and easily sell a few items, while hosted platforms like Shopify and Bigcommerce are for &#8220;serious&#8221; stores.</p>
<p>This viewpoint is actually pretty backwards, not to mention the fact that the number of items is a poor way of determining which platform you should use.</p>
<h3 id="give-each-its-due">Give each its due</h3>
<p>Is WordPress the best platform on which to build apps? I don&#8217;t always think so, but it <strong>could be</strong>. Is it always a good choice for eCommerce? Nope. However, it&#8217;s the <strong>right one</strong> for lots of stores, and it&#8217;s the <strong>wrong one</strong> for lots of stores.</p>
<p>There are a few major strengths and weaknesses of both WordPress and hosted solutions. I&#8217;ve worked most with <a href="http://www.woothemes.com/woocommerce/">WooCommerce</a>, <a href="http://easydigitaldownloads.com/">Easy Digital Downloads</a>, and <a href="http://www.shopify.com/">Shopify</a>, but have tried lots of other eCommerce solutions for comparison. Some of the knocks against WordPress aren&#8217;t valid, but we should note that some are.</p>
<h3>WordPress eCommerce weaknesses</h3>
<p>Everyone loves to talk about how easy certain WordPress plugins are to use. When you compare WordPress plugins to something like Shopify, this just <strong>isn&#8217;t true</strong>. They may be easy to use for people that are familiar with WordPress, but not for the average user who wants to start selling online with no experience.</p>
<p>WordPress requires a domain name purchase, hosting setup, installation, plugin installation and setup, theme installation and setup, blah blah blah, you get the drift. With hosted solutions, you don&#8217;t worry about this (though solutions like <a href="http://evermo.re/">Evermore</a> &#8212; which was <a title="Evermore, hosted WordPress with power and ease of use" href="http://www.poststat.us/evermore-interview/">covered by Post Status</a> when it launched &#8212; make this interesting). You pay your monthly bill, and you&#8217;re handed a store website &#8211; you just pick the name and get rolling. You can start adding products right away, and then you might get into changing your theme or other setup.<span id="more-7165"></span></p>
<div id="attachment_7167" class="wp-caption alignright"><img class="wp-image-7167 size-medium" src="http://www.poststat.us/wp-content/uploads/2014/10/easy-300x258.jpg" alt="easy" width="300" height="258" /><p class="wp-caption-text"><a href="https://c2.staticflickr.com/4/3181/3086827283_e9e762331c.jpg">Image Credit</a></p></div>
<p>Some of the site tweaks or setup with hosted solutions aren&#8217;t easy, but the learning curve for a solution like Shopify is far gentler than the learning curve for something like WooCommerce.</p>
<p>There are also <strong>WP Cron</strong> issues for some sites, as it&#8217;s not a perfect system for scheduling actions, like recurring payments. It can work pretty well, but other platforms can make this far easier to implement and more reliable than Cron.</p>
<p>WordPress store owners are also <strong>responsible</strong> for their own hosting, software updates, and security. For many site owners, these are huge responsibilities. Hosted solutions roll all of this into their package so that users don&#8217;t have to know how their website is powered. They just have to use it.</p>
<p>Both WordPress and hosted solutions will scale, but there are considerations with WordPress that users need to be aware of. Database issues (like backups or memory with massive amounts of customers and orders) should be addressed, hosting has to be optimized, and plugins need to scale with the site. With a hosted solution, none of this is your problem as a user.</p>
<h3>WordPress eCommerce strengths</h3>
<p>Bearing these weaknesses in mind, it&#8217;s a bit crazy to me that WordPress is sometimes referred to as the &#8220;easy solution&#8221; or the right tool for &#8220;small stores&#8221;. It&#8217;s not. In many cases, it&#8217;s like bringing a tank to the eCommerce playground.</p>
<p>So what does WordPress do well?</p>
<p>First, WordPress offers the most all-in-one website solution available. WordPress can offer the eCommerce aspects of the website, in addition to its many other CMS features. The ability to create a single, seamless CMS experience for a multi-purpose website makes it quite compelling and more budget-friendly than more &#8220;eCommerce first&#8221; platforms.</p>
<p>Second, it&#8217;s optimized for <strong>SEO</strong>. Your content is crucial here, and WordPress is built for content. More importantly, if you&#8217;ve tried to blog on another platform, you know how painful it can be (don&#8217;t start with me Squarespace fans, that thing is difficult to use). WordPress doesn&#8217;t encourage you to avoid blogging to avoid headache: it&#8217;s built for <strong>complete websites</strong>, and is not simply focused on eCommerce.</p>
<p>WordPress also contains functionality that you can&#8217;t always get with different platforms. There&#8217;s a massive selection of plugins, themes, and all sorts of solutions for WordPress that are readily available. Since it&#8217;s open source, it&#8217;s far easier to find ways to customize it when compared to closed platforms like Bigcommerce.</p>
<p>Speaking of customizations, your ability to customize WordPress or plugins is <strong>far</strong> easier than with hosted solutions. There&#8217;s lots of functionality that can be achieved with WordPress that&#8217;s not even possible in hosted solutions. For example, developers have no control over the Shopify checkout process, but this can be entirely customized with WordPress.</p>
<p>You can also usually find a plugin that will provide a &#8220;starting point&#8221; for a customization project. Even if you find a Shopify or Bigcommerce app that gets <em>close</em> to what you need, but not quite, you&#8217;ll need to create a completely custom solution anyway &#8211; there&#8217;s no &#8220;extending&#8221; there.</p>
<p>Along with customization is the <strong>control over your environment</strong>. You can spin up your eCommerce site on something like Digital Ocean, and you&#8217;ve got control over the entire site, from server to theme.</p>
<h3>Product type</h3>
<p>The biggest difference for me between hosted solutions and self-hosted actually isn&#8217;t usability or scalability &#8211; it&#8217;s <strong>product type</strong>. Can almost every eCommerce platform sell tee shirts? Yes. Even EDD can do that, and it&#8217;s made for digital products.</p>
<p>However, selling complex products becomes infinitely more difficult on hosted platforms, as you&#8217;re restricted to what the API offers for product changes, which isn&#8217;t always a lot. For example, if you&#8217;ve ever tried to add pricing changes for customization options in Shopify, you know that it literally takes some wizardry, black magic, and possibly bubble gum used as tape to do so.</p>
<p>WordPress plugins make this far easier, because the entire platform is open, not just an API. Most eCommerce plugins have more than enough actions or filters to change products, product pages, checkout forms, or any other part of your site.</p>
<h3>Recap</h3>
<p>Hosted eCommerce solutions are typically easy to use, and can provide some customization options via apps or other add-on services. However, it&#8217;s like renting a house versus owning. With a rented house, you can&#8217;t go knocking down walls or completely remodeling &#8211; you&#8217;ve got to work inside of a framework you&#8217;re given. This is exactly how a hosted solution works.</p>
<p>The benefit to this is that you absolve yourself of a lot of responsibility and worry. The entire experience is managed and supported, and is typically very easy to work with.</p>
<p>However, WordPress eCommerce is like buying the house. You can do whatever you want &#8211; add-on, rebuild sections of the house, change layouts around, add tunnels to other houses, you name it. However, when the water heater blows up, it&#8217;s your responsibility.</p>
<p>WordPress also affords the opportunity to sell complex products, such as measurement based products like corks by the pound, that simply can&#8217;t be sold on other platforms. The same ability to customize WordPress so thoroughly lets you customize the eCommerce plugin you&#8217;re using.</p>
<p>You gain the flexibility that comes with the platform, as well as the benefits like tons of plugins, themes, a great content structure, and a consistently maintained and updated core solution. However, the Frankenstein site that you build is your baby, and yours alone &#8211; you need to host it, maintain it, and care for it.</p>
<p>WordPress lets you create advanced functionality via plugins and customizations, but isn&#8217;t right for users looking for an easy, basic shop setup. If you want a move-in ready house or a beautiful rental, you should look at hosted solutions. If you&#8217;re willing to make your dream house from great bones and foundation, or you need to sell fairly complex products, then WordPress might be it for you. It&#8217;s not the &#8220;easy&#8221; solution, but it can be a great one.</p>
<div id="single-hcard-beka" class="loop-meta vcard"><h4 class="author-bio fn n">Beka Rice</h4><div class="author-description"><img alt="Beka Rice" src="http://1.gravatar.com/avatar/5ea957b08d0cf6a1e5e5cf5681519537?s=150&d=http%3A%2F%2F1.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D150&r=G" class="avatar avatar-150 photo" height="150" width="150" /><div class="user-bio author-bio">Beka is the content manager for <a href="http://skyverge.com">SkyVerge</a>, where she writes sales copy, documentation, and website content. She also runs <a href="http://sellwithwp.com">Sell with WP</a>, which is a site devoted to eCommerce using WordPress. When she’s not furiously writing, she’s playing music or leveling up her movie trivia knowledge.</div><!-- .user-bio .author-bio --></div><!-- .loop-description --></div><!-- .loop-meta -->";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 06 Oct 2014 19:03:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Beka Rice";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Matt: Gambino Mixtape STN MTN";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44227";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://ma.tt/2014/10/gambino-mixtape-stn-mtn/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:640:"<p>The ever-creative <a href="http://childishgambino.com/">Childish Gambino</a> has released a <a href="http://stonemounta.in/">new mixtape STN MTN</a> (<a href="http://www.hotnewhiphop.com/childish-gambino-stn-mtn-new-mixtape.115505.html">track by track</a>) which is part of a longer EP Kauai <a href="https://itunes.apple.com/us/album/kauai/id925162758">that was just released on iTunes</a>. Donald is a friend and an artist whose work fluently spans much more than music. And I&#8217;m not just saying that because, as Techcrunch noted, he shouts out to <a href="http://krutal.wordpress.com/">Krutal</a> and I at the end of Go DJ.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 06 Oct 2014 15:49:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:38:"Jen Mylo: Site Setup Journal: Prologue";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://jenmylo.com/?p=4558";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://jenmylo.com/2014/10/05/site-setup-journal-prologue/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2998:"<p>I think that most of the people involved in creating software for the web have completely forgotten what it&#8217;s like to navigate these waters, and that &#8220;our setup is so simple!&#8221; statements are in general full of crap. Over the next few days, I am going to try to set up up a website on a domain I own using <em><strong>only</strong></em> the documentation and support available to the average person (who doesn&#8217;t have access to lead developers and heads of support teams). Is this decision predicated by the fact that none of those people were around when I tried pinging them today at 6am? Well, yes, yes it is. But given the frustration level I have encountered in the first 2 hours alone, I am glad they&#8217;re not around right now. I&#8217;ve been setting up websites since 1999, and I think we are making the process harder, not easier.</p>
<p>Get ready for some painful descriptions of just how janky all our product flows and documentation are. I know I&#8217;m wincing.</p>
<p>I&#8217;m thinking this will wind up being the equivalent of a play in 3 acts, but I could be wrong &#8212; it depends on how complicated things get.</p>
<h3><img class="aligncenter size-full wp-image-4560" src="http://jenmylo.files.wordpress.com/2014/10/screen-shot-2014-10-05-at-8-17-45-am.png?w=520&h=241" alt="Screen shot of unavailable webpage" width="520" height="241" /></h3>
<h3></h3>
<h3>Setting</h3>
<p>A quiet home in the Pacific Northwest featuring cable internet with advertised speeds of 25Mbps down/10Mbps up. A comfortable bed with pillows propped against the headboard, against which our main character lounges at the opening of Act I, equipped with a MacBook Air circa 2010, an iPhone 5s, and a debit card.</p>
<h3>Cast of Characters</h3>
<p><strong>Jen Mylo:</strong> An average web user trying to set up a site for the first time.</p>
<p><strong>GoDaddy:</strong> The registrar holding the domain <em>[Ed. Note: Legacy registrar; I\'ll switch it to namecheap at some point before it\'s time to renew].</em></p>
<p><strong>Dreamhost:</strong> A web hosting company that Jen Mylo has loved forever and that employs one of her favorite people as their resident WP expert. They were hosting non-profits for free before it was cool.</p>
<p><strong>WordPress:</strong> An open source content management system you can use to run a website. Claims a famous 5-minute install, &#8220;well-known for its ease of installation.&#8221; Rumor has it this web app is made by a bunch of weirdos.</p>
<p><strong>BuddyPress: </strong>An open source WordPress plugin that creates a social network on your site. Also made by weirdos.</p>
<p><strong>Rivermark Community Credit Union:</strong> A community credit union in Portland, OR that likes to do everything online; where Jen Mylo keeps some of her money.</p>
<p>Stay tuned for Act I!</p><img alt="" border="0" src="http://pixel.wp.com/b.gif?host=jenmylo.com&blog=45389656&post=4558&subd=jenmylo&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 05 Oct 2014 15:20:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"Jen Mylo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Matt: All About that Bass";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44224";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://ma.tt/2014/10/all-about-that-bass/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:164:"<p>This catchy song has been making the rounds with my friends, see if you can listen and not move just a little bit:</p>
<p><span class="embed-youtube"></span></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 05 Oct 2014 13:03:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Matt: New Diane Foug Art";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44236";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://ma.tt/2014/10/new-diane-foug-art/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:563:"<p><a href="http://i2.wp.com/ma.tt/files/2014/10/IMG_2422.jpg"><img src="http://i2.wp.com/ma.tt/files/2014/10/IMG_2422.jpg?w=604" alt="IMG_2422.JPG" class="alignnone size-full" /></a></p>
<p><a href="http://i2.wp.com/ma.tt/files/2014/10/IMG_2421.jpg"><img src="http://i2.wp.com/ma.tt/files/2014/10/IMG_2421.jpg?w=604" alt="IMG_2421.JPG" class="alignnone size-full" /></a></p>
<p><a href="http://i1.wp.com/ma.tt/files/2014/10/IMG_2423.jpg"><img src="http://i1.wp.com/ma.tt/files/2014/10/IMG_2423.jpg?w=604" alt="IMG_2423.JPG" class="alignnone size-full" /></a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 05 Oct 2014 03:11:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Matt: Streak";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44229";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://ma.tt/2014/10/streak/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4597:"<p>You might have noticed there have been more posts around here lately. Actually until yesterday (Oct 3) there was an unbroken string of at least one post a day since August 25th, 40 posts in total. It started with a tweet from Colin Devroe:</p>
<blockquote class="twitter-tweet" width="550"><p>I challenge <a href="https://twitter.com/mds">@mds</a> <a href="https://twitter.com/Yarcom">@yarcom</a> <a href="https://twitter.com/kyleruane">@kyleruane</a> <a href="https://twitter.com/garyvee">@garyvee</a> <a href="https://twitter.com/stewart">@stewart</a> <a href="https://twitter.com/TechonomicMan">@TechonomicMan</a> <a href="https://twitter.com/geoffd">@geoffd</a> <a href="https://twitter.com/Clarko">@clarko</a> <a href="https://twitter.com/photomatt">@photomatt</a> to personal blogging every weekday for 30dys</p>
<p>&mdash; Colin Devroe (@cdevroe) <a href="https://twitter.com/cdevroe/status/504630581117063169">August 27, 2014</a></p></blockquote>
<p></p>
<p>Until now I forgot it was only weekdays, so I was doing weekends as well. Friends know I like doing personal experiments just to question assumptions or ingrained behavior, other examples this I&#8217;ve tried this year are giving up drinking for a month, going without a smartphone for 40 days, and more recently training for a half marathon with my friend Rene. I thought blogging every day would be a burden, but it actually became a great source of joy. It was more a shift in mindset than anything &#8212; every day I read things I think are interesting, share links with friends, have thoughts that are 80% of a blog post, and write a ton privately, it was just a matter of catching those moments and turning them into something that was shared with the world.</p>
<p>The tools besides WordPress that I found super-helpful in this were <a href="http://simplenote.com/">Simplenote</a>, which was great for capturing thoughts and drafts when I was on the go, and I&#8217;ve been using the <a href="https://wordpress.org/plugins/editorial-calendar/">Editorial Calendar</a> plugin to help me schedule drafts and keep an eye on my progress. The Editorial Calendar plugin is useful but I don&#8217;t love it &#8212; I wish the calendar view moved week by week rather than replacing the whole table, that it was responsive or worked on mobile, and that it would take over your publish button so you could define a desired posting cadence (in my case every 24 hours) and it would put a finished post in the next free slot, or let you bump something to the front of the queue and push all the other posts back a day. There were a few missteps along the way with timezones but overall I&#8217;m happy with how the experiment turned out.</p>
<p>So what broke the streak? It was actually one of the other experiments: running. I&#8217;ve never considered myself a runner, and never really done it in my life, but a few months ago I started trying it and have been training up for a half marathon on November 16. (<a href="http://ma.tt/2014/10/photo-run-through-stockholm/">It&#8217;s also a great opportunity to take photos</a>.) Yesterday morning I woke up early around 5 AM and as the sun started to come up, and the weather was so nice after <a href="https://cloudup.com/cCYGA3rqlvi">I rounded the Bay Bridge</a> (planned turnaround point) kept going to Crissy Field where <a href="https://cloudup.com/caWpo6oFQ0d">I saw the Golden Gate from afar</a> and thought it would be fun to cross it. <a href="http://matt.wordpress.com/2014/10/04/under-golden-gate/">After crossing</a> I was starving by and figured 3 more miles would be a half marathon and also put me in Sausalito. The last mile or two was really tough, definitely beyond what I was ready for and I walked a lot, but <a href="http://runkeeper.com/user/photomatt/activity/446743645?&activityList=false&tripIdBase36=7dz9lp&channel=web.activity.shorturl">I was very proud of the result</a>, finishing in around 2 hours 45 minutes. But I hadn&#8217;t planned to stay out that long, and the rest of my day was full of meetings. I had moved my scheduled post for the day out so I could talk about the new Childish Gambino mixtape (post coming tomorrow) but the rest of the day was so busy and I got exhausted so early I totally forgot to post.</p>
<p>So achieved one life goal while breaking the streak on another, which is not ideal, but today is another day and I want to see if I can break the 39 day streak next. Everything happens one day at a time. <img src="http://i1.wp.com/s.ma.tt/blog/wp-includes/images/smilies/icon_smile.gif?w=604" alt=":)" class="wp-smiley" /></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 04 Oct 2014 17:42:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"WPTavern: Contributing Back to WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31765";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wptavern.com/contributing-back-to-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8837:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/matt-mullenweg.jpg" rel="prettyphoto[31765]"><img class="size-full wp-image-31713" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/matt-mullenweg.jpg?resize=1024%2C522" alt="Photo by Vladimir Kaladan Petkov" /></a>Photo by Vladimir Kaladan Petkov
<p>During a session at <a title="http://2014.europe.wordcamp.org/" href="http://2014.europe.wordcamp.org/">WordCamp Europe</a>, Matt Mullenweg was asked how companies contribute back to WordPress, how they&#8217;re doing it, and what companies should do more of. He responded to the question in-depth in a blog post entitled <a title="http://ma.tt/2014/09/five-for-the-future/" href="http://ma.tt/2014/09/five-for-the-future/">Five for the Future</a>. In the post, he outlines 5% as being a good rule of thumb to avoid the <a title="http://en.wikipedia.org/wiki/Tragedy_of_the_commons" href="http://en.wikipedia.org/wiki/Tragedy_of_the_commons">tragedy of the commons</a>. The post ignited a healthy discussion throughout the WordPress community.</p>
<p>While his post is more about WordPress organizations, companies, and agencies and how they can grow their part of the pie and WordPress as a whole, I&#8217;m going to focus on individual contributions.</p>
<h2>What is a WordPress Contribution?</h2>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/ContributionBox.png" rel="prettyphoto[31765]"><img class="size-full wp-image-31791" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/ContributionBox.png?resize=640%2C213" alt="Contribution Box" /></a>photo credit: <a href="https://www.flickr.com/photos/chrstopher/341538188/">Chrstopher</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a>
<p>The definition of what classifies as a contribution to WordPress is subjective. In the broadest sense of the term, I define contribution as anything that furthers the WordPress project. I seperate contributions to WordPress into two groups, <strong>direct</strong> and <strong>indirect</strong>. Direct contributions are those that deal with the core of WordPress such as patches, leading a release, and commits. These have a direct impact on WordPress and the millions of people who use it.</p>
<p>Indirect contributions are those that further the project without using code. Examples include meetups, WordCamps, and tech support. These are what I think make up the vast majority of contributions to WordPress.</p>
<h2>Contributing to WordPress Without Realizing it</h2>
<p>As I thought about the 5% goal and whether or not I meet the criteria, I had an epiphany. <em>Thousands of people likely contribute to WordPress everyday without realizing it</em>.</p>
<ul>
<li>A friend emails you and needs WordPress support. You help fix their problem.</li>
<li>Someone needs a particular plugin to fulfill a need and you offer a suggestion that works.</li>
<li>You&#8217;re at a local meetup and help someone figure out how to use a particular feature in WordPress.</li>
</ul>
<p>All of the examples above are <strong>indirect</strong> ways of contributing to WordPress but are things millions of people do everyday. In these moments, users are helping each other while in the background, they&#8217;re contributing to WordPress. This is important because it means a lot of individuals are probably closer to the 5% goal than they might realize.</p>
<h2>The Impact of Contributions</h2>
<p>One of the first comments to Mullenweg&#8217;s article is a question <a title="http://ma.tt/2014/09/five-for-the-future/#comment-578864" href="http://ma.tt/2014/09/five-for-the-future/#comment-578864">asked by bftrick</a>, &#8220;I like the idea of having a full-time employee that works on WordPress core but I think I’d rather have everyone on board and contributing 5% of their time. What do you think about that?&#8221; Mullenweg&#8217;s response is as follows:</p>
<blockquote><p>Any percent that people can pitch in is fantastic! Some tasks divide into smaller pieces better than others, I’m sure over time you’ll find the balance that maximizes your impact. That actually brings up a good point, it’s good to look at what impact you’re having — I’ve seen companies dedicate a person full-time that hasn’t really had a big impact, and people working just a few hours a week that have had a big one. Look at the outcomes and results of what you contribute objectively, and if it’s not working try something different.</p></blockquote>
<p>I find it fascinating that some companies devoting time and effort to work on WordPress can end up having little impact. Mullenweg&#8217;s comment is a good reminder to look at the impact your contributions are having.</p>
<h2>The Value of Contributions</h2>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/ValueOfContributions.png" rel="prettyphoto[31765]"><img class="aligncenter wp-image-31792 size-full" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/ValueOfContributions.png?resize=641%2C222" alt="Value Of Contributions" /></a></p>
<p>After years of being involved in the community, it&#8217;s my understanding that every contribution counts no matter how small it is. In December of 2013, I explained with the help of a few mentors, <a title="http://wptavern.com/i-contributed-to-the-core-of-wordpress-and-you-can-too" href="http://wptavern.com/i-contributed-to-the-core-of-wordpress-and-you-can-too">how I contributed to the core</a> of WordPress for the first time. I corrected a typo inside the default theme. I&#8217;d almost classify this as an indirect contribution but since it deals with the core of WordPress, I consider it a direct contribution. Due to the typo I fixed, my name was added to the credits page of WordPress 3.8.</p>
<p>There are hundreds of ways for people to contribute to WordPress but few that receive public acknowledgement. This is one of the reasons why badges have been added to WordPress.org user profiles.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/wordpress-profile.png" rel="prettyphoto[31765]"><img class="aligncenter size-full wp-image-20468" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/wordpress-profile.png?resize=1025%2C460" alt="wordpress-profile" /></a>If you&#8217;ve organized or have spoken at a WordCamp, which I classify as an indirect contribution, you&#8217;ll be publicly acknowledged with a badge.</p>
<p>On the surface, all contributions to WordPress no matter how small appear to be valued equally. However, WordPress is code that is written and maintained by humans. If direct contributions from volunteers decline to nothing, all of the indirect contributions become a moot point. While I think writing about WordPress is definitely a worthy contribution to the project, the reality is, <em>code is what gets the job done</em>.</p>
<h2>Contributing Back to WordPress Just Makes Sense</h2>
<p>While Automattic makes a significant contribution to the WordPress project, I&#8217;d hate to see it become the <strong>only</strong> large contributor. Development of WordPress 4.1 is being <a title="http://wptavern.com/meet-john-blackbourn-wordpress-4-1-release-lead" href="http://wptavern.com/meet-john-blackbourn-wordpress-4-1-release-lead">lead by John Blackbourn</a>, who is employed by the agency, <a title="http://codeforthepeople.com/" href="http://codeforthepeople.com/">Code For The People</a>. It&#8217;s the second release in a row to be lead by an individual not employed by Audrey Capital or Automattic. This is a welcome trend and something I&#8217;d like to see continue into the future.</p>
<p>For companies, agencies, and anyone else who rely on WordPress to put food on the table, contributing back to the project seems like common sense. WordPress is 11 years old but if those with a vested interest don&#8217;t contribute back at least 5% as suggested by Mullenweg, there&#8217;s a chance we might not be able to celebrate WordPress&#8217; 21st birthday.</p>
<h2>Related Material</h2>
<ul>
<li>Post Status &#8211; <a href="http://www.poststat.us/contribution-culture/">Contribution Culture </a></li>
<li>Ben Metcalf &#8211; <a title="http://benmetcalfe.com/blog/2014/09/wordpress-what-exactly-do-they-get-for-their-5/" href="http://benmetcalfe.com/blog/2014/09/wordpress-what-exactly-do-they-get-for-their-5/">The feasibility and governance concerns behind 5% contribution to WordPress Core</a></li>
<li>Tony Perez &#8211; <a href="http://perezbox.com/2014/10/wordpress-the-vision-of-five-and-what-it-means/">The Vision of Five and What it Means</a>.</li>
<li>Dries Buytaert &#8211; <a title="http://buytaert.net/scaling-open-source-communities" href="http://buytaert.net/scaling-open-source-communities">Scaling Open Source Communities</a></li>
</ul>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 03 Oct 2014 05:57:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:97:"WordPress.tv Blog: Build your audience:  Recent WordCamp videos from experienced content creators";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.wordpress.tv/?p=398";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:113:"http://blog.wordpress.tv/2014/10/03/build-your-audience-recent-wordcamp-videos-from-experienced-content-creators/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2710:"<p>Building an audience and growing traffic on your blog is an evergreen topic at WordCamps everywhere. Here are some recent videos from <a href="http://wordpress.tv/event/wordcamp-cape-town-2013/" target="_blank">WordCamp Capetown</a> and <a href="http://wordpress.tv/event/wordcamp-calgary-2014/" target="_blank">WordCamp Calgary </a> on how you can raise the profile of your blog with the power of content!</p>
<h2>How to build an audience in 743 difficult steps</h2>
<div id="v-revo65sd-1" class="video-player">
</div>
<p>Rian van der Merwe shares why it is better to stay away from the easy ways and choose the difficult ways instead, and how a struggling blog with an insignificant number of readers can become not only a source of great joy and expression, but also a source of non-insignificant income.</p>
<p><a href="http://wordpress.tv/2014/10/01/rian-van-der-merwe-how-to-build-an-audience-in-743-difficult-steps/" target="_blank">View on WordPress.tv</a></p>
<h2>Finding Your Voice – Learnings From 6 years of Failure</h2>
<div id="v-tS1GsW4N-1" class="video-player">
</div>
<p>In this talk, Ernest Barbaric discusses how  6 years of failure, and trying thousands of tips, tricks and best practices helped him to build an audience and a blog presence and how finally the right words came out through the keyboard, they connected with the right people, traffic quadrupled almost instantly, Publications came knocking and business started coming in from across the globe.</p>
<p><a href="http://wordpress.tv/2014/09/30/ernest-barbaric-finding-your-voice-learnings-from-6-years-of-failure/" target="_blank">View on WordPress.tv</a></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptvblog.wordpress.com/398/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptvblog.wordpress.com/398/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.wordpress.tv&blog=5310177&post=398&subd=wptvblog&ref=&feed=1" width="1" height="1" /><div><a href="http://blog.wordpress.tv/2014/10/03/build-your-audience-recent-wordcamp-videos-from-experienced-content-creators/"><img alt="WordCamp Cape Town 2013 &#8211; Rian van der Merwe &#8211; How to build an audience in 743 difficult steps.mp4" src="http://videos.videopress.com/revo65sd/video-e29d41ae2b_scruberthumbnail_0.jpg" width="160" height="120" /></a></div><div><a href="http://blog.wordpress.tv/2014/10/03/build-your-audience-recent-wordcamp-videos-from-experienced-content-creators/"><img alt="Ernest Barbaric: Finding Your Voice – Learnings From 6 years of Failure" src="http://videos.videopress.com/tS1GsW4N/video-5e3790afbe_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 03 Oct 2014 01:32:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Jerry Bates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WPTavern: 5 WordPress Conferences Taking Place This Weekend";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31778";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wptavern.com/5-wordpress-conferences-taking-place-this-weekend";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5511:"<p>This weekend is a busy time for WordPress conferences. One event to keep an eye on is WordCamp Tampa. They have been selected as one of the first to participate in a live stream pilot program using new equipment purchased by the WordPress Foundation.</p>
<p>Depending on the outcome of the experiment at this and other events, live streaming may become a regular feature of future WordCamps. Here&#8217;s a recap of the events taking place this weekend and how you can enjoy some of them from the comfort of your home.</p>
<h2>PodsCamp</h2>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/PodsCampFeaturedImage.png" rel="prettyphoto[31778]"><img class="size-full wp-image-29491" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/PodsCampFeaturedImage.png?resize=697%2C284" alt="The First Ever Podscamp" /></a>The First Ever Podscamp
<p>PodCamp is being held in Dallas, TX on October 3rd, 2014, a day before <a title="http://2014.dfw.wordcamp.org/" href="http://2014.dfw.wordcamp.org/">WordCamp DFW</a> (Dallas/Fort Worth) with a ticket price of $50. Each ticket grants you access to the event, BBQ for lunch, and direct access to the developers of Pods Framework. This will be the first time every member of the Pods development team will be in the same physical location. There are <a title="http://podscamp.org/tickets/" href="http://podscamp.org/tickets/">12 tickets remaining</a>.</p>
<h2>PrestigeConf</h2>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/PrestigeConfLogo.png" rel="prettyphoto[31778]"><img class="aligncenter size-full wp-image-27630" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/PrestigeConfLogo.png?resize=275%2C233" alt="Prestige Conference Logo" /></a></p>
<p>Prestige is a <a title="http://prestigeconf.com/" href="http://prestigeconf.com/">new conference </a>taking place on October 3rd-5th, 2014 in downtown Minneapolis, Minnesota and is being organized by Josh Broton and Kiko Doran. Unlike WordCamps, Prestige only has one track and is devoted to the business of WordPress. There are <a title="http://prestigeconf.com/tickets/" href="http://prestigeconf.com/tickets/">17 tickets remaining</a> for October 4th. However, there are 32 tickets remaining at $49 each to view a live stream of the event. Prestige also has a <a title="http://prestigeconf.wparmchair.com" href="http://prestigeconf.wparmchair.com">WP Armchair site</a> to monitor the hashtag assigned to the event.</p>
<h2>WordCamp DFW (Dallas/Fort Worth)</h2>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampDallas2014Header.png" rel="prettyphoto[31778]"><img class="aligncenter size-full wp-image-31782" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampDallas2014Header.png?resize=503%2C265" alt="WordCamp Dallas 2014 Header" /></a></p>
<p>For the first time <a title="http://central.wordcamp.org/wordcamps/dallas-2009/" href="http://central.wordcamp.org/wordcamps/dallas-2009/">since 2009</a>, there is a <a title="http://2014.dfw.wordcamp.org/" href="http://2014.dfw.wordcamp.org/">WordCamp being held</a> in the Dallas/Forth Worth area. WordCamp Dallas is a two-day event beginning on October 4th. The first day will have sessions covering various aspects of WordPress while Sunday, October 5th is contributor day. Tickets are sold out but you can keep tabs on the event via <a title="http://wcdfw.wparmchair.com/" href="http://wcdfw.wparmchair.com/">http://wcdfw.wparmchair.com/</a>.</p>
<h2>WordCamp Ann Arbor</h2>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampAnnArbor2014.png" rel="prettyphoto[31778]"><img class="aligncenter size-full wp-image-31783" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampAnnArbor2014.png?resize=680%2C265" alt="WordCamp Ann Arbor 2014 Header" /></a></p>
<p><a title="http://2014.annarbor.wordcamp.org/" href="http://2014.annarbor.wordcamp.org/">WordCamp Ann Arbor</a> is a one day event in downtown Ann Arbor, Michigan near the University of Michigan. For just $12, attendees will have an entire day of sessions to choose from to learn WordPress. It&#8217;s the first event of its kind in for Ann Arbor and tickets are sold out. I&#8217;ll be at this event so if you see me, stop and say hi.</p>
<h2>WordCamp Tampa</h2>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampTampa2014Header.png" rel="prettyphoto[31778]"><img class="aligncenter size-full wp-image-31784" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/WordCampTampa2014Header.png?resize=458%2C225" alt="WordCamp Tampa 2014 Header" /></a></p>
<p><a title="http://2014.tampa.wordcamp.org/" href="http://2014.tampa.wordcamp.org/">WordCamp Tampa</a>, Florida, is a two-day event beginning on October 4th. Tickets are sold out but you can watch the event from home if you purchase a <a title="http://2014.tampa.wordcamp.org/live-streaming/" href="http://2014.tampa.wordcamp.org/live-streaming/">live stream ticket</a>. There are 954 tickets remaining at a cost of $5 each. WordCamp Tampa is part of a pilot program to experiment with new equipment purchased by the WordPress Foundation to generate a high quality live stream. Depending on the results of the experiment at this and other events, live streaming may become a common feature at future WordCamps. Alternatively, you can follow along via <a title="http://wctpa.wparmchair.com/" href="http://wctpa.wparmchair.com/">http://wctpa.wparmchair.com/</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Oct 2014 22:33:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WPTavern: WPWeekly Episode 164 – Interview With Lester “GaMerZ” Chan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=31769&preview_id=31769";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wptavern.com/wpweekly-episode-164-interview-with-lester-gamerz-chan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4336:"<p>In this episode of WordPress Weekly, <a href="http://marcuscouch.com/" title="http://marcuscouch.com/">Marcus Couch</a> and I travel to Singapore to interview <a href="http://lesterchan.net/" title="http://lesterchan.net/">Lester &#8220;GaMerZ&#8221; Chan</a>. Chan has <a href="https://profiles.wordpress.org/gamerz/#content-plugins" title="https://profiles.wordpress.org/gamerz/#content-plugins">23 different plugins</a> in the plugin directory, amassing an incredible total download count of <strong>12,241,325</strong>! This accounts for approximately <strong>1.6%</strong> of all plugin downloads from the directory.</p>
<p>Chan explains how he handles support for 23 different plugins and offers suggestions to improve WordPress.org to make providing support easier. One of his suggestions is to give plugin authors the ability to close threads in their plugin&#8217;s support forums. Chan describes what the WordPress scene is like in Singapore and informs us that there a shortage of WordPress developers. Last but not least, he explains his role as &#8220;Tech Guy&#8221; for the <a href="http://www.techinasia.com/" title="http://www.techinasia.com/">Tech In Asia</a> website which is powered by WordPress.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/reader-poll-what-are-your-favorite-features-in-wordpress-4-0" title="http://wptavern.com/reader-poll-what-are-your-favorite-features-in-wordpress-4-0">Reader Poll: What Are Your Favorite Features In WordPress 4.0?</a><br />
<a href="http://wptavern.com/meet-john-blackbourn-wordpress-4-1-release-lead" title="http://wptavern.com/meet-john-blackbourn-wordpress-4-1-release-lead">Meet John Blackbourn, WordPress 4.1 Release Lead</a><br />
<a href="http://wptavern.com/ben-gillbanks-announces-the-end-of-timthumb" title="http://wptavern.com/ben-gillbanks-announces-the-end-of-timthumb">Ben Gillbanks Announces The End of TimThumb</a><br />
<a href="http://wptavern.com/godaddy-and-media-temple-engage-in-strategic-partnership-with-wp101" title="http://wptavern.com/godaddy-and-media-temple-engage-in-strategic-partnership-with-wp101">GoDaddy and Media Temple Engage in Strategic Partnership With WP101</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href="https://wordpress.org/plugins/gravity-forms-personality-quiz-add-on/" title="https://wordpress.org/plugins/gravity-forms-personality-quiz-add-on/">Gravity Forms Personality Quiz Add-On</a> lets you create simple, un-scored personality quizzes (think Buzzfeed-style quizzes). While there is an official quiz add-on for Gravity Forms, it is focused on graded quizzes like those you might take in school. This add-on lets you easily create quizzes that return a result rather than a grade, like &#8220;How Texan are you?&#8221; or &#8220;What Disney character would you be?&#8221;</p>
<p><a href="https://wordpress.org/plugins/ttt-crop/" title="https://wordpress.org/plugins/ttt-crop/">TTT Crop</a> This is an easy and fast way to crop any uploaded image into WordPress. No more complicated graphical editors, photos of people without heads, or products with a wrong view. Select the thumbnail, edit the crop area, and save a new thumbnail image.</p>
<p><a href="https://wordpress.org/plugins/family-tree/" title="https://wordpress.org/plugins/family-tree/">WP Family Tree</a> is a graphically formatted family tree generator for WordPress. Family members are registered as custom post types through which you can manage things such as name, birthday, the person&#8217;s picture, occupation, etc. You can also establish relationship associations, such as who a person&#8217;s mother and father are or their spousal relationship.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, October 8th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #164:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Oct 2014 21:21:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WPTavern: Matt Mullenweg on Ensuring the Future of WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31712";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wptavern.com/matt-mullenweg-on-ensuring-the-future-of-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:17398:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/matt-mullenweg.jpg" rel="prettyphoto[31712]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/matt-mullenweg.jpg?resize=1024%2C522" alt="Photo by Vladimir Kaladan Petkov" class="size-full wp-image-31713" /></a>Photo by Vladimir Kaladan Petkov
<p>Matt Mullenweg made waves this past weekend during his Q&amp;A session at <a href="http://wptavern.com/wordpress-beyond-boundaries-a-recap-of-wordcamp-europe-2014" target="_blank">WordCamp Europe</a> when he strongly advocated the importance of companies contributing back to WordPress. He offered a rule of thumb for companies that benefit from the software and want to invest in the future of WordPress:</p>
<blockquote><p>I think a good rule of thumb that will scale with the community as it continues to grow is that organizations that want to grow the WordPress pie (and not just their piece of it) <strong>should dedicate 5% of their people to working on something to do with core</strong> — be it development, documentation, security, support forums, theme reviews, training, testing, translation or whatever it might be that helps move WordPress mission forward.</p></blockquote>
<p>He cites the <a href="http://en.wikipedia.org/wiki/Tragedy_of_the_commons" target="_blank">tragedy of the commons</a> as an example fate that he hopes WordPress can avoid.</p>
<p>The <a href="http://ma.tt/2014/09/five-for-the-future/" target="_blank">5% statement</a> was instantly controversial, sparking a number of heated discussions on <a href="http://benmetcalfe.com/blog/2014/09/wordpress-what-exactly-do-they-get-for-their-5/" target="_blank">blogs</a>, <a href="http://www.poststat.us/contribution-culture/" target="_blank">news sites</a>, and Twitter. Some took exception to the wording of his suggestion, as the use of &#8220;should&#8221; implies a moral obligation, complicated further by the fact that the statement originates from a person in a position of power, who many perceive as the person most likely to benefit from increased contributions.</p>
<p>Granted, Mullenweg is at the helm of what is undeniably the most successful WordPress-based company in operation. Automattic is one of many companies that are entirely reliant on this software for their continued existence. Though all may not benefit equally from contribution, it does not negate the fact that the WordPress project is 100% dependent on contribution and would not exist without it. If we want to see it grow, there must be continued contribution, and in the end it doesn&#8217;t matter if that motivation is practical or ideological.</p>
<p>Open source businesses are free to act on Mullenweg&#8217;s suggestion of 5% contribution or to throw it out entirely. The issue cuts close to home. It&#8217;s a personal question of philosophy as much as it is a business consideration.</p>
<p>For Mullenweg, the suggestion of a 5% contribution originates out of a desire to ensure the future of WordPress. The project started out much like your average garage band. Mullenweg <a href="http://ma.tt/2003/01/the-blogging-software-dilemma/" target="_blank">wanted a place to blog and post photos</a>, so with the help of a handful of contributors, WordPress was born. Since the very early days, he has been unwavering when it comes to protecting user freedoms with the GPL and established the project&#8217;s mission to democratize publishing through open source software.</p>
<p>Before you decide to contribute, it&#8217;s a good idea to consider the future of WordPress. Where does Matt see the project going? Do you want to be a part of taking it there? I had the opportunity to speak with him at WordCamp Europe to press further into his vision of WordPress for the next decade.</p>
<h2>Mobile</h2>
<p>You&#8217;ve probably heard it before: mobile is a big part of the future of WordPress. Mullenweg emphasizes this in nearly every recent interview I&#8217;ve read and Automattic is aggressively hiring mobile developers. For many internet users, their mobile device is the only way they access the web. This is particularly true for users in countries like <a href="http://en.wikipedia.org/wiki/List_of_countries_by_number_of_mobile_phones_in_use" target="_blank">China and India</a>. If WordPress is to gain penetration in these geographical regions, it must provide a solid mobile experience.</p>
<p>This puts the WordPress mobile apps in a singular place of influence, which results in a bit of controversy at the moment. Currently, the apps are packed full of WordPress.com features that provide functionality beyond the core publishing experience. Many self-hosted WordPress users <a href="http://wptavern.com/poll-who-uses-reader-in-the-wordpress-mobile-apps" target="_blank">find the Reader in particular to be irrelevant</a>.</p>
<p>Mullenweg explained Automattic&#8217;s approach to the mobile apps:</p>
<blockquote><p>The goal with the mobile apps is first and foremost to get as many mobile app users as possible, because I think that ensures WordPress development for years to come. They are open source projects and people can contribute code to make them do a lot of different things. The team is focused on developing the things that will be most compelling to people on the mobile side. That&#8217;s notifications, stats, and the reader.</p></blockquote>
<p>Since the apps are open source, developers can fork them and remove unwanted features if they want to. However, this seems a bit counterintuitive for self-hosted WordPress users who don&#8217;t use WordPress.com features. The recent <a href="http://wptavern.com/wordpress-com-publishes-first-ever-video-ad-entitled-welcome-home" target="_blank">video ad</a> produced by Automattic does not put the spotlight on the Reader but rather features the mobile apps in use for publishing media. Won&#8217;t people be using the publishing features more often than the Reader? Mullenweg doesn&#8217;t think so.</p>
<blockquote><p>By definition, people read more than they write. You read far more than you write.  The average blogger doesn&#8217;t post every day. They read blogs every day. In fact, they read WordPress blogs every day, over a billion per month. By connecting more of those to the active users with this thing we call WordPress, I think it opens the door for more publishing in the future, which is really exciting.</p></blockquote>
<p>The apps are technically open source. If there&#8217;s a strong contingency of developers who don&#8217;t agree with the preeminence of WordPress.com&#8217;s Reader in the app, they can work to change that through contribution. The reality is that mobile developers are few and far between. At the moment, Automattic drives nearly 100% of the contribution on the apps and its agenda is unrivaled. These apps wouldn&#8217;t exist without the company&#8217;s contributions.</p>
<p>I asked Mullenweg if other contributing commercial entities are free to push their own features through the official mobile apps. &#8220;Yeah they could,&#8221; he said, but followed it up with more insight on what he believes to be Automattic&#8217;s roll in the mobile apps:</p>
<blockquote><p>I think that in many ways, Automattic is a shepherd. When you type in WordPress into a search engine, we&#8217;re the thing that pops up first. We&#8217;re the gateway drug, the thing that brings in the billions of people who don&#8217;t use WordPress yet. That&#8217;s our responsibility.</p></blockquote>
<p>He believes that, as more users easily gain access through WordPress.com, it will mean a greater number of those who transition to self-hosted sites, as people graduate from the service. &#8220;We&#8217;ll even help them move on,&#8221; he said. Obviously, you cannot simply download PHP files to your phone and get started.</p>
<p>&#8220;We want you to be able to start a blog and engage with the world of blogging 100% from the mobile device,&#8221; he said. &#8220;That requires WordPress.com and Jetpack features. Will it forever? Maybe not, but, as an idealist in a practical world, while that is not what I&#8217;d choose as a perfect solution &#8211; I&#8217;d love for you to be able to run WordPress on your phone and the world could access it, but that&#8217;s not reality today.&#8221;</p>
<p>So why doesn&#8217;t Automattic simply rename the apps to reflect the fact that the it heavily features WordPress.com? &#8220;We could rename it to WordPress.com App, but then there would be no WordPress app.&#8221; Automattic only has 15 mobile engineers at present and there aren&#8217;t many on the outside lining up to contribute to the open source apps. For Mullenweg, the ease of starting a free blog via the app is something that will help to ensure the future of WordPress:</p>
<blockquote><p>It&#8217;s difficult to build an open source thing on a closed source platform. I see it as a gateway drug and it gives people more options down the road. If we don&#8217;t do anything on mobile, five years from now, when everyone is only using mobile devices, they will all have Squarespace&#8217;s or Weebly&#8217;s. WordPress is still around but it just doesn&#8217;t matter. This allows us to matter five years from now.</p></blockquote>
<p>Mullenweg sees the apps as an easy onramp to the WordPress software in general, but recognizes that the method isn&#8217;t the most ideal situation for everyone. &#8220;The direction we&#8217;re moving is to make them more modular, so people can fork the apps more easily in the future,&#8221; he said. &#8220;If you talk to anyone on the mobile team, you will find a passion for open source.&#8221; This means that there&#8217;s the potential for the focus of the app&#8217;s development to change in the future.</p>
<h2>Internationalization and Global Adoption</h2>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/wp-croatia-serbia-slovenia-communities.png" rel="prettyphoto[31712]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/10/wp-croatia-serbia-slovenia-communities.png?resize=1025%2C509" alt="Croatian, Serbian and Slovenian WP communities with @photomatt @nacin at #WCEU - photo credit: Konstantin Tatar" class="size-full wp-image-31716" /></a>Croatian, Serbian and Slovenian WP communities with @photomatt @nacin at #WCEU &#8211; photo credit: Konstantin Tatar
<p>WordCamp Europe is unique in that it brings together many WordPress users whose primary language is not English. Mullenweg could not hide his excitement about the recent and upcoming changes related to internationalization. &#8220;If WordPress is representative of the world, then English should be a minority of the interactions, contributions and even plugins,&#8221; he said, and remarked further on how we&#8217;re still in the old mindset of taking English plugins and themes and then translating them into another language.</p>
<blockquote><p>Personally, I am far and away most excited about the internationalization improvements, because the fact that WordPress has that many users at all in these other languages where there&#8217;s not very much documentation, no plugins, very few themes, it&#8217;s kind of amazing. Basically we have lots of usage in other countries but it&#8217;s primarily built by English-speaking people. So when that starts to change to where you can, for example, login to your dashboard in Spanish, installation, plugins and themes in Spanish, I think it could substantially change WordPress&#8217; adoption rate.</p></blockquote>
<p>He believes that internationalization improvements will be key to improving WordPress&#8217; global adoption and may perhaps be more of an influential factor than the software&#8217;s incremental improvement on features:</p>
<blockquote><p>Honestly, incremental features in WordPress probably aren&#8217;t going to change its adoption rate (the number of people starting a WP blog every day). At this point, that&#8217;s primarily driven by our reputation and existing users. What will substantively change that is if WordPress opens up to vastly more audiences than it was before, be that platforms, languages, or cost. At the moment WordPress.com is free but it&#8217;s not fully available to all languages.</p></blockquote>
<p>WordPress already receives many contributions from contributors who do not speak English as their first language. Mullenweg believes it may be quite a ways down the road from now before WordPress core development requires translators to effectively incorporate contributions from what may someday be a larger contingency of non-English speaking lead developers.</p>
<p>&#8220;Maybe there&#8217;s a full-time translator working with Nacin,&#8221; he commented, imagining how internationalization could change the project in the future. With WordPress fully opened up to more languages, the software has the potential to improve at an exponentially faster rate than it does now. It&#8217;s an exciting prospect to consider.</p>
<h2>The Value of Experimentation</h2>
<p>In his quest to ensure the future of WordPress, Mullenweg often looks outside of the project for inspiration. He&#8217;s devoted a team at Automattic to experimenting with non-WordPress technologies. This was the team that created the <a href="http://wptavern.com/automattics-planned-gravatar-app-morphs-into-a-selfies-app-for-android" target="_blank">Selfies app</a>, released earlier this year.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/selfies.jpg" rel="prettyphoto[31712]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/selfies.jpg?resize=582%2C267" alt="selfies" class="aligncenter size-full wp-image-26965" /></a></p>
<p>The app wasn&#8217;t built on WordPress and didn&#8217;t appear to be as polished as other Automattic products. I asked Mullenweg why they chose to release the app in its unpolished state. He highlighted the importance of experimentation:</p>
<blockquote><p>One thing that&#8217;s difficult in a company, as it grows, is to not just work on the thing that&#8217;s most successful. WordPress, WordPress.com, Jetpack, these are ridiculously successful by any measure. It would be very easy for all 272 people at Automattic to only work on that. One of the things we did this year is create a team that is almost like our version of Google X, except we&#8217;re not going to space. As a smaller company our ambitions are a little more modest, but we do want that sense of experimentation, and that it&#8217;s ok to release something that&#8217;s not 100% polished.</p></blockquote>
<p>This further clarifies the release of the Selfies app, which the team presented as an accident wherein the planned Gravatar App morphed into Selfies. &#8220;There&#8217;s no one working on a Gravatar app right now,&#8221; Mullenweg said, confirming that the idea was considered and then scrapped. What they learned in the process was more valuable than delivering on the original idea.</p>
<blockquote><p>Usage is oxygen for ideas, right? The things that we know and learn by releasing stuff, we never could have learned otherwise, so look for more of that. That team has lots of things planned &#8211; their charter is specifically not to do things that integrate with WordPress. I&#8217;d love for it to be a much larger team, actually.</p></blockquote>
<p>This spirit of experimentation is what sets Automattic apart from many other companies that simply focus on their successful products. Perhaps it will someday translate into technology that can work alongside WordPress, especially when the software adopts more modern APIs.</p>
<h2>The Mission</h2>
<p>In recent press, Automattic has received considerable attention due to the fact that the company doesn&#8217;t work from one centralized office. The idea is brand new to those who have only experienced more traditional workplaces. I asked Mullenweg what he believes is truly unique about his company. He cited a few things, such as the hiring process, the reliability of WordPress.com&#8217;s technical architecture, the dedication to experimentation. But in the end, for him, everything loops back around to the mission of democratizing publishing.</p>
<blockquote><p>I don&#8217;t think there&#8217;s anything that doesn&#8217;t exist in any other company. Obviously we&#8217;re really deeply involved with WordPress. So is 10up and many other WP consultancies. We do a ton of open source but so does Canonical, Acquia, Redhat, and everyone else. I think it&#8217;s just the combination of all of these things, the truly distributed nature, and the mission, which isn&#8217;t just about bottom lines. It has an altruistic aspect as well.</p></blockquote>
<p>Mullenweg&#8217;s <a href="http://ma.tt/2014/09/five-for-the-future/" target="_blank">Five for the Future</a> post compelling open source companies to strive to contribute 5% back to the core software is a hotly debated topic in the WordPress ecosystem right now. Those who do not share the same practical convictions or altruistic ideals feel that the idea comes with an implication of people &#8220;working for free.&#8221; The folks at Automattic are hoping to lead the way in proving that commercial success can go hand-in-hand with an altruistic mission. For Mullenweg, it&#8217;s part of a larger vision and an unwavering commitment to ensure the future of WordPress for all.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Oct 2014 18:31:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Matt: Singapore Suites Class";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44174";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://ma.tt/2014/10/singapore-suites-class/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1153:"<p>Derek Low on What It&#8217;s like to Fly the $23,000 Singapore Airlines Suites Class [link removed, see end]. I&#8217;ve been on the <a href="http://thepointsguy.com/2014/01/flight-review-emirates-first-class-a380-dubai-new-york-jfk/">Emirates First Class A380 with the shower before</a>, but this looks like an entirely other level. I also must confess I think Emirates has rather gaudy design. <a href="http://www.svenblogt.de/review-first-class-airbus-a330-with-swiss-air/">The best I&#8217;ve seen design-wise is actually from Swiss Air</a>, as you&#8217;d expect. Update: Apparently the original link <a href="http://www.reddit.com/r/singapore/comments/2huw34/what_its_like_to_fly_the_23000_singapore_airlines/">borrowed pretty heavily</a> from another blogger, so here are links to the original author&#8217;s posts: <a href="http://andystravelblog.com/2013/04/22/sia-singapore-airlines-suites-class-a380-frankfurt-singapore/">one</a>, <a href="http://andystravelblog.com/2013/05/05/singapore-airlines-777-first-class-private-room/">two</a>, <a href="http://andystravelblog.com/2013/05/09/cathay-pacific-first-class-747-hkg-sfo/">three</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Oct 2014 11:27:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"Akismet: September Stats Roundup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1705";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://blog.akismet.com/2014/10/01/september-stats-roundup/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3608:"<p><img class="alignright wp-image-1716" src="http://akismet.files.wordpress.com/2014/10/akisbot-party1.jpg?w=500&h=291" alt="akisbot-party" width="500" height="291" />T&#8217;was an exciting month around Akismet headquarters. <strong>We caught over 300 million spam messages in just one day for the first time</strong>, on September 26. And if that wasn&#8217;t enough, we saw over 300 million comments in one day again on September 30.</p>
<p>But wait, there&#8217;s more&#8230; we also broke our daily record a total of 4 times this month. Our last daily record was 269 million spam messages on August 21, here&#8217;s what happened since then:</p>
<ul>
<li>We broke the daily record on <strong>September 4th</strong> with 280 million spam comments</li>
<li>And then again on <strong>September 7th</strong> with 284 million spam messages</li>
<li>And then again on <strong>September 26th</strong> with the groundbreaking 312 million comments</li>
<li>And finally, just yesterday &#8211; on <strong>September 30</strong> -we broke our record again with 366 million spam comments</li>
</ul>
<p>Phew. What a ride. <span class="wp-smiley wp-emoji wp-emoji-mrgreen" title=":mrgreen:">:mrgreen:</span></p>
<p>There were two other times in Akismet history when we broke the daily record this many times in one month. In November 2011 we broke the daily record 8 times (!) and in December 2012, we broke it 6 times. Though, the numbers were much easier to beat then &#8211; 90 to 100 million daily spam comments in November 2011, and 177 to 196 million in December 2012.</p>
<p>Here are the daily numbers for September, with the previous record marked for comparison:</p>
<div id="attachment_1719" class="wp-caption alignnone"><a href="http://akismet.files.wordpress.com/2014/10/akismet-spam-and-ham-stats-sept-2014.png"><img class="wp-image-1719 size-large" src="http://akismet.files.wordpress.com/2014/10/akismet-spam-and-ham-stats-sept-2014.png?w=700&h=436" alt="We saw 7,955,568,000 spam comments go through this month, and 357,739,000 real comments." /></a><p class="wp-caption-text">We saw 7,955,568,000 spam comments go through this month, and 357,739,000 real comments.</p></div>
<p>You may have also seen a rise in your own spam comments this month. If you&#8217;re noticing a larger number of comments than usual being missed by Akismet, please do get in touch through <a href="http://akismet.com/contact/">our contact form</a> so we can help out. Let us know what your API key is, and on what website you&#8217;re seeing the increase, and we&#8217;ll be happy to take a look.</p>
<p>Our slowest day this month was September 14, with a mere 218 million spam comments going through. Compared with September of last year, the number of spam comments going through Akismet increased by 112%, and it increased from last month by 10%. This month, we missed about 1 in every 4,574 spams.</p>
<p>As usual, real comments make up only a small portion of the total comments we see coming through &#8211; at 4% this month.</p>
<p><em>This post is part of a monthly series summarizing some stats and figures from the Akismet universe. Feel free to browse <a href="http://blog.akismet.com/category/monthly-roundup/">all of the posts in the series</a>.</em></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1705/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1705/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.akismet.com&blog=116920&post=1705&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Oct 2014 01:00:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Valerie";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WPTavern: WordPress Theme Review Team Gains 27 New Reviewers at WordCamp Europe Contributor Day";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31680";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:105:"http://wptavern.com/wordpress-theme-review-team-gains-27-new-reviewers-at-wordcamp-europe-contributor-day";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4310:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/wceu-contributor-day.png" rel="prettyphoto[31680]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/10/wceu-contributor-day.png?resize=1025%2C495" alt="wceu-contributor-day" class="aligncenter size-full wp-image-31687" /></a></p>
<p>The contributor day following <a href="http://wptavern.com/wordpress-beyond-boundaries-a-recap-of-wordcamp-europe-2014" target="_blank">WordCamp Europe</a> was a tremendous success, bringing approximately 180 people to the <a href="http://www.siteground.com/" target="_blank">SiteGround</a> offices in Sofia. A healthy mixture of veteran contributors were in attendance, as well as many folks who were brand new to contributing.</p>
<p>At the beginning of the day, contributors split off into smaller groups to focus on translations, core, documentation, theme review, support, GlotPress, and Rosetta. When Theme Review Team member Tammie Lister put out a call for theme reviewers, hands shot up all over the room. Automattic donates Lister&#8217;s time two or three days per week specifically for helping with WordPress.org theme review.</p>
<p>After the event, she reported that 27 new people were added to the <a href="https://make.wordpress.org/themes/" target="_blank">WordPress Theme Review Team</a>. They started by introducing themselves and discussing why one might want to get involved. Those who had some experience shared their individual processes. After this, they dove straight into reviewing and each person was given a theme.</p>
<p>&#8220;The current idea is that during the month of October we will be focusing on how we do contribution days now, so we&#8217;re having experiments and thinking about ways to improve that,&#8221; Lister said. During the last <a href="https://make.wordpress.org/themes/2014/09/24/weekly-meeting-notes-2/" target="_blank">weekly meeting</a>, the Theme Review Team identified the pain points in adding reviewers and brainstormed ideas for onboarding new reviewers during contributor days. This includes the possibility of creating a doing_it_wrong() theme, as a project at WordCamp San Francisco, that can be used for education and testing. Lister said they will be playing with a few ideas at upcoming contribution days in San Francisco and Toronto.</p>
<h3>A Room Full of Themers</h3>
<p>The best part of getting a record number of new reviewers together was packing a room full of themers who were all buzzing about the craft of WordPress theming. &#8220;What was really exciting about today is that it wasn&#8217;t just developers,&#8221; Lister said. &#8220;We had some people who didn&#8217;t know much HTML, some who were newer to theming, and some who were doing it the right way.&#8221;</p>
<p>The key thing for new reviewers is to take your time, Lister said. &#8220;I think the thing is that you just have to take it slowly when you start theme reviewing. You go through the process and you get faster.&#8221;</p>
<p>New reviewer <a href="https://twitter.com/andrew_liyanage" target="_blank">Andrew Liyanage</a> decided to jump in and join the Theme Review Team in order to sharpen his professional skills. &#8220;I wanted to get into theme design. I thought before designing a theme, I could get into review in order to get to know what the do&#8217;s and the don&#8217;ts are,&#8221; he said. &#8220;I&#8217;m already reviewing a theme right now, and it&#8217;s going better than I thought it would.&#8221;</p>
<p>Lister plans to match each new reviewer with someone from the new <a href="http://wptavern.com/wordpress-theme-review-team-to-launch-mentoring-program" target="_blank">mentoring program</a>, established last month. Although most of the communication happens on trac, there are more people than ever to help out with the process.</p>
<p>&#8220;A lot of it is trac focused, because it has to be, but we now have mentors, more admins, and trusted reviewers. So there&#8217;s a lot more people but there&#8217;s a lot more people looking after those people,&#8221; Lister said.</p>
<p>With a record number of new theme reviewers added in one day, the team now has 27 more people who are familiar with the guidelines. This is bound to make a significant dent in the queue and lighten the load for the rest of the team.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 01 Oct 2014 09:52:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"Post Status: Contribution as culture";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=7153";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://www.poststat.us/contribution-culture/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:12488:"<p><img class="aligncenter size-large wp-image-7157" src="http://www.poststat.us/wp-content/uploads/2014/10/five-percent-752x250.gif" alt="five-percent" width="627" height="208" /></p>
<p><em>This post spends a lot of time analyzing and referencing two other blog posts. Excuse me for that, but also be sure to read both, as they are relevant for this post and also interesting in their own right.</em></p>
<p>Matt Mullenweg wrote a blog post called <a href="http://ma.tt/2014/09/five-for-the-future/">Five for the Future</a> yesterday that advocates his belief that WordPress-centric companies should aim to utilize 5% of their company resources toward contributing back to the project.</p>
<p>He noted in the post that <a href="http://automattic.com">Automattic</a> isn&#8217;t quite to this point, but that they are working on it, and describes why he believes it&#8217;s important. He closes with this:</p>
<blockquote><p>It’s a big commitment, but I can’t think of a better long-term investment in the health of WordPress overall. <strong>I think it will look incredibly modest in hindsight.</strong> This ratio is probably the bare minimum for a sustainable ecosystem, avoiding the <a href="http://en.wikipedia.org/wiki/Tragedy_of_the_commons">tragedy of the commons</a>. I think the 5% rule is one that all open source projects and companies should follow, at least if they want to be vibrant a decade from now.</p></blockquote>
<p>This was followed up by one of the co-founders of one of the very hosting companies Matt partially referenced in his post &#8212; WP Engine&#8217;s Ben Metcalfe &#8212; who responded with a blog post of his own: <a href="http://benmetcalfe.com/blog/2014/09/wordpress-what-exactly-do-they-get-for-their-5/">WordPress: What exactly do they get for their 5%?</a></p>
<p>I think I was immediately thrown off by Ben&#8217;s post title, but so many times throughout reading it I was shocked at how he made assumptions of Matt&#8217;s intentions or missed what I would call &#8220;the point&#8221;.</p>
<h3>5% is not a decree</h3>
<p>Obviously, Matt is not speaking from the mountaintop with a proclamation of law. This is his recommendation &#8212; one that he believes will reward the firms that strive for it.</p>
<p>I believe that the community has already shown us that those that invest into WordPress are rewarded from it. We improve our understanding of a foundational software of our careers, improve our skills, are more marketable, more attractive to employers, and create natural opportunities for developing industry relationships.</p>
<p>How should 5% of &#8220;people&#8221; be defined? I&#8217;m pretty sure Matt would agree that 5% of people or 5% of revenue toward people doesn&#8217;t really matter to him; yet Ben makes a continuous sticking point about the cost of &#8212; and need for &#8212; engineers.</p>
<p>Additionally, while Matt utilizes full-time employees, the same (or better) effect could be had with shared time from more employees.</p>
<p>I&#8217;m not big into absolutes, so it&#8217;s important to remember that while I&#8217;m advocating that Matt&#8217;s recommendation of 5% time, I think it&#8217;s simply a good recommendation. This is a free economy and companies can do what they want. But I think in the current and long term, contribution will be key to greater corporate success for those that choose to do so.</p>
<h3>What does 5% cost, and who does it require?</h3>
<p><span id="more-7153"></span></p>
<blockquote><p>While Matt was careful to include numerous non-engineering roles companies could help with, ultimately what drives the open source project is source code contribution by software engineers. &#8230;</p>
<p>A reasonable engineer in the US costs $100k/y, and if you factor in benefits <em>(tax funded health-care, anyone?)</em> and overheads you could easily be looking at $130k or more per person, per year. &#8230;</p>
<p>A 200+ person web hosting company would need to hire 10 engineers to meet a 5% goal, requiring a budget of anything between $1MM-1.3MM+ per year. Those engineers probably need a manager – to mentor them, provide career development etc. Those 11 people also put pressure on human resources, finance, legal, facilities etc – probably equating to another person again. Now we’re talking probably more like $1.25-$1.5m annually.</p></blockquote>
<p>First, I believe Ben has spent too much time in the world&#8217;s largest cities if he believes engineers cost $100,000 per year on average. In my experience (yes, I interview people myself), that&#8217;s not the case, and based on my decent view of the ecosystem it&#8217;s not an appropriate going rate &#8212; especially if the offer on the table is a particularly desirable position.</p>
<p>More importantly, <strong>the project needs far more non-technical contributors</strong>. Ben&#8217;s assertion that &#8220;ultimately&#8221; software engineers drive the project is not true. Users drive the project. A technically savvy user-minded contributor can be a beacon of light to a group of software developers. And given the user-facing nature of WordPress itself, non-engineer contributors could drastically improve the less code-sexy parts of the WordPress ecosystem: project management, docs, training, testing, support, translation, etc.</p>
<p>Additional to &#8220;core&#8221; contributions, WordCamps, plugins, themes, communities, and many other venues are outstanding places where contributors &#8212; yes, they&#8217;re still contributors! &#8212; can impact the overall project.</p>
<p>Finally, as I noted above, I think companies could quite effectively contribute parts of employees&#8217; time versus dedicated 100% time, which would also prevent the need to have dedicated managers for open source contributors.</p>
<h3>Foundational software to your business</h3>
<p>Ben spends a chunk of time saying that big companies like GoDaddy get a &#8220;get out of jail free card&#8221; and that obviously Matt wouldn&#8217;t expect they dedicate 5% of their thousands of employees.</p>
<p>GoDaddy definitely benefits from WordPress and they also contribute to it; and no, they don&#8217;t contribute 5% I&#8217;m sure. But WordPress is not foundational to GoDaddy&#8217;s business. They have a dedicated sub-product for it, and they also have many contributors to it.</p>
<p>WP Engine, and many others (including mine), are almost completely or completely reliant on WordPress as a platform. WordPress and its underlying technologies are foundational to our careers and businesses.</p>
<p>It is simply a different story to compare a company that would continue on pretty much fine without WordPress and one that would have to seriously reconsider their entire business model.</p>
<p>For example, let&#8217;s compare the scenario to a publisher. <a href="http://recode.net">Re/code</a> is built on WordPress. They have a staff of 20+. Do they <em>completely rely</em> on WordPress for their website? Yes. For their business model? No. In their scenario, it makes sense for them &#8212; and could benefit them pretty directly &#8212; to allocate some time of some employees to WordPress, but if WordPress disappears they can and will migrate to a different platform.</p>
<h3>Contributing to the full stack</h3>
<p>It was questioned to me on Twitter, after my initial reaction to Ben&#8217;s post, whether I contribute 5% of my time to open source projects like PHP, MySQL, and other tools that WordPress relies on.</p>
<p>This is a good question and point, but it does not cause me to stumble in my opinions. I believe open source contributions in general benefit the entire software stack.</p>
<p>In my scenario, I can be more impactful on the WordPress project than others. But I believe contributions can take many shapes, in both directions.</p>
<p>Some folks, like Daniel Bachhuber, greatly contribute to the project as a whole by supporting upstream projects like <a href="http://wp-cli.org">WP CLI.</a></p>
<p>Automattic is a fantastic example of a company that has both upstream and downstream contributions. They are active contributors to, employers of contributors or founders, or monetary sponsors to a huge number of downstream projects: WordPress, PHP, Nginx, jQuery, Elastic Search, Node, Socket.io, and probably a bunch I can&#8217;t think of or don&#8217;t know about. Additionally, they are a driving force behind dozens of upstream, open source themes and plugins.</p>
<p><em>Edit: Matt <a href="https://twitter.com/photomatt/status/517270097355091968">says in a Tweet</a> where Andrey Savchenko asked for clarification about PHP contributions that Automattic doesn&#8217;t actively contribute to PHP. Though I think I define contribution a bit more loosely than Matt does.</em></p>
<p>Whether a company is contributing to their foundational piece of software, a downstream or upstream application, or on an adjacent aspect that leads to the betterment of the platform that is foundational to their business objectives, then I believe it will in turn be beneficial to their bottom line.</p>
<h3>Contribution as culture</h3>
<p>Contribution should not be considered an isolated cost, but an enabling investment.</p>
<p>If I run a business that relies on a foundational piece of software like WordPress, then it benefits me greatly for my employees &#8212; no matter what role they play within the company &#8212; to be intimately familiar with that software.</p>
<p>In my last job, I was tasked with guiding a transition of my company from developing mostly on a proprietary CMS to WordPress. I consistently preached the importance for everyone in the company to understand some fundamentals of WordPress itself. During my time there and since I&#8217;ve moved on, I&#8217;ve seen other members of that company learn the software, get involved in our local community, and even contribute back to WordPress itself; and both they and the company are better off for it.</p>
<p>Whether an employee is in sales, customer service, design, development, management, or wherever else &#8212; every employee knowing your product is important. I firmly believe this. I would want anyone in an organization I&#8217;m part of to be able to discuss our product in detail and with confidence to anyone.</p>
<p>When your company relies on a foundational piece of software &#8212; such as those we&#8217;re discussing in this post &#8212; that&#8217;s in effect part of your product. We are building products and services around and for WordPress. How important should it be that our company&#8217;s employees understand it?</p>
<p>And how can they understand it better? By contributing of course!</p>
<p>Have a new support rep? Show them the WordPress.org forums to get their feet wet. New designer or front-end developer? Have them sit in on default theme conversations or read through the Make UI blog. New sales person? Get them involved at your local meetup and WordCamp. This list can go on.</p>
<p>Avenues for contribution are an incredible gateway for learning WordPress. Blogging about WordPress (another avenue of contribution) has greatly enabled me to be better at my job, and therefore made me significantly more valuable to the companies I&#8217;ve worked with.</p>
<h3>Five for now</h3>
<p>Matt called his post Five for the Future, and talked specifically about how a 5% investment by a company will ensure a greater future for WordPress and therefore said company. I disagree.</p>
<p>Contributing now will benefit the company and its employees <em>right now</em>. And while both Matt and Ben focused on individuals within the company being targeted contributors, I think it&#8217;s much more beneficial to have a much larger percentage of a company contributing a portion of their time (even if small). I&#8217;d rather see 2 of 200 employees be full time contributors and then have 80 10% contributors than have 10 full time contributors.</p>
<p>I think we&#8217;ve seen many, many examples of contributors (people and companies) reaping tangible and intangible benefits from when they contribute &#8212; whether that contribution is to the codebase or the community. Contributors in this ecosystem come out on top.</p>
<p>Contributions are not an isolated cost or burden. Nor should their effects be limited to good faith investments to the sustainability of the ecosystem.</p>
<p>Contributions benefit the bottom line, and they benefit the bottom line right now.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 01 Oct 2014 06:17:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WPTavern: Interview With Stream Project Lead, Frankie Jarrett";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31664";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wptavern.com/interview-with-stream-project-lead-frankie-jarrett";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9745:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/FrankieJarretFeaturedImage.png" rel="prettyphoto[31664]"><img class="aligncenter size-full wp-image-31673" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/FrankieJarretFeaturedImage.png?resize=651%2C246" alt="Frankie Jarrett Featured Image" /></a></p>
<p>Stream 2.0 is a <a title="http://wptavern.com/stream-morphs-from-a-plugin-into-a-service" href="http://wptavern.com/stream-morphs-from-a-plugin-into-a-service">significant update</a> that changes the stand alone plugin into a service. But not everyone is happy with the change. Those who use Stream in enterprise environments have voiced disappointment regarding the latest update. The following is feedback from a user on the <a title="https://www.facebook.com/groups/advancedwp/?fref=nf" href="https://www.facebook.com/groups/advancedwp/?fref=nf">Advanced WordPress Facebook group</a>. &#8220;Heads up if you use Stream. The 2.0 upgrade now stores everything in the cloud instead of the local database and requires a WordPress.com account to use it. It&#8217;s a great plugin but this new functionality is not optional and I can no longer use it with our enterprise data.&#8221;</p>
<p>I reached out to Stream project lead, <a title="http://frankiejarrett.com/" href="http://frankiejarrett.com/">Frankie Jarrett</a>, and asked why the team decided to rely on third-party services. I also inquired whether users have any options to house data on their own servers or connect it to a service of their choosing. Jarrett gives insight into the future of Stream as a Service and let&#8217;s us know if they are working on a version that is compatible with enterprise environments.</p>
<h2>Interview With Frankie Jarrett</h2>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WordPressLogging.png" rel="prettyphoto[31664]"><img class="size-full wp-image-31670" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WordPressLogging.png?resize=640%2C200" alt="WordPRess Logging" /></a>photo credit: <a href="https://www.flickr.com/photos/astro-dudes/1492818224/">Claire L. Evans</a> &#8211; <a href="http://creativecommons.org/licenses/by-nd/2.0/">cc</a>
<p><strong>Jeff &#8211; Why the decision to use an external service by default to offload Stream activity data?</strong></p>
<p>Over the past 10 months we’ve learned a lot about logging events, specifically logging actions taken inside the WordPress Admin. As time went on, some of the biggest concerns we had revolved around the topics of performance and security. It became clear to us that Stream needed to be more than just a plugin to advance into a solid solution, it needed to be a service that was self-contained and lived alongside WordPress instead of trying to force it to work inside the WordPress architecture and never truly being scalable or secure.</p>
<p>MySQL is nice solution for storing content with simple querying, this is how WordPress uses it, but MySQL is actually bad for storing logs, especially if you want to retain them for a long time and/or run complex queries on them while also expecting those queries to be fast. Not to mention, you don’t want the performance of your website’s content to be affected at all. Since the primary purpose of the MySQL database is to store and serve up content to your website visitors, it was our view that should never be hindered by event logging.</p>
<p>Now that Stream is a service, we can use brand new technologies like <a title="http://www.elasticsearch.org/" href="http://www.elasticsearch.org/">Elasticsearch</a>, that are better suited for (and even designed for) querying huge numbers of logs. The result is a more powerful querying performance, the possibility for users to do even more complex queries in the future (for their Reports), and have no worries about keeping logs for a very, very long time. The things we are now doing in Stream 2.0, and plan to do in the future, require the power of Elasticsearch and don’t translate into MySQL storage solutions.</p>
<p>In regards to security, websites and databases get hacked all the time. Unfortunately that’s just the way it is. Since all of Stream’s records had previously lived inside the website, it too was as vulnerable as the website itself. This means that any hacker that gained access could mess up a site and then cover up their tracks by simply deleting the Stream log data. This was a bad thing and meant those logs weren’t really a true security audit trail at all. Now that Stream is a service, those logs are untouchable by an intruder. Once an action is performed, it’s forever in the event history, so the site owner knows without a doubt what things have happened on their site and can go through an undo the damage.</p>
<p><strong>Jeff &#8211; Why the connection between Stream and WordPress.com ID logins?</strong></p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WordPressStreamConnection.png" rel="prettyphoto[31664]"><img class="size-full wp-image-31671" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WordPressStreamConnection.png?resize=639%2C200" alt="WordPress Stream Connection" /></a>photo credit: <a href="https://www.flickr.com/photos/manchester-monkey/5432450932/">Manchester-Monkey</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a>
<p>This was an easy decision for us, actually. Over the past few years there have been several WordPress companies that have had their sites hacked and user passwords have been compromised as a result. It’s a sad and unfortunate thing that can be avoided by simply not storing them. Our solution for this was to use SSO (Single sign on) powered by <a title="https://wordpress.com/" href="https://wordpress.com/">WordPress.com</a>.</p>
<p>This means Stream doesn’t have to store any login details for any customer and customers don’t have to sign up for yet another account somewhere. Furthermore, <a title="http://en.support.wordpress.com/security/two-step-authentication/" href="http://en.support.wordpress.com/security/two-step-authentication/">WP.com SSO supports two-factor authentication</a>. This is a huge win for folks who are really concerned about the security of their logins, and we wanted Stream to have this capability.</p>
<p>The reason why we chose WP.com SSO was because of its status and reach in the WordPress community. Stream is a WordPress product and service, so it only makes sense to reach as many WordPress users as possible. When you think about all the people who use Jetpack, Gravatar, Akismet, VaultPress and Polldaddy &#8211; that’s a lot of people. Maybe not everyone, but again, we wanted to make a decisive decision not to store user login credentials at all, and that could mean some people might not be able to use it, but it’s for the good of all our users. WordPress.com SSO was also very easy to implement on our WordPress-powered site compared with the Facebook, Twitter or Google SSO alternatives.</p>
<p><strong>Jeff &#8211; Is the connection between Stream and WordPress.com similar to Jetpack in that some things won’t work without the connection?</strong></p>
<p>The only time Stream needs to talk to WordPress.com is during sign up, for login credentials. Stream doesn’t <em>ping</em> back to your website like Jetpack does. This means your site doesn’t have to be publicly accessible for Stream to work and can be run on a local/development environment without any problems or extra steps needed.</p>
<p><strong>Jeff &#8211; Overall, what are the future plans for Stream now that it’s morphed into a service?</strong></p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/FutureOfStream.png" rel="prettyphoto[31664]"><img class="size-full wp-image-31672" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/FutureOfStream.png?resize=639%2C200" alt="Future of Stream" /></a>photo credit: <a href="https://www.flickr.com/photos/wwarby/9641216546/">wwarby</a> &#8211; <a href="http://creativecommons.org/licenses/by/2.0/">cc</a>
<p>Now that we have some scalability, performance and security milestones behind us, we are very much looking forward to making Stream even better in the coming months and years. You might have already noticed, but Stream 2.0 featured built-in integration with eight popular WordPress plugins. We intend to continue making Stream compatible out-of-the-box with tracking things that many other popular plugins do.</p>
<p>Another thing we plan to do is open up a <strong>REST API</strong> for people to be able to access their data and do anything they want with it. This is a very exciting prospect. Finally, we are working on ways to have a complete “mash-up” of all of your Stream data in one place. This is based on a lot of feedback we’ve been getting from folks who run not just multi-site, but multiple single-site installs for their clients and want to see everything that’s happening in one place. We think that will be another huge benefit to people and something that is only possible because Stream is now a service.</p>
<p><strong>Jeff &#8211; One of the complaints I&#8217;ve seen is that Stream&#8217;s reliance on third-party services makes it incompatible with enterprise environments. What is the team doing to address this issue?</strong></p>
<p>The new Stream relies on the power of Elasticsearch for performance and complex queries, but we are exploring ways for the Stream service stack to be run <em>on-premise</em> for Enterprise organizations who have strict internal policies that would require that. We don’t have have an ETA on when this type of solution will be ready, but we are actively pursuing it.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 01 Oct 2014 04:07:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WPTavern: Stream Morphs From a Plugin Into a Service";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31615";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wptavern.com/stream-morphs-from-a-plugin-into-a-service";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6231:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2013/12/stream-banner.jpg" rel="prettyphoto[31615]"><img class="aligncenter size-full wp-image-12902" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2013/12/stream-banner.jpg?resize=772%2C250" alt="stream plugin banner" /></a></p>
<p>Stream 2.0 is <a title="https://wp-stream.com/the-new-stream-is-here/" href="https://wp-stream.com/the-new-stream-is-here/">available for download</a> and includes a plethora of enhancements. This version features a rewrite from the ground up with a focus on <em>scalability, security</em>, and <em>activity</em>. As part of the rewrite, Stream activity data is stored in the cloud using <a title="http://aws.amazon.com/" href="http://aws.amazon.com/">Amazon Web Services</a> with <a title="http://www.elasticsearch.org/" href="http://www.elasticsearch.org/">Elasticsearch</a>. This is the same type of setup Jetpack uses to power its <a title="http://jetpack.me/support/related-posts/" href="http://jetpack.me/support/related-posts/">Related Posts</a> module.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ConnectToStream.png" rel="prettyphoto[31615]"><img class="size-full wp-image-31654" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ConnectToStream.png?resize=989%2C120" alt="Connect To Stream Service" /></a>Request For a WordPress.com ID
<p>The data is stored over an SSL connection making it hard to tap into your activity stream. The Stream team explains the plugin as being the <em>black box</em> of a WordPress site that even the NSA can&#8217;t penetrate. As part of the security enhancements, <span class="wp-stream-tooltip">Stream uses your WordPress.com ID to authorize your account. </span></p>
<p><span class="wp-stream-tooltip">After connecting my WordPress.com ID to Stream, it loaded a <a title="https://wp-stream.com/pricing/" href="https://wp-stream.com/pricing/">Plans and Pricing page</a> in place of the backend instead of just connecting my account. This is unexpected behavior and a disappointing user experience. I ended up having to load the WordPress backend in a new browser tab. </span></p>
<p>I ran into a loop where each time I logged into the backend of WordPress, I&#8217;d see the <strong>Connect to Stream</strong> notification. Each time I clicked the button, it would load the Plans and Pricing page. As it turns out, the reason for the endless loop is because I didn&#8217;t have a subscription registered with the Stream website. Once I completed the process of registering for a free account, the WordPress backend loaded the Stream records screen.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/SuccessfulConnectionToStream.png" rel="prettyphoto[31615]"><img class="size-full wp-image-31655" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/SuccessfulConnectionToStream.png?resize=765%2C336" alt="Successful Connection To Stream" /></a>Successful Connection To Stream
<p>I recommend text be added to the top of the Plans and Pricing page. The text should explain that in order to complete the connection to Stream, a subscription plan needs to be selected. It&#8217;s not obvious and gave me the impression the plugin is broken.</p>
<h2>Support For SMS Notifications Thanks to an Outside Source</h2>
<p>One of the neat features in 2.0 is the ability to set up SMS notifications. For instance, every time a theme, plugin, or WordPress is updated, you can configure Stream to send you a text message.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ConfiguringSMSNotifcations.png" rel="prettyphoto[31615]"><img class="size-full wp-image-31656" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ConfiguringSMSNotifcations.png?resize=1025%2C552" alt="Configuring SMS Notifications In Stream" /></a>Configuring SMS Notifications In Stream
<p>SMS notifications ended up in 2.0 thanks to the contributing efforts of <a title="https://jeffmatson.net/" href="https://jeffmatson.net/">Jeff Matson</a>. Matson is the author of the <a title="http://wordpress.org/plugins/wp-sms-notifications/" href="http://wordpress.org/plugins/wp-sms-notifications/">WP SMS Notifications</a> plugin <a title="http://wptavern.com/keep-track-of-changes-to-your-wordpress-site-with-the-wp-sms-notifications-plugin" href="http://wptavern.com/keep-track-of-changes-to-your-wordpress-site-with-the-wp-sms-notifications-plugin">we highlighted on the Tavern</a> back in July. Matson explains why he decided to contribute to the Stream project, &#8220;When I created WP SMS Notifications, the biggest comment I received was that I should work with Stream to add my functionality to their plugin. The team behind Stream agreed and I was given access to their Github account. Now, I can proudly say that my code is behind one of the greatest activity tracking plugins out there.&#8221; However, the only way to take advantage of SMS notifications is to use the Pro account which is available for <strong>$2 per month</strong>.</p>
<h2>Older Version of Stream Will Remain Available For Download</h2>
<p>Stream has undergone major changes and is now a service versus a stand alone plugin. For those who don&#8217;t want to update to the new version, the Stream Team is leaving the <a title="https://github.com/wp-stream/stream/releases/tag/1.4.9" href="https://github.com/wp-stream/stream/releases/tag/1.4.9">previous version online</a> via Github. Versions 1.4.9 and below won&#8217;t receive any more updates outside of patching major bugs or security vulnerabilities.</p>
<h2>Overall, a Solid Update</h2>
<p>Stream 2.0 is a solid update. The latest edition supports activity tracking for eight of the most popular WordPress plugins out-of-the box including: Advanced Custom Fields, bbPress, BuddyPress, Easy Digital Downloads, Gravity Forms, Jetpack, WooCommerce and WordPress SEO by Yoast. SMS notification is a great enhancement and I think it&#8217;s respectable of the team to keep 1.4.9 available for those that don&#8217;t like the new direction Stream is heading in.</p>
<p>Are you satisfied with the latest update to Stream? Does using WordPress.com and Amazon Web Services turn you off from using it?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 01 Oct 2014 02:46:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:107:"WPTavern: WordPress Plugin Checks if The Server Hosting Your Site is Vulnerable to The “ShellShock” Bug";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31659";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:111:"http://wptavern.com/wordpress-plugin-checks-if-the-server-hosting-your-site-is-vulnerable-to-the-shellshock-bug";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2910:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ShellShockFeaturedImage.png" rel="prettyphoto[31659]"><img class="size-full wp-image-31661" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ShellShockFeaturedImage.png?resize=636%2C300" alt="ShellShock Featured Image" /></a>photo credit: <a href="https://www.flickr.com/photos/tbuser/6076934115/">Tony Buser</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a>
<p>In recent days, a <a title="http://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2014-6271" href="http://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2014-6271">security vulnerability</a> in Bash known as &#8220;ShellShock&#8221; has put millions of servers at risk. Without going into too much detail, the vulnerability allows an attacker to execute any code on a vulnerable server. The amount of servers at risk is far greater than the <a title="http://heartbleed.com/" href="http://heartbleed.com/">Heartbleed bug</a> discovered earlier this year. The founder of <a title="https://managewp.com" href="https://managewp.com">ManageWP</a>, Vladimir Prelovac, has released a <a title="https://wordpress.org/plugins/shellshock-check/" href="https://wordpress.org/plugins/shellshock-check/">new WordPress plugin</a> that helps determine if the server hosting your website is vulnerable to the ShellShock bug.</p>
<p>The plugin checks for both disclosed ShellShock vulnerabilities <a href="http://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2014-6271">CVE-2014-6271</a> and <a href="http://web.nvd.nist.gov/view/vuln/detail?vulnId=CVE-2014-7169">CVE-2014-7169</a>. Simply download the plugin, activate it, and browse to <strong>Settings &gt; Shellshock.</strong> Click the <strong>Run Test</strong> button. After the test is completed, a notice displays whether the server is vulnerable or not. In the following  screenshot, the server I tested is not vulnerable.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ShellShockTestResults.png" rel="prettyphoto[31659]"><img class="size-full wp-image-31660" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ShellShockTestResults.png?resize=890%2C229" alt="ShellShock Test Results" /></a>ShellShock Test Results
<p>If the server is vulnerable, take a screenshot and contact your host as soon as possible. Create a trouble ticket. Then, inform the support representative you tested the server and the results show it&#8217;s vulnerable. Attach the screenshot to the trouble ticket with a link to <a title="http://www.troyhunt.com/2014/09/everything-you-need-to-know-about.html" href="http://www.troyhunt.com/2014/09/everything-you-need-to-know-about.html">this article by Troy Hunt</a>, which explains everything they need to know about the bug. After filing the report, create a full back up of your site in case the server is attacked before it&#8217;s patched.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 01 Oct 2014 01:41:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WPTavern: A New Project by Nick Haskins, WP Status Page";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31609";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wptavern.com/a-new-project-by-nick-haskins-wp-status-page";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3570:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/WPStatusPageFeaturedImage.png" rel="prettyphoto[31609]"><img class="size-full wp-image-31651" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/WPStatusPageFeaturedImage.png?resize=640%2C200" alt="WP Status Page Featured Image" /></a>photo credit: <a href="https://www.flickr.com/photos/lrosa/560296859/">Luigi Rosa has moved to Ipernity</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a>
<p>The creator of <a title="http://nickhaskins.com/2014/09/wp-status-page/" href="http://nickhaskins.com/2014/09/wp-status-page/">Aesop Story Engine</a>, Nick Haskins, wants to know if there is <a title="http://nickhaskins.com/2014/09/wp-status-page/" href="http://nickhaskins.com/2014/09/wp-status-page/">any interest in a WordPress plugin</a> that would provide a project status page. After browsing the WordPress plugin directory and coming up empty, Haskins is developing his own solution in the form of a plugin.</p>
<p>He describes the plugin will have a similar setup to <a title="https://www.statuspage.io/" href="https://www.statuspage.io/">StatusPage.io</a>. &#8220;It would definitely have a mechanism to determine if a supplied URL and/or database is down or not. But the page would be more &#8220;alive&#8221; then a static <strong>coming soon page</strong> with the ability to send notifications (email/SMS) to users in addition to showing real-time status updates with a history of events,&#8221; Haskins told the Tavern.</p>
<div>Haskins explains how the plugin would work. &#8220;You&#8217;d provide a subset of items like maybe a URL, database , API endpoint, and we&#8217;d ping that and return the status in a pretty way. I think the key making this really work would be to provide some level of automation as in, a developer could push a commit to Github or Bitbucket with a specific tag that would then automatically update a message status on the status page.</div>
<div></div>
<p>An example of a status page is the Amazon Web Services health dashboard. Haskins says his page will look similar but will have a better design.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/AmazonWebServicesStatusPage.png" rel="prettyphoto[31609]"><img class="size-full wp-image-31649" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/AmazonWebServicesStatusPage.png?resize=814%2C690" alt="Amazon Web Services Status Page" /></a>Amazon Web Services Status Page
<p>One of the issues he brings up is where to host the plugin. It doesn&#8217;t make sense to host a status page on the same server as the project. Instead of forcing users to sign up for a cheap hosting account, Haskins may turn it into a hosted service. One option to consider is using <a title="https://www.openshift.com/" href="https://www.openshift.com/">OpenShift Online</a>. OpenShift has free accounts available and is Red Hat&#8217;s public cloud application development and hosting platform.</p>
<p>If you&#8217;d like to know when the plugin is ready for testing, <a title="http://wpstatuspage.com/" href="http://wpstatuspage.com/">WP Status Page</a> has a splash page available where you can enter your email address to receive updates on the <em>project&#8217;s status</em>.</p>
<p>Is this something you&#8217;d be interested in using? What other ideas or features would you like to see in a status page generation plugin? If you already use a service or have custom coded a solution to provide a status page for your project, please share it in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Sep 2014 21:14:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Matt: Five for the Future";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44176";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://ma.tt/2014/09/five-for-the-future/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3121:"<p>On <a href="http://2014.europe.wordcamp.org/">Sunday at WordCamp Europe</a> I got a question about how companies contribute back to WordPress, how they&#8217;re doing, and what companies should do more of.</p>
<p>First on the state of things: there are more companies genuinely and altruistically contributing to growing WordPress than ever before. In our ecosystem web hosts definitely make the most revenue and profits, and it&#8217;s been great to see them stepping up their game, but also the consultancies and agencies around WordPress have been pretty amazing about their people contributions, as demonstrated most recently by the fact the 4.0 and 4.1 release leads both hail from WP agencies (<a href="http://10up.com/">10up</a> and <a href="http://codeforthepeople.com/">Code for the People</a>, respectively).</p>
<p>I think a good rule of thumb that will scale with the community as it continues to grow is that organizations that want to grow the <a href="http://wordpress.org/">WordPress</a> pie (and not just their piece of it) should <strong>dedicate 5% of their people to working on something to do with core</strong> &#8212; be it development, documentation, security, support forums, theme reviews, training, testing, translation or whatever it might be that helps move WordPress mission forward.</p>
<p>Five percent doesn&#8217;t sound like much, but it adds up quickly. As of today <a href="http://automattic.com/">Automattic</a> is 277 people, which means we should have about 14 people contributing full-time. That&#8217;s a lot of people to not have on things that are more direct or obvious drivers of the business, and we&#8217;re not quite there today, but I&#8217;m working on it and hope Automattic can set a good example for this in the community. I think it&#8217;s just as hard for a 20-person organization to peel 1 person off.</p>
<p>It&#8217;s a big commitment, but I can&#8217;t think of a better long-term investment in the health of WordPress overall. <strong>I think it will look incredibly modest in hindsight.</strong> This ratio is probably the bare minimum for a sustainable ecosystem, avoiding the <a href="http://en.wikipedia.org/wiki/Tragedy_of_the_commons">tragedy of the commons</a>. I think the 5% rule is one that all open source projects and companies should follow, at least if they want to be vibrant a decade from now.</p>
<p><strong>Further reading:</strong> There&#8217;s been a number of nice blog follow-ups. Post Status has <a href="http://www.poststat.us/contribution-culture/">a nice post on Contribution Culture</a>. Ben Metcalf responded but <a href="http://benmetcalfe.com/blog/2014/09/wordpress-what-exactly-do-they-get-for-their-5/">I disagree with pretty much everything</a> even though I&#8217;m glad he wrote it. Tony Perez wrote <a href="http://perezbox.com/2014/10/wordpress-the-vision-of-five-and-what-it-means/">The Vision of Five and What it Means</a>. Dries Buytaert, the founder of Drupal, pointed out his essay <a href="http://buytaert.net/scaling-open-source-communities">Scaling Open Source Communities</a> which I think is really good.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Sep 2014 19:05:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: WordPress Beyond Boundaries: A Recap of WordCamp Europe 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31620";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wptavern.com/wordpress-beyond-boundaries-a-recap-of-wordcamp-europe-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9081:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/wceu-2014.jpg" rel="prettyphoto[31620]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/wceu-2014.jpg?resize=1025%2C469" alt="WordCamp Europe 2014 - photo credit: Vladimir Kaladan Petkov" class="size-full wp-image-31627" /></a>WordCamp Europe 2014 &#8211; photo credit: Vladimir Kaladan Petkov
<p>This weekend, 794 WordPress professionals and enthusiasts from all over the world descended upon Sofia, Bulgaria to participate in Europe&#8217;s largest WordCamp to date. WordCampers arrived excited to soak up new information and connect with others in the European community.</p>
<p>Sofia&#8217;s graffiti-lined streets are peppered with leftovers of communist architecture, contrasting the Neo-Bohemian culture that energizes the city. The event was held in the National Palace of Culture, a magnificent venue situated in the center of Bulgaria&#8217;s capital, designed nearly a decade before the fall of the Iron Curtain. Its halls are lined with murals and dark colors, which created an interesting backdrop for a conference devoted to a bright and growing free software community.</p>
<p>The warm hospitality of the organizers of WordCamp Europe lent an intimate atmosphere to what otherwise might have seemed like an impersonally large event. Attendees enjoyed a world class lineup of WordPress speakers and had the opportunity to try delicious local specialties during breaks and lunch.</p>
<h3>Organizing WordCamp Europe 2014</h3>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/wceu-volunteers.jpg" rel="prettyphoto[31620]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/wceu-volunteers.jpg?resize=1025%2C485" alt="wceu-volunteers" class="aligncenter size-full wp-image-31631" /></a></p>
<p>WordCamp Europe is an event that requires many months of planning and an army of volunteers to make it happen. Local organizer <a href="https://twitter.com/petyeah" target="_blank">Petya Raykovska</a> helped to organize WordCamp Sofia&#8217;s 300 attendees last year, in addition to being part of the WCEU organizing team. She commented on how welcoming and helpful the Bulgarian community has been in hosting the event. &#8220;We have a bunch of local volunteers who have been amazing. Everybody wants to help,&#8221; she said. <strong>&#8220;But that is WordPress everywhere, not just in Bulgaria. People in WordPress share these same values in common.&#8221;</strong></p>
<p>Out of the event&#8217;s 950 attendees, 240 were Bulgarian, with the vast majority of others from outside the country. WordCamp Europe is made up of an international team of organizers, strategically chosen to unite the different areas of the Europe. The location of the event changes every year and potential host cities have the opportunity to compete for the spot by submitting a proposal and demonstrating support from the local community, much like the Olympics. This year it was a close competition between Lisbon and Sofia.</p>
<p>&#8220;Any local community that has had a WordCamp before has the opportunity to bid,&#8221; explained <a href="https://twitter.com/DeFries" target="_blank">Remkus de Vries</a>, a leader in the Dutch WordPress community and one of the original organizers of WCEU. &#8220;They have to have experience and know how to manage everything.&#8221;</p>
<p>In its first year, WordCamp Europe was held in Leiden, located in Western Europe. &#8220;It&#8217;s not just who has the best story,&#8221; De Vries commented on the selection process. <strong>&#8220;We have an agenda, and the agenda is to unite Europe as best as we can and to have open source be the vehicle.</strong></p>
<p>&#8220;We picked Sofia because we thought it would be good to have Eastern Europe be a part of it. We have a large WordPress community in Romania, Bulgaria, and a few neighboring countries like Serbia and Croatia,&#8221; he said. For them it&#8217;s relatively easy to come here and we wanted to have them here.&#8221;</p>
<h3>No Boundaries: Uniting People Across Borders with WordPress</h3>
<p>The European WordPress community has a checkered history of division. De Vries and fellow organizers founded the event in 2013, with the hopes of uniting different languages, nationalities, and cultures in a way that only WordPress can.</p>
<p>&#8220;Diversity,&#8221; is the one word answer De Vries gave when asked about the distinguishing characteristics of the community. &#8220;We&#8217;ve had a lot of issues with countries not liking each other in the last seven years, and that, in some regard, is somewhat always there,&#8221; he said. &#8220;<a href="https://twitter.com/zedejose" target="_blank">Zé</a> and I had the idea in 2009/2010 that we should have a European WordCamp, for the simple reason that when we went to the other EU WordCamps, we saw that there was the beginning of people looking outside their borders when it came to the WordPress community.&#8221;</p>
<p>De Vries highlighted a few of the differences that the EU community has to overcome. &#8220;If you just look at the way we write, from the Cyrillic alphabet to the Greek to the Latin ones, that&#8217;s a big difference,&#8221; he said. &#8220;Additionally, there are cultural differences between Eastern, Western, Northern and Southern Europe. Obviously you have stuff like that in America as well but this is truly different in a lot of senses. One of our goals was that the local communities would start looking outside of themselves. That&#8217;s exactly what happened.&#8221;</p>
<p>Prior to the first WordCamp Europe, many across the continent kept to their own small communities and didn&#8217;t often travel to connect with each other. De Vries shared an example of how things have changed:</p>
<blockquote><p>I would say Germany is a beautiful example. Germany is a very close knit community, one of the strongest running and one of the oldest, other than the US. Earlier this year WordCamp Hamburg had many foreigners in attendance. That didn&#8217;t happen in Germany in the past. That&#8217;s the big difference. Now they&#8217;re looking outside.</p></blockquote>
<p>Once everyone comes together around WordPress, differences disappear. &#8220;There&#8217;s a funny thing about the people who enjoy WordPress, in the raw sense of the word, is that they tend to be people who like each other in real life,&#8221; De Vries said. &#8220;Which is why I think WordCamps are such a huge success. I can&#8217;t speak that much for other open source communities but I do have a feeling that that&#8217;s something special about the WordPress community.&#8221;</p>
<p>WordCamp Europe is so well-supported that within two or three days, every single sponsor package was sold out, despite the fact that they weren&#8217;t featured very well in the previous year. Companies are still lining up to offer support, because they recognize the value of a unifying event like this in Europe.</p>
<h3>Looking to the Future of WordCamp Europe</h3>
<p>De Vries and many of the core organizing team are in it for the foreseeable future. He&#8217;s addicted to the high of connecting people who might not otherwise have the opportunity to connect with their peers. &#8220;Yes, it costs a lot of time. I have a busy company as well, but I just think it&#8217;s worth it,&#8221; he said.</p>
<p>Why does he continue to put so much time into WordPress? De Vries put it simply. &#8220;WordPress saved my life. It allowed me to come out of a very dark place to make money to provide for my family at a time when I was experiencing something very rough,&#8221; he said. He wouldn&#8217;t have been able to get there without the community surrounding the project.</p>
<p>&#8220;It is the way the software is structured and the way the community is structured around that,&#8221; he said. &#8220;It makes it very easy to jump in anytime. If you put in the hours and you want to learn and understand what it&#8217;s about and translate that into your work, I would say that WordPress is as good as a community can get. So for me, giving back is also part of that. &#8221;</p>
<p>The first year WordCamp Europe sold 750 tickets. This year it reached 950, despite the fact that travel to Bulgaria is more difficult for some. With the exception of a few direct flights, most everyone else has two or three connecting flights to make it to Sofia. &#8220;To see that the attendance has actually risen, I think is a testament to what we&#8217;re doing here,&#8221; De Vries remarked.</p>
<p>When asked if they will expand the event&#8217;s attendance next year, he replied, &#8220;Maybe 1200 would be nice. I think if we pick a location that&#8217;s even more of a direct flight, attendance could go in that direction.&#8221;</p>
<p>But for De Vries, attendance is of less importance than the unifying power of the WordCamp. <strong>&#8220;Attendance is not the end goal. The goal is people of different countries and backgrounds realizing that, in this community, there are no boundaries.&#8221;</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Sep 2014 14:48:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Matt: No Longer Use TimThumb";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44172";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://ma.tt/2014/09/no-longer-use-timthumb/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:195:"<p>Ben Gillbanks, the co-author of TimThumb, says <a href="http://www.binarymoon.co.uk/2014/07/dont-use-timthumb-instead/">I No Longer Use TimThumb &#8212; Here&#8217;s What I do Instead</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Sep 2014 06:24:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: GoDaddy and Media Temple Engage in Strategic Partnership With WP101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31536";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://wptavern.com/godaddy-and-media-temple-engage-in-strategic-partnership-with-wp101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:13362:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WP101Logo.png" rel="prettyphoto[31536]"><img class="alignright size-full wp-image-31599" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WP101Logo.png?resize=186%2C96" alt="WP101 Logo" /></a>Customers who host sites with <a title="https://www.godaddy.com/" href="https://www.godaddy.com/">GoDaddy</a> or <a title="http://mediatemple.net/" href="http://mediatemple.net/">Media Temple</a> will see a new WordPress resource in their control panel. Thanks to a <a title="https://www.wp101.com/wp101-godaddy-mediatemple/" href="https://www.wp101.com/wp101-godaddy-mediatemple/">strategic partnership</a> with WP101, GoDaddy and Media Temple customers can watch a 20-part WordPress 101 video tutorial series, directly within the WordPress dashboard.</p>
<p>I reached out to <a title="https://www.wp101.com/" href="https://www.wp101.com/">WP101</a> founder, Shawn Hesketh, to learn more about the partnership and what his thoughts are on the state of WordPress training. He also shares the valuable lessons he learned during the process. Near the end of the interview, he provides a list of resources for those interested in learning WordPress.</p>
<h2>Interview With WP101 Founder, Shawn Hesketh</h2>
<p><strong>Jeff &#8211; How difficult has been for you to keep up with WordPress development through your training videos?</strong></p>
<p>To be perfectly honest with you, I was a bit nervous when I first heard Matt Mullenweg <a title="http://wordpress.tv/2013/07/29/matt-mullenweg-state-of-the-word-2013/" href="http://wordpress.tv/2013/07/29/matt-mullenweg-state-of-the-word-2013/">outline a strategy</a> for increasingly rapid releases, eventually leading to constant background updates to WordPress at some point in the near future. But so far, it&#8217;s been fairly manageable, as we&#8217;ve only seen an additional one or two revision cycles in a given year.</p>
<p>I&#8217;ve given a great deal of thought to how we might continue to keep the <a title="https://www.wp101.com/courses/wordpress101/" href="https://www.wp101.com/courses/wordpress101/">WordPress 101 tutorial series</a> up-to-date should WordPress move to more transparent and automatic updates. But for the time being, we should be able to continue updating and re-recording our videos with each major release.</p>
<p>I continually monitor the WordPress development blog, Trac, and the IRC channel, which helps me stay abreast of coming changes and prepare ahead of time as much as possible. Without access to those invaluable resources, it would be quite a challenge.</p>
<p><strong>Jeff &#8211; As WordPress continues to grow, WordPress Training continues to be a business in high demand. How have you differentiated yourself from the other trainers/coaches out there?</strong></p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/CMSMarketShareWordPress.png" rel="prettyphoto[31536]"><img class="size-full wp-image-31603" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/CMSMarketShareWordPress.png?resize=698%2C291" alt="CMS MarketShare report" /></a>Marketshare via OpensourceCMS.com 9/29/2014
<p>It certainly helps that WP101 was one of the first WordPress video tutorial series to be launched, way back in 2008, at a time when almost no one was providing high-quality WordPress tutorial videos. Since then, we&#8217;ve certainly seen a number of other sites emerge to address the growing need for WordPress education, not only for beginners, but also intermediate and advanced users.</p>
<p>Still, the feedback I receive almost daily is that the WP101 videos are some of the best-produced, easy-to-follow video tutorials for beginners. I&#8217;ve spoken about this in the past, but I maintain that fanatical attention to detail and careful craftsmanship can still help differentiate you from competitors, no matter what product or service you provide.</p>
<p>Finally, I don&#8217;t create my tutorials in a vacuum. Rather than simply producing what <strong>I</strong> think will work best, I&#8217;m constantly listening to input and feedback from our audience, developers, and beginners alike revising the WP101 series, improving it with each release. I think it&#8217;s this commitment to building meaningful, long-term relationships and serving our audience that continues to set WP101 apart.</p>
<p><strong>Jeff &#8211; What challenges did you face in making this strategic partnership a reality?</strong></p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WP101-GoDaddy-MediaTemple.jpg" rel="prettyphoto[31536]"><img class="size-full wp-image-31601" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WP101-GoDaddy-MediaTemple.jpg?resize=900%2C500" alt="WP101 Partnership" /></a>Image Courtesy of WP101
<p>The partnership with GoDaddy and Media Temple is a great example of the importance of long-term relationship building. We spent the first several weeks in conversations about the challenges they faced with regard to on-boarding new WordPress users. It was only after I had a clear understanding of their challenges that we began to explore the best way to put the WP101 videos to work for their customers.</p>
<p>Although it may appear on the surface to be a relatively simple solution, it was actually the product of several months of hard work, both in terms of developing the custom software required and arriving at a pricing model that worked for both parties.</p>
<p>To be honest, I didn’t expect the process to take several months to fully materialize, but this was never about a quick win. From the beginning, we were all working toward the best solution, not just for our two companies, but ultimately for their customers.</p>
<p><strong>Jeff &#8211; Did you learn any lessons that others can use when trying to partner with large, well-established brands and or companies?</strong></p>
<p><em>Have patience</em>. Don&#8217;t underestimate the amount of time you (or your legal team) will spend carefully crafting an agreement that is truly a win/win.</p>
<p>It&#8217;s true that the best agreements are those in which <em>both</em> parties feel that they came out ahead. But as with anything of lasting value, it takes time. Time spent in conversations that results in a clear understanding of the desired outcome. Time spent carefully crafting a custom solution, rather than simply applying a quick fix. And throughout the entire process, keeping an eye firmly fixed on the end goal, which is ultimately to better serve the customer.</p>
<p><em>Communicate clearly</em>. When there are large teams of people involved, it&#8217;s easy to get lines crossed. I’m a big fan of UIHD (<a title="http://unlessiheardifferently.com/" href="http://unlessiheardifferently.com/">Unless I Hear Differently</a>). It helps everyone involved stay crystal clear on roles and timeframes, who’s doing what, and when. It helps eliminate downtime due to unnecessary communication cycles. Keep emails simple, limited to just one question at a time, and close every communication with, &#8220;<em>Unless I hear differently…</em>&#8221;</p>
<p>Finally, don&#8217;t underestimate the importance of finding a great attorney, which also takes time. I&#8217;ve worked with general business attorneys in the past, but it&#8217;s another matter altogether to find an attorney who understands the intricacies of licensing intellectual property for online distribution. I went through several recommendations before finally finding a local attorney who had the understanding and expertise to craft the agreement we needed.</p>
<p><strong>Jeff &#8211; Last but not least, when you take a step back and look at the big picture, what do you see in terms of the WordPress training landscape?</strong></p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/LandscapeHorizon.png" rel="prettyphoto[31536]"><img class="size-full wp-image-31602" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/LandscapeHorizon.png?resize=638%2C280" alt="Landscape WordPress Training Horizon" /></a>photo credit: <a href="https://www.flickr.com/photos/jixxer/8238528131/">Kristofer Williams</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a>
<p>It&#8217;s an exciting time to be a WordPress educator. The increasing popularity of WordPress means there is also a growing demand for WordPress training. There have never been more educational resources available for nearly every level of expertise.</p>
<p>From written tutorials and code snippets on individual blogs to personalized, one-on-one coaching, there is a wide variety of training available for just about every learning style. The WordPress community is filled with knowledgeable, friendly people who are willing to share their knowledge with others.</p>
<p>But with so many resources out there, it can also be challenging, particularly for beginners, to separate the good from the bad. How do you know whether a tutorial is accurate, reliable, or up-to-date?</p>
<p>With powerful tools like <a title="http://screenflow.en.softonic.com/mac" href="http://screenflow.en.softonic.com/mac">ScreenFlow</a> and <a title="http://www.techsmith.com/camtasia.html" href="http://www.techsmith.com/camtasia.html">Camtasia</a>, it’s never been easier to create screencast tutorials. But it&#8217;s increasingly difficult to ensure they’re continually up to date with each new release of WordPress.</p>
<p>In the six years since I launched WP101, I&#8217;ve updated and re-recorded my WordPress 101 series <strong>12 times</strong>. During that same period of time, I’ve seen several tutorial sites come and go. Their content becomes out-of-date after just one or two release cycles. As I mentioned earlier, it’s only going to become more challenging as WordPress continues to release updates more rapidly.</p>
<p>So, it’s hard work, and quite tedious at times, but for those of us who truly enjoy the reward of teaching others how to use WordPress, it’s also a labor of love. But one of the things that excites me the most is the spirit of “co-opetition” that exists in the WordPress community.</p>
<h3>Resources Hesketh Recommends for Learning WordPress</h3>
<p>Some people learn best by reading. So I often recommend the excellent books by <a title="http://www.amazon.com/WordPress-Web-Developers-Introduction-Professionals/dp/1430258667" href="http://www.amazon.com/WordPress-Web-Developers-Introduction-Professionals/dp/1430258667">Stephanie Leary</a>, <a title="http://lisasabin-wilson.com/books/" href="http://lisasabin-wilson.com/books/">Lisa Sabin-Wilson</a>, or <a title="http://www.amazon.com/Professional-WordPress-Development-Brad-Williams/dp/111844227X" href="http://www.amazon.com/Professional-WordPress-Development-Brad-Williams/dp/111844227X">Brad Williams and team</a>.</p>
<p>Others learn best through one-on-one training, so I send them to <a href="http://bobwp.com">BobWP</a>.</p>
<p>There&#8217;s the ever-growing library of <a href="http://webdesign.com">web design webinars</a> by my friends at iThemes.</p>
<p>I’m excited about the possibilities of <a href="http://www.sidekick.pro">SIDEKICK</a> for helping developers to create custom interactive walkthroughs.</p>
<p>Nobody has a larger library of written tutorials than <a href="http://www.wpbeginner.com">WPBeginner</a>.</p>
<p>Of course, there are plugins like <a href="http://www.videousermanuals.com">Video User Manuals</a>, or our own <a href="http://wp101plugin.com">WP101 Plugin</a> that enable developers to provide WordPress tutorials directly in their clients&#8217; dashboard.</p>
<p>To say nothing of learning sites like <a href="http://Lynda.com">Lynda.com</a> or <a href="http://teamtreehouse.com">Treehouse</a>.</p>
<p>With our new partnership with GoDaddy and Media Temple, we’re starting to provide valuable WordPress training right where customers need it most, in their own WordPress dashboard.</p>
<p>Not a day goes by that I don’t recommend one or more of these excellent learning resources if I feel they might be the best fit for someone and many, if not all, of these folks do the same for WP101. This creates an environment in which everyone wins. Most importantly the individuals who just want to learn how to use WordPress to build a gorgeous blog or compelling business site.</p>
<p>In a perfect world, WordPress would be so intuitive where no training or manual would be required. Until then, we’ll be there to help fill in the gaps, answer questions, and help folks learn how to use WordPress as quickly as possible.</p>
<h2>A Win-Win Situation</h2>
<p>As the WordPress training scene becomes increasingly crowded, it&#8217;s becoming more difficult to differentiate between all of the resources available. Partnering with a webhosting company is an excellent way for WordPress training materials to be seen by thousands of customers who might not otherwise be aware of their existence.</p>
<p>The material also provides an opportunity to lessen the support burden. As customers learn the basics of WordPress, the support team can dedicate more resources towards difficult support queries.</p>
<p>If you&#8217;re a GoDaddy or Media Temple customer, let us know what you think of the videos in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 29 Sep 2014 21:31:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"WPTavern: Ben Gillbanks Announces The End of TimThumb";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31588";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wptavern.com/ben-gillbanks-announces-the-end-of-timthumb";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5202:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/TimThumbEndsFeaturedImage.png" rel="prettyphoto[31588]"><img class="size-full wp-image-31592" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/TimThumbEndsFeaturedImage.png?resize=637%2C289" alt="TimThumb Ends Development " /></a>photo credit: <a href="https://www.flickr.com/photos/katy_bird/6661402027/">katybird</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a>
<p>The once popular image resizing script known as TimThumb is <a title="http://www.binarymoon.co.uk/2014/09/timthumb-end-life/" href="http://www.binarymoon.co.uk/2014/09/timthumb-end-life/">no longer supported</a> according to co-creator, Ben Gillbanks. In 2011, <a title="http://www.binarymoon.co.uk/2011/08/timthumb-2/" href="http://www.binarymoon.co.uk/2011/08/timthumb-2/">TimThumb made headlines</a> when a major security vulnerability was discovered and used to hack into several websites.</p>
<blockquote><p>The exploit that was found was a bug with the external image resize functionality and the fact it could be used to download and execute files. There was code in place that restricted the downloads to a whitelist of clean sites, but it wasn’t strict enough and so a hole was found that could inject php onto your server.</p></blockquote>
<p>In 2009, <a title="http://www.binarymoon.co.uk/2009/07/a-brief-history-of-timthumb/" href="http://www.binarymoon.co.uk/2009/07/a-brief-history-of-timthumb/">Gillbanks estimated</a> that 95% of commercial WordPress themes supported TimThumb. Several major commercial theme companies such as WooThemes, <a title="http://www.woothemes.com/2011/08/timthumb-security-flaw-patch/" href="http://www.woothemes.com/2011/08/timthumb-security-flaw-patch/">used the script</a> in most of its products. This set the stage for thousands of sites to be affected by the vulnerability.</p>
<p>The outcome of the event has weighed heavily on Gillbanks and is one of the primary reasons he&#8217;s giving up development.</p>
<blockquote><p>In particular in 2010 there was <a href="http://www.binarymoon.co.uk/2011/08/timthumb-2/">a major security exploit</a> found and it hurt a lot of websites, my own included. There are still people who are suffering because of it. I’ve felt incredibly guilty about this for years now, and so my enthusiasm for TimThumb has dropped to nothing.</p>
<p>Because of this lack of enthusiasm, and a fear of doing something else wrong, I have barely touched the code in years.</p></blockquote>
<p>If you&#8217;re using TimThumb, Gillbanks <a title="http://www.binarymoon.co.uk/2014/07/dont-use-timthumb-instead/" href="http://www.binarymoon.co.uk/2014/07/dont-use-timthumb-instead/">recommends removing it</a> and using something else. An excellent alternative is the <a title="http://matthewruddy.github.io/Wordpress-Timthumb-alternative/" href="http://matthewruddy.github.io/Wordpress-Timthumb-alternative/">WordPress TimThumb Alternative</a> on Github. Created by Matthew Ruddy, the function uses WordPress&#8217; native resizing functions to mimic TimThumb resizing.</p>
<h2>Timeline of Notable Events</h2>
<p>The following is a timeline of notable events surrounding TimThumb. Feel free to add more in the comments.</p>
<ul>
<li>March 27th, 2008 &#8211; TimThumb added to <a title="https://code.google.com/p/timthumb/source/list?num=25&start=20" href="https://code.google.com/p/timthumb/source/list?num=25&start=20">Google Code</a></li>
<li>July 6th, 2009 &#8211; Ben Gillbanks <a title="http://www.binarymoon.co.uk/2009/07/a-brief-history-of-timthumb/" href="http://www.binarymoon.co.uk/2009/07/a-brief-history-of-timthumb/">takes over development</a> of the script</li>
<li>August 1st, 2011 &#8211; Mark Mauder reports a major vulnerability in TimThumb and <a title="http://markmaunder.com/2011/08/01/zero-day-vulnerability-in-many-wordpress-themes/" href="http://markmaunder.com/2011/08/01/zero-day-vulnerability-in-many-wordpress-themes/">releases WordThumb</a>, a fork of TimThumb with the necessary patched files. The patches are merged into TimThumb during the development of 2.0</li>
<li>August 8th, 2011 &#8211; Matt Mullenweg <a title="http://ma.tt/2011/08/the-timthumb-saga/" href="http://ma.tt/2011/08/the-timthumb-saga/">chimes in</a> on the TimThumb saga</li>
<li>August 11th, 2011 &#8211; <a title="http://www.binarymoon.co.uk/2011/08/timthumb-2/" href="http://www.binarymoon.co.uk/2011/08/timthumb-2/">TimThumb 2.0 Released</a></li>
<li>June 24th, 2014 &#8211; Zero-Day vulnerability <a title="http://wptavern.com/wordpress-security-alert-new-zero-day-vulnerability-discovered-in-timthumb-script" href="http://wptavern.com/wordpress-security-alert-new-zero-day-vulnerability-discovered-in-timthumb-script">discovered</a> in TimThumb script dealing with Webshots</li>
<li>September 27th, 2014 &#8211; Ben Gillbanks announces that he will no longer support or maintain TimThumb</li>
</ul>
<p>With the development of TimThumb being discontinued, it&#8217;s the end of an era for WordPress theme development. Are you happy or sad to see it go? Since TimThumb has an open source license, will developers pick up where Gillbanks left off?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 29 Sep 2014 19:19:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Matt: Hemingway on Writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44162";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://ma.tt/2014/09/hemingway-on-writing/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:664:"<blockquote><p>I believe that basically you write for two people; yourself to try to make it absolutely perfect; or if not that then wonderful. Then you write for who you love whether she can read or write or not and whether she is alive or dead.</p></blockquote>
<p><cite>&#8212; Ernest Hemingway to Arthur Mizener, 1950 Selected Letters, p. 694.</cite></p>
<p>I got it from <a href="http://smile.amazon.com/dp/B000FC0O1I/">Hemingway on Writing</a> which is a short and pleasant read I&#8217;m going through right now. It turns out <a href="http://ma.tt/2014/01/intrinsic-blogging/">Hemingway was 64 years ahead of me in his advice about who to write for</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 29 Sep 2014 13:46:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"Lorelle on WP: Research on the WordPress, Web Development, and Web Design Job Market";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"http://lorelle.wordpress.com/?p=11928";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:108:"http://lorelle.wordpress.com/2014/09/29/research-on-the-wordpress-web-development-and-web-design-job-market/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:499:"In 2012 and 2013, I did extensive research for the grant program to develop and rewrite the Web Developer degree program at Clark College. This research included an analysis of current and future job opportunities for students graduating with that degree with a solid understanding of WordPress. Now that the program has completed its first [&#8230;]<img alt="" border="0" src="http://pixel.wp.com/b.gif?host=lorelle.wordpress.com&blog=72&post=11928&subd=lorelle&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 29 Sep 2014 11:35:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Lorelle VanFossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: Meet John Blackbourn, WordPress 4.1 Release Lead";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31547";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wptavern.com/meet-john-blackbourn-wordpress-4-1-release-lead";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5717:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/john-blackbourn.png" rel="prettyphoto[31547]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/john-blackbourn.png?resize=1025%2C473" alt="John Blackbourn speaking at WordCamp London 2013 - WordPress.tv" class="size-full wp-image-31552" /></a>John Blackbourn speaking at WordCamp London 2013 &#8211; <a href="http://wordpress.tv/2014/02/28/john-blackbourne-developing-for-the-new-media-manager/">WordPress.tv</a>
<p>Nine years ago, <a href="https://johnblackbourn.com/" target="_blank">John Blackbourn</a> was stocking shelves at a supermarket 40 hours per week and returning home to do another 20 hours of freelance work on the side. His journey with WordPress started much like many others, when his first patch was accepted seven years ago. This past weekend at WordCamp Europe, Blackbourn was named <a href="https://make.wordpress.org/core/2014/09/27/john-blackbourn-is-leading-wordpress-4-1-and-announcing-new-committers/" target="_blank">WordPress 4.1 release lead</a>.</p>
<p>&#8220;I&#8217;m sure my first contribution was because I found a bug that annoyed me, so I thought I&#8217;ll patch that up and get it in there,&#8221; he said. Submitting bug reports led him to learn about Subversion, patching files, and the trac ticket manager. &#8220;That&#8217;s actually a great way for people to get into version control &#8211; when someone turns around and says &#8216;Write a patch for it,&#8217; and you have to go off and figure out how to do it.&#8221;</p>
<p>It started off as a hobby, Blackbourn said, &#8220;building my own websites and playing around a bit.&#8221; After awhile his freelance work started to take off. &#8220;Then I was lucky enough to be able to drop my hours down to part time while I ramped up my freelance work,&#8221; he said. A couple years later, he got a job at <a href="http://codeforthepeople.com/" target="_blank">Code For The People</a>, a WordPress development agency and WordPress.com VIP partner.</p>
<p>Code for the People is made up of a flock of regular contributors to WordPress core, with founders who are passionately committed to giving back to open source software. When Blackbourn was put forward to lead the 4.1 release, his agency was behind him 110%.</p>
<p>&#8220;I had previously talked to Andrew Nacin about leading 3.9 and 4.0 and he&#8217;d already spoken to my bosses at Code For The People. They said, &#8216;Yeah go for it &#8211; we&#8217;ll give you time off work, adequate resources, and time to lead it.\'&#8221;</p>
<p>Simon Wheatley, one of the founders of CFTP, spoke at WordCamp Europe about running an open source business, during which his co-founder, Simon Dickson, <a href="https://twitter.com/simond/status/515834467781730304" target="_blank">commented</a> on donating Blackbourn&#8217;s time to core. <strong>&#8220;CFTP is a small team. Contributing John Blackbourn to WP Core won&#8217;t make our lives easy. But it&#8217;s important to us. We&#8217;ll find a way,&#8221;</strong> he said.</p>
<h3>What&#8217;s on the horizon for WordPress 4.1?</h3>
<p>This will be the first time that Blackbourn has led a release, although he has been a core committer for both 3.9 and 4.0. WordPress 4.1 will be a short release cycle, with less than three months, due around December 12th. He shared a few ideas with us about where he thinks 4.1 will be heading.</p>
<blockquote><p>We&#8217;re going to try to reign in expectations for the release so we&#8217;re going to get a few nice things to do with session management and password security, etc. If we keep the potential features reigned in a bit, then hopefully we won&#8217;t be needing to take weeks off work. I expect to be doing a couple days a week that I would normally be working.</p></blockquote>
<p>Blackbourn hopes to further extend the improvements to sessions that were made in the previous release. &#8220;The new thing in WP 4.0 is the sessions &#8211; when you log in, you actually get assigned a session now, so you can forcibly log one of your sessions out,&#8221; he explained. &#8220;So if I&#8217;m logged in on my laptop and my phone I can kick myself out of one or the other.&#8221; This now exists in WordPress on an API level and Blackbourn is hopeful that 4.1 will add a UI for it.</p>
<p>He has extensive experience working with multisite on a daily basis at CFTP. &#8220;We haven&#8217;t got many clients who don&#8217;t use multisite these days,&#8221; he said. When asked if there are any multisite improvements planned for 4.1, he said that there may not be much time to make significant strides on the <a href="https://make.wordpress.org/core/2013/10/06/potential-roadmap-for-multisite/" target="_blank">roadmap</a>. However, he&#8217;s optimistic about including improvements related to <a href="http://wptavern.com/wordpress-4-0-targeted-to-fix-multisite-new-user-password-security-issues" target="_blank">multisite password resets</a>.</p>
<p>Since it&#8217;s his first time to lead a release, Blackbourn plans to meet with several past release leads in attendance at WordCamp Europe in order to get an overview of how it&#8217;s done. He&#8217;s one of the most humble, talented people I had the privilege of meeting at the event. <a href="http://wptavern.com/query-monitor-a-remarkably-comprehensive-debugging-plugin-for-wordpress" target="_blank">Query Monitor</a>, his comprehensive WordPress debugging plugin, is truly a work of art, and many developers can no longer live without it. Blackbourn is a benefit to the project and an excellent example of a WordPress professional who has become a high-end expert by sharpening his skills through contribution to core.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 28 Sep 2014 22:18:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"Matt: 4.0 Recap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44167";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:31:"http://ma.tt/2014/09/4-0-recap/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:410:"<p>If you want to see some of the thought and care that went into the <a href="https://wordpress.org/news/2014/09/benny/">WordPress 4.0 release</a>, check out <a href="http://scotty-t.com/2014/09/04/wordpress-4-0-under-the-hood/">Scott Taylor&#8217;s peek under the hood</a> and <a href="http://helenhousandi.com/2014/09/wordpress-4-0-an-easter-egg/">Helen Hou-Sandi&#8217;s reveal of a 4.0 Easter egg</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 28 Sep 2014 05:10:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Matt: Sedaris on Fitbit";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44160";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:39:"http://ma.tt/2014/09/sederis-on-fitbit/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:229:"<p><a href="http://www.newyorker.com/magazine/2014/06/30/stepping-out-3">David Sedaris in the New Yorker on how his Fitbit took over his life.</a>. <cite>Hat tip: <a href="http://jeremeyduvall.com/">Jeremey Duvall</a>.</cite></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 27 Sep 2014 12:03:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"WPTavern: WPWeekly Episode 163 – Interview With Andrea Middleton of WordCamp Central";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=31451&preview_id=31451";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wptavern.com/wpweekly-episode-163-interview-with-andrea-middleton-of-wordcamp-central";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3942:"<p>In this episode,<a title="http://marcuscouch.com/" href="http://marcuscouch.com/"> Marcus Couch</a> and I are joined by <a title="http://wine-scamp.com/" href="http://wine-scamp.com/">Andrea Middleton</a> who manages <a title="http://central.wordcamp.org/" href="http://central.wordcamp.org/">WordCamp Central</a>. She tells us what it means to be a &#8220;dot organizer&#8221; within Automattic and what her day to day duties are managing WordCamp Central. We discuss whether the WordCamp Guidelines allow for differentiation between WordCamps. Middleton explains the various initiatives in place to help first-time organizers with planning their event. Last but not least, we talk about the importance of sponsorships and how they&#8217;ve enabled WordCamps to be affordable to the general public.</p>
<p><strong>WordCamp Resource Material</strong>:</p>
<ul>
<li><a title="http://central.wordcamp.org/schedule/" href="http://central.wordcamp.org/schedule/">Upcoming WordCamps</a></li>
<li><a title="http://plan.wordcamp.org/" href="http://plan.wordcamp.org/">WordCamp Planning Site</a></li>
<li><a title="http://plan.wordcamp.org/forums/" href="http://plan.wordcamp.org/forums/">WordCamp Forums</a></li>
</ul>
<h2>Stories Discussed:</h2>
<p><a title="http://wptavern.com/buddypress-2-1-patsy-released" href="http://wptavern.com/buddypress-2-1-patsy-released">BuddyPress 2.1 Patsy Released</a><br />
<a title="http://wptavern.com/ithemes-suffers-security-breach-customers-urged-to-reset-passwords" href="http://wptavern.com/ithemes-suffers-security-breach-customers-urged-to-reset-passwords">iThemes Suffers Security Breach, Customers Urged To Reset Passwords</a><br />
<a title="http://wptavern.com/netropolitan-facebook-for-rich-people-is-powered-by-wordpress-and-buddypress" href="http://wptavern.com/netropolitan-facebook-for-rich-people-is-powered-by-wordpress-and-buddypress">Netropolitan “Facebook for Rich People” is Powered by WordPress and BuddyPress</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a title="https://wordpress.org/plugins/admin-branding/" href="https://wordpress.org/plugins/admin-branding/">Admin Branding</a> &#8211; Completely brand the admin dashboard and login screen through easy and straight forward controls. You can do advanced customizations and branding by adding your own CSS and JavaScript. Fits both regular users and developers.</p>
<p><a title="https://wordpress.org/plugins/coursepress/" href="https://wordpress.org/plugins/coursepress/">CoursePress</a> &#8211; CoursePress turns WordPress into a powerful online learning platform. Set up online courses by creating learning units with quiz elements, video, audio etc. You can also assess student work, sell your courses and much more.</p>
<p><a title="https://wordpress.org/plugins/widget-menuizer/" href="https://wordpress.org/plugins/widget-menuizer/">Widget Menuizer</a> &#8211; Widget Menuizer makes it possible to embed sidebars within your site&#8217;s menus. Anything you can do with a widget can now be done inside your menus. This makes the menu system much more powerful, as it allows for easy creation of sophisticated &#8220;mega dropdowns&#8221; and other menu fanciness without completely overhauling the menu management system into something unfamiliar.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, October 1st 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #163:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 27 Sep 2014 01:39:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WPTavern: Reader Poll: What Are Your Favorite Features In WordPress 4.0?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31525";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://wptavern.com/reader-poll-what-are-your-favorite-features-in-wordpress-4-0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2166:"<p>Since the release of WordPress 4.0, users have had nearly a month to get used to its new features. It&#8217;s time to find out which ones are your favorite. My favorite features are the sticky toolbar, oEmbed previews in the visual editor, and the overall improvements to the writing experience. I&#8217;ve found the sticky toolbar is especially useful on smaller screens.</p>
<p>If you select not listed, please use the comments to tell us what it is.</p>
Note: There is a poll embedded within this post, please visit the site to participate in this post\'s poll.
<h2>WordPress 4.1 Development to Kickoff on Monday</h2>
<p>As we get used to the improvements in 4.0, development on WordPress 4.1 is <a title="https://make.wordpress.org/core/2014/09/26/announcement-4-1-kickoff-meeting-this-monday-september-29/" href="https://make.wordpress.org/core/2014/09/26/announcement-4-1-kickoff-meeting-this-monday-september-29/">about to get underway</a>. The first meeting to discuss WordPress 4.1 will be on Monday, September 29, at 1400 UTC. Also note that the Wednesday meeting (October 1) is still on for 2000 UTC as well. Since time zones can be difficult to figure out, Andrew Nacin provided further clarification on the exact time.</p>
<ul>
<li>10am U.S. Eastern (GMT-4), 7am U.S. Pacific (GMT-7).</li>
<li>This is midnight Tuesday for the East Coast of Australia (GMT+10).</li>
<li>If you’re at WordCamp Europe’s contributor day (GMT+3), this will be 5pm.</li>
</ul>
<p>The meeting takes place on IRC in the #<strong>wordpress-dev</strong> channel. If you don&#8217;t have access to an IRC client, you can use a web-based client at <a title="http://webchat.freenode.net/" href="http://webchat.freenode.net/">webchat.freenode.net</a>. If there is a particular feature you&#8217;d like to see in 4.1 or have a plugin you&#8217;d like to see merged into core, say so in the meeting or within the <a title="https://make.wordpress.org/core/2014/09/26/announcement-4-1-kickoff-meeting-this-monday-september-29/" href="https://make.wordpress.org/core/2014/09/26/announcement-4-1-kickoff-meeting-this-monday-september-29/">comment section</a> of the announcement.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 26 Sep 2014 21:56:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: WordPress.com Publishes First Ever Video Ad Entitled “Welcome Home”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31515";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://wptavern.com/wordpress-com-publishes-first-ever-video-ad-entitled-welcome-home";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4258:"<p>WordPress.com released a new video on its <a title="https://www.youtube.com/channel/UCiR2d9r3QkBwuNVS8nqGNgg" href="https://www.youtube.com/channel/UCiR2d9r3QkBwuNVS8nqGNgg">YouTube account</a> entitled <a href="https://www.youtube.com/watch?v=MfW2UJMIQvQ&feature=youtu.be"><strong>Welcome Home</strong></a>. In the 15 second video, featuring music from <a title="http://childishgambino.com/" href="http://childishgambino.com/">Childish Gambino</a>, photos are taken with a iPhone in various locations. Near the end of the video, the WordPress app is opened displaying a post with one of the images captured by the phone. The central theme of the video is to <strong>create your home on the web at <a title="http://wordpress.com/" href="http://wordpress.com/">WordPress.com</a></strong>.</p>
<p><span class="embed-youtube"></span></p>
<p>My initial reaction to the video is that it puts too much emphasis on photos. It makes it seem like the WordPress app is only capable of sharing photos similar to <a title="https://www.flickr.com/" href="https://www.flickr.com/">Flickr</a> or <a title="http://instagram.com/#" href="http://instagram.com/">Instagram</a>. A home on the web has more than just photos, something that doesn&#8217;t come across in the 15 second message.</p>
<p>Something else I find odd is the choice to highlight the app versus WordPress.com. There&#8217;s no mention or video of the WordPress.com user interface or other aspects of the site. As WordPress.com likes to do, this video is likely an experiment but in my opinion, fails to deliver on their central message. It&#8217;s aimed at too narrow of an audience and doesn&#8217;t adequately show off what WordPress.com is truly capable of. Granted, we&#8217;re talking about 15 seconds of video which is why I&#8217;d like see what the team creates if given one minute to get the point across.</p>
<p>Just for the sake of comparison, watch this SquareSpace ad. It&#8217;s a minute long, more to the point, and delivers on the message of creating a home on the web or in this case, creating your own space. The ad also does a good job of showing how the service can be used on various devices. When I watch this ad, I feel like people from all walks of life are able to easily create a site through SquareSpace.</p>
<p><span class="embed-youtube"></span></p>
<h2>Jon Burke Provides Context For The Video</h2>
<p>In an effort not to cloud my judgement and reaction to the video, I reached out to Jon Burke, who works for Automattic, after publishing this post and received more information concerning the video.</p>
<p><strong>Is the video actually a commercial or more or less an experiment?</strong></p>
<p>WordPress.com has a freemium model and we run house ads. We have been running this video as a promotion on free sites. This video is part of a series. This video focuses on the utility of photos and the mobile apps. Other videos we are producing will focus on other aspects of WordPress.com.</p>
<p>The video is brief for a couple of reasons. We don&#8217;t want to interrupt the site viewers&#8217; experience for too long and we wanted it to be viewable by our visitors where English is not the primary language.</p>
<p>So it is a commercial, but we are also experimenting with different videos about WordPress.com to see how we can best get our message out in a way that is organic with the culture of Automattic and the WordPress community.</p>
<p><strong>Is it aimed towards raising awareness of the WordPress mobile app or WordPress.com?</strong></p>
<p>This video is focused on our mobile apps. The comparison to the SquareSpace video is a fair one but our ambition is to get our message across better in a dozen videos rather than in a single, longer video. We create a lot of products and have a number of services and don&#8217;t think we can cover it all well in a single short video.</p>
<h2>Now It Makes Sense</h2>
<p>The explanation provided by Burke provides the missing context surrounding the video. The video now makes perfect sense in that it&#8217;s part of a series with plans to produce more like it focusing on other areas of WordPress.com. This information completely changes my tune. Instead of failing to deliver the message, it&#8217;s on point.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 26 Sep 2014 20:02:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:94:"WPTavern: Ryan Hellyer’s AWS Nightmare: Leaked Access Keys Result in a $6,000 Bill Overnight";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31497";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://wptavern.com/ryan-hellyers-aws-nightmare-leaked-access-keys-result-in-a-6000-bill-overnight";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9568:"<p>WordPress developer <a href="http://geek.ryanhellyer.net/" target="_blank">Ryan Hellyer</a> had always wanted to open source his website. As a strong supporter of open source software and an avid plugin developer, he enjoys sharing his code and learning from others. This desire led him to put his site up on GitHub one evening, not knowing that he would wake to find himself in a security nightmare due to a simple oversight.</p>
<p>Open sourcing a website is not such an uncommon practice, as it brings with it a number of benefits. Hellyer shared his story with the Tavern and identified the main reasons wanted to make his site&#8217;s code public on GitHub:</p>
<ol>
<li>It allows people to see what plugins and themes I use</li>
<li>It makes it super easy to get help with my website, since people can see the code</li>
<li>It encourages me to use best practices across my entire website, not just the bits I post for download (custom plugins, themes etc.)</li>
<li>It is a handy way to sync the files between locations</li>
</ol>
<p><strong>&#8220;I was aware that keeping my wp-config.php file off of GitHub was critical,&#8221;</strong> Hellyer said.</p>
<p>&#8220;Leaving that open for download would also make my database credentials, security salts etc. known to attackers. To mitigate this, I simply moved it one folder down (it still works even when it&#8217;s not in the root of your site). As a double protection, I also used the .gitignore file to forcibly prevent Git from pushing it to the repository.&#8221;</p>
<p>Satisfied that his website was totally backed up and thinking that he had taken all the necessary security precautions, Hellyer pushed all the contents of his site (with the exception of the uploads directory) to a new GitHub repository. Pleased with his efforts, he dozed off to sleep.</p>
<h3>An Urgent Message Arrives from Amazon</h3>
<p>Not four hours later, Hellyer received an urgent message from Amazon, though he didn&#8217;t have the chance to read it until later in the morning.</p>
<p>&#8220;I awoke fresh the next morning, began work for the day, then decided to check my personal email account and saw the email I had received overnight,&#8221; he said. &#8220;The email was marked URGENT.&#8221;</p>
<p>Hellyer initially thought it was spam but went with his instinct and opened it anyway, as it appeared to be fairly legitimate. Amazon emailed to notify him that his account may have been compromised.</p>
<p>&#8220;I immediately went to check my AWS billing page, but thankfully it was only at US$17 for the month so far, which was about my normal usage,&#8221; he said, noting that he uses AWS (Amazon Web Services) for backing up to Amazon S3 and for providing a CDN service to his website (via Amazon Cloudfront).</p>
<p>The email specifically asked him to check his EC2 instances, which Hellyer found to be odd, since he doesn&#8217;t even use Amazon EC2.</p>
<p>&#8220;I checked anyway, and surprisingly, here were 80+ servers running. I thought &#8216;OHHH CRAP!&#8217;</p>
<p>&#8220;So I shut them all down. Problem solved I thought, and since my bill was still looking normal I figured it wasn&#8217;t a problem.&#8221;</p>
<p>Ten minutes later Hellyer discovers another 80+ servers running at a different location on EC2. Digging deeper, he found five more locations, all with 80+ servers running. After fully auditing his account, he found more sections of &#8220;reserved instances&#8221; with even more servers running.</p>
<p><strong>&#8220;In total, there seemed to be around 600 servers running. The time between realizing all this and uploading my Git repository was approximately 12 hours.&#8221;</strong></p>
<h3>Digging Out of a Hole</h3>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/emergency.jpg" rel="prettyphoto[31497]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/04/emergency.jpg?resize=1024%2C482" alt="photo credit: Code & Martini by Ivana Vasilj - cc license" class="size-full wp-image-21873" /></a>photo credit: <a href="https://flic.kr/p/dLUWMb">Code &#038; Martini</a> by <a href="https://www.flickr.com/photos/ivanavasilj/">Ivana Vasilj</a> &#8211; cc license
<p>Hellyer went into damage control mode, scrambling to find the source of the problem.</p>
<p>&#8220;My immediate thought was &#8216;YOU IDIOT! You didn&#8217;t remove the wp-config.php file which contains AWS access keys!&#8217; he said. &#8220;But I went to check the repository, and it was not there. It turned out though, that there was another file called &#8216;wp-config.php.save,&#8217; which DID contain my AWS access keys.&#8221;</p>
<p>That file also contained his database password and security salts, but so far he hasn&#8217;t found any indication that the site was compromised by those. Hellyer immediately changed the password and swapped out the config keys.</p>
<p><strong>&#8220;But those horrid little AWS access keys were sitting on the repository in view of everyone. I immediately deleted the entire repository from GitHub.&#8221;</strong></p>
<p>Unfortunately, it took him two hours to delete all of the Amazon EC2 instances created by the exploited keys. &#8220;The evil little blighters had cranked up the security protection and actually made it very awkward to shut them all down,&#8221; he explained. &#8220;I wasn&#8217;t able to just terminate them and in fact had to go through one by one and manually turn off termination protection, then stop them, then terminate them. Then I had to go through and delete many volumes which had been setup (I think this is the EC2 equivalent of a drive).&#8221;</p>
<h3>Hellyer is Slapped with a $6,000 Bill for Unauthorized Usage</h3>
<p>AWS bills don&#8217;t update in real time, and Hellyer&#8217;s bill still read $17 USD. After contacting support to find out the damage, he saw his bill jump from $17 to $3,087.97. AWS was helpful throughout the process and give him a list of tasks to complete, including deleting some hidden EC2 instances which had not previously been visible in the console.</p>
<p>&#8220;After doing all of this, I went to take a snapshot of the billing statement to show everyone my lovely US$3,087.97 bill, only to find it had shot up to US$5994.08 in the meantime,&#8221; he said.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/aws-bill.png" rel="prettyphoto[31497]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/aws-bill.png?resize=425%2C554" alt="aws-bill" class="aligncenter size-full wp-image-31503" /></a></p>
<p>Amazon followed up with the following note:</p>
<blockquote><p>We&#8217;ve submitted a concession request for the unauthorized usage charges you incurred for the current month. The concession request requires approval from levels of management therefore the process can take up to 7 &#8211; 10 working days to complete.</p></blockquote>
<p>He&#8217;s hoping that the leaked keys will not result in him having to cough up $6K for unauthorized use, but he hasn&#8217;t yet received confirmation that he won&#8217;t be held responsible.</p>
<h3>Why were his AWS Credentials in his wp-config file?</h3>
<p>If you&#8217;ve been following along with this nightmare situation, you may be wondering why Hellyer was storing his AWS credentials in wp-config.php. This was required for the <a href="http://geek.ryanhellyer.net/products/photocopy/">Photocopy</a> plugin he released a few years ago. There are many other plugins that utilize this same method. Although the plugin didn&#8217;t seem to have any security flaws, he decided to remove it from the site and discontinue development due to the unpleasant experience of having his keys leaked. &#8220;The only other option is store it in the database, but I think that&#8217;s actually worse as you would run into exactly the same problem if your database were leaked,&#8221; Hellyer said.</p>
<h3>Keep Your Keys Safe and Private</h3>
<p>This cautionary tale should serve as a reminder to keep your keys safe and private. Hellyer unknowingly sabotaged himself when trying to open source the code for his site and learned an expensive lesson:</p>
<p><strong>&#8220;Not only should you be extremely careful with your usernames, passwords, plugin and theme security etc., but you need to be even more careful about credentials for services which cost money,&#8221;</strong> he advised.</p>
<p>&#8220;I&#8217;d rather see my blog(s) hacked than to have this happen again. Hacked sites can be easily fixed. Deleted data can be restored. A $6000 bill however is something else entirely,&#8221; Hellyer said. He also noted that if the exploit had just been a few extra dollars here and there, it could have quietly leached his account indefinitely without him noticing. As it was, if Amazon hadn&#8217;t issued him an urgent notice, he probably wouldn&#8217;t have noticed until he received a $100,000 bill at the end of the month.</p>
<p>The lesson here is that if you can avoid having to store AWS credentials in wp-config.php, by all means, find another way. What started out as a well-meaning effort to open source his site, quickly became a horrible nightmare that has yet to reach a conclusion. There are people out there ready and willing to exploit stolen or leaked AWS keys, and they clearly have a sophisticated way of scouring the web to find them.</p>
<p>Hellyer sums it up: <strong>&#8220;Long story short &#8230; don&#8217;t do stupid stuff with publicly accessible code. Also, don&#8217;t store your AWS credentials unless you absolutely have to.&#8221;</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 26 Sep 2014 16:38:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Matt: Faith in Eventually";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44158";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://ma.tt/2014/09/faith-in-eventually/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:659:"<blockquote><p>During the development of most any product, there are always times when things aren’t quite right. Times when you feel like you may be going backwards a bit. Times where it’s almost there, but you can’t yet figure out why it isn’t. Times when you hate the thing today that you loved yesterday. Times when what you had in your head isn’t quite what you’re seeing in front of you. Yet. That’s when you need to have faith.</p></blockquote>
<p>Jason Fried writes <a href="https://signalvnoise.com/posts/3776-faith-in-eventually">Faith in eventually</a>. Good to share with anyone who&#8217;s been working on something for a while.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 26 Sep 2014 16:10:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WordPress.tv Blog: Leveling-up with WordPress:  Great videos for developers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.wordpress.tv/?p=391";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://blog.wordpress.tv/2014/09/26/leveling-up-with-wordpress-great-videos-for-developers/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3213:"<p>WordCamps are a great place to jump-start your education in the world of WordPress development, or build upon yours current skills to make even greater plugins and themes.  Here are some recent videos from <a href="http://wordpress.tv/event/wordcamp-asheville-2014/" target="_blank">WordCamp Asheville</a> and <a href="http://wordpress.tv/event/wordcamp-vancouver-2014/" target="_blank">WordCamp Vancouver </a> focused on how you can polish your development skills</p>
<h2>Introduction to WordPress Plugin Development</h2>
<div id="v-UhGPU68X-1" class="video-player">
</div>
<p>Jonathan Daggerhart gives a basic introduction to the creation of a new plugin, including using the Codex, actions, filters, shortcodes, custom settings, and some best practices. An existing understanding of some PHP is required to get the most value from this presentation.</p>
<p><a href="http://wordpress.tv/2014/09/24/jonathan-daggerhart-introduction-to-wordpress-plugin-development/" target="_blank">View on WordPress.tv</a></p>
<h2>How To Build A Custom Widget</h2>
<div id="v-vR4M3CqR-1" class="video-player">
</div>
<p>Widgets are a great way to deliver added content or functionality to a WordPress site. In this presentation, Mel Karlik shows you how to create a simple custom widget then see how you can distribute theme with a theme or as a stand-alone plugin.</p>
<p><a href="http://wordpress.tv/2014/09/25/mel-karlik-how-to-build-a-custom-widget/" target="_blank">View on WordPress.tv</a></p>
<h2>Advanced Custom Fields – Beyond the basics</h2>
<div id="v-R3mr0Q9g-1" class="video-player">
</div>
<p>This presentation by Merrill Mayer covers the use of advanced custom fields in non-blog oriented websites, focusing on using them in custom post types as well as demonstrating custom queries along with custom prev/next posts.</p>
<p><a href="http://wordpress.tv/2014/09/25/merrill-mayer-advanced-custom-fields-beyond-the-basics-2/" target="_blank">View on WordPress.tv</a></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptvblog.wordpress.com/391/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptvblog.wordpress.com/391/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.wordpress.tv&blog=5310177&post=391&subd=wptvblog&ref=&feed=1" width="1" height="1" /><div><a href="http://blog.wordpress.tv/2014/09/26/leveling-up-with-wordpress-great-videos-for-developers/"><img alt="Jonathan Daggerhart: Introduction to WordPress Plugin Development" src="http://videos.videopress.com/UhGPU68X/video-882b46ac2b_scruberthumbnail_3.jpg" width="160" height="120" /></a></div><div><a href="http://blog.wordpress.tv/2014/09/26/leveling-up-with-wordpress-great-videos-for-developers/"><img alt="Mel Karlik: How To Build A Custom Widget" src="http://videos.videopress.com/vR4M3CqR/video-da912a20fb_scruberthumbnail_0.jpg" width="160" height="120" /></a></div><div><a href="http://blog.wordpress.tv/2014/09/26/leveling-up-with-wordpress-great-videos-for-developers/"><img alt="Merrill Mayer: Advanced Custom Fields – Beyond the basics" src="http://videos.videopress.com/R3mr0Q9g/video-99f3a50e95_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 26 Sep 2014 00:12:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Jerry Bates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:121:"Lorelle on WP: What Does WordPress, iThemes, Goodwill, Home Depot, and Target Have in Common? Your Identity and Security.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"http://lorelle.wordpress.com/?p=11913";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:141:"http://lorelle.wordpress.com/2014/09/25/what-does-wordpress-ithemes-goodwill-home-depot-and-target-have-in-common-your-identity-and-security/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:485:"We received a new credit card in the mail today to replace our old one AGAIN. An &#8220;unsuccessful attempt&#8221; to access our secure security data happened and this is a precaution the bank is taking to protect us. I have no other information so I&#8217;m left wondering. Yesterday I received an email supposedly from Home [&#8230;]<img alt="" border="0" src="http://pixel.wp.com/b.gif?host=lorelle.wordpress.com&blog=72&post=11913&subd=lorelle&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 25 Sep 2014 21:57:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Lorelle VanFossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"Matt: Circa 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44156";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:29:"http://ma.tt/2014/09/circa-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:216:"<p><a href="http://cir.ca/">Circa is how I get news on my phone every day</a>, and they&#8217;ve just redesigned with some slick new features. They&#8217;re an <a href="http://audrey.co/">Audrey</a> company, too.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 25 Sep 2014 20:49:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"Post Status: The anatomy of a security breach, and how to do good in a bad situation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=7134";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://www.poststat.us/ithemes-security-breach-and-disclosure/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:12133:"<p><img class="aligncenter size-large wp-image-7139" src="http://www.poststat.us/wp-content/uploads/2014/09/ithemes-dark-752x226.jpg" alt="ithemes-dark" width="627" height="188" /></p>
<p>On Tuesday, iThemes posted an announcement that they had <a href="http://ithemes.com/2014/09/23/important-security-update-for-all-customers/">suffered from a security breach</a> of their website and servers. The attackers had reached the servers which stored customer information, including email addresses, IP addresses, full names, and yes, passwords.</p>
<p>iThemes was quick to notify customers via their blog, social media, and their full customer email list about the breach. Approximately 60,000 users were affected. They warned that passwords were vulnerable. In <a href="http://ithemes.com/2014/09/25/update-2-security-update-for-ithemes-customers/">the second update</a>, posted today, they gave more information about passwords, in response to many questions from users.</p>
<p>It turns out that passwords were stored in plaintext on iThemes&#8217; server. That is, obviously, very bad practice.</p>
<blockquote>
<h3>Why Would You Store Passwords in Plain Text?</h3>
<p>This is how the membership software we started using in 2009 did it. There are a number of factors for this, none that will make much of a difference at this point or make anyone feel any better about it, myself included.</p>
<p>Know that it’s not because we did not value your data. As an organization, we have been working on a very large migration process that has required us to interlink legacy systems with the latest technologies. Anyone that has ever gone through that process understands the complexities and challenges.</p>
<p>Frankly put, it’s been something we identified as a potential risk and are working rapidly now to rectify this issue as fast as humanly possible.</p></blockquote>
<p>It&#8217;s also worth noting that their customer database and iThemes.com users were affected, but customers that use their Sync product to manage their own websites were not. So if you use iThemes Sync, and utilized your site passwords to connect, those accounts and passwords were not part of this breach.</p>
<h3>aMember and legacy membership platforms</h3>
<p>The membership platform that Cory highlights in the update is a<a href="http://www.amember.com/">Member</a>, a membership management system that&#8217;s been around for many years. aMember only introduced <a href="http://www.amember.com/p/2011/11/amember-pro-version-4-stable/">encrypted passwords in version 4</a>, which was released in November of 2011.</p>
<p>I discussed aMember and plaintext passwords with some other folks that have a significant history with the membership platform, and there are some significant problems that anyone using aMember have experienced.</p>
<p>First, most folks heavily using aMember aren&#8217;t using it out of the box. At the time, most membership sites were doing significant customizations to aMember to achieve desired functionality. So when the v.4 update came out, it was a very difficult update procedure for people to take advantage of the features.</p>
<p>iThemes would even tell you that their current version of membership software doesn&#8217;t look much like aMember at all.</p>
<p>iThemes is also not the first to be hacked and their aMember passwords leaked. Tuts+ Premium <a href="http://marketblog.envato.com/general/tuts-premium-security/">had the same issue in 2012</a>.</p>
<p>I discussed aMember at length with <a href="http://twitter.com/pippinsplugins">Pippin Williamson</a>. He has done a lot of work on his brother&#8217;s membership site, <a href="http://cgcookie.com/">CGCookie</a>, which also used aMember until 2012, when he did a huge migration of tens of thousands of members to a new platform.</p>
<p>At the time, Pippin notes that aMember did not disclose passwords were stored in plaintext, so CGCookie had no idea that their users were vulnerable until they learned of the Tuts+ hack, wherein they put a planned migration &#8220;into hyperdrive.&#8221;</p>
<p>The problem with iThemes&#8217; situation is that they knew of the plaintext passwords and didn&#8217;t address the obvious security vulnerability.</p>
<p>All in all, the migration for CGCookie took months to perfect and significant juggling of priorities by their team.</p>
<h3>Ticking time bomb</h3>
<p>Speaking with Pippin, migrating from aMember was not an easy task. Paypal&#8217;s IPN handlers (a payment notification system) were tightly linked to aMember and preventing customer accounts from being disconnected from the membership site took weeks of engineering. Additionally, simply upgrading to the newer versions was also terrible.</p>
<p>Many other WordPress companies have used aMember in the past as well, storing plaintext passwords just like iThemes today.</p>
<p>So, aMember has definitely been a problem before now, but iThemes has absolutely slacked in their prioritization of the issue. Simply put, it&#8217;s inexcusable to put users into long term risk if you know their passwords are stored in plaintext.<span id="more-7134"></span></p>
<p>That said, we should consider the potential consequences &#8212; though it doesn&#8217;t make it excusable. Because iThemes doesn&#8217;t store credit card details, emails and names and passwords are about the worst things at risk. Still, a tiny percentage of the general population uses responsible passwords, so getting a list of names and emails and passwords is a treasure trove of information for third party (as in other websites like banks and email providers) to steal identities and break directly into user accounts.</p>
<p>This should also be a significant lesson for any user to always use different passwords for every website where you keep an account. Tools like <a href="https://lastpass.com/">LastPass</a> and <a href="https://agilebits.com/">1Password</a> make account password management easy. Additionally, learn about <a href="http://en.wikipedia.org/wiki/Two-step_verification">2-factor authentication</a> and use it whenever the service enables it.</p>
<h3>Owning mistakes</h3>
<p>This is clearly a horrible situation for iThemes to be in. Users have a right to be mad. In 2014 we should be able to expect that our passwords are encrypted, and that even if a server where our information is stored is hacked, that certain valuable details like credit cards or passwords are not exposed. Thankfully, iThemes doesn&#8217;t store credit card details, but those passwords should now be assumed stolen, and users have to pay that price.</p>
<p>But where I have enormous respect for iThemes is how they have owned it. Especially in the update post, Cory Miller &#8212; iThemes&#8217; founder and CEO &#8212; took ownership of the issue and told the full story of the breach.</p>
<blockquote><p>I realize this will generate a lot of concern. Again, I am deeply sorry for this mistake and how it has affected you.</p>
<p>Let me say: we have made mistakes in the past at iThemes … and as humans will make mistakes in the future. To make a promise otherwise would be absurd and misleading.</p>
<p><strong>But my promise to you, our customers, is this</strong> … and it’s the same promise that I’ve held to since January 2008 when I started iThemes in my home:</p>
<ol>
<li><strong>We will identify mistakes as best we can.</strong> You have helped us with this and appreciate that accountability.</li>
<li><strong>We will own up to our mistakes.</strong> Again, we’ve done this in the past, we did this yesterday and this post is another example of us living this value.</li>
<li><strong>We will fix the mistake as fast as humanly possible.</strong> A number of priority issues have been unearthed, shone a hard light on, but we are working to resolve them.</li>
<li><strong>We will learn and grow from it and be better for it and for you.</strong></li>
</ol>
<p>Additionally, as the founder and CEO, the leader of this company, I want you to know: <strong>the buck stops with me and me alone.</strong></p>
<p>At the end of the day, I am responsible for our company, iThemes, and the work we do. I’ve often tried to defer credit for the great work we’ve done to our team, but as for the mistakes we make, that credit belongs solely to me.</p></blockquote>
<p>Not every company that&#8217;s been breached can say the same. Even huge organizations (I&#8217;m thinking of Home Depot as the latest) have done a horrible job at responsible and honest disclosure to their customers.</p>
<p>iThemes could have made this much more quiet and kept it from being a priority to their users or a big deal in WordPress news-land. But they didn&#8217;t. They owned it, they apologized, and they&#8217;ve been rewarded for that.</p>
<p>In the comments of the security update post, users were appalled by the lack of responsibility on the security priorities, but the honesty paid off in the sense that users were verbally thankful for it so that they could accept the problem and deal with it, when the alternative was to be in the dark.</p>
<p>While this breach has cost iThemes some credibility, and some trust, I believe those things are recoverable. Had they obfuscated the hack itself, my post and users reactions (had they found out) would be very different.</p>
<h3>What iThemes is doing now</h3>
<p>iThemes has learned a hard lesson this week, as many other companies have before them. Now they must react, and react strongly. In a situation like this, nothing should take priority over getting this issue fixed.</p>
<p>Until they get their password storage issue fixed, they still are storing passwords in plaintext, even the new ones. Thankfully they&#8217;ve already updated password restrictions &#8212; which previously limited passwords to 20 characters &#8212; to now accept up to 255 characters. But storing them in plaintext means that they are still as vulnerable today as they were last week if someone gets into the server again. So they must be absolutely vigilant to protect their servers through this migration.</p>
<h3>What we can all learn</h3>
<p>Security is not a sexy industry. Too often we don&#8217;t consider it until it&#8217;s a problem. &#8220;Going on offense&#8221; should be our default when we consider security actions, but more often &#8212; even with some of the best companies and people in the tech space &#8212; we react to issues and aren&#8217;t appropriately proactive.</p>
<p>That said, our job is not done either. All of us should consider our own security situation and how we can improve it. Especially if you have users of your own (and many of my readers do), consider that state of your own security, and make sure it&#8217;s a priority in your business.</p>
<p>When we think about what pays the bills, it&#8217;s not security awareness and proactive security investments. But we should consider security breaches and vulnerabilities as risks that must be managed; meaning investment into security priorities should be a significant part of any business.</p>
<p>iThemes, Envato, and WooThemes are all &#8220;big&#8221; businesses from a WordPress business perspective. Each of them has fought a website security battle. Envato and WooThemes before iThemes have recovered and maintained their users and the community&#8217;s trust. I think iThemes will too. But before you, or me, decide &#8220;it won&#8217;t happen to us&#8221;, consider that it can happen to anyone, and our investments into security measures and best practices are not only worthwhile, but the only responsible thing to do.</p>
<p>And for users, use different passwords on every site. Use LastPass or 1Password. Enable 2-factor authentication. Be vigilant. Do not use the excuse that it&#8217;s too hard or a burden. What&#8217;s much more of a burden is dealing with a hacked email or bank account. Protect yourself and learn how to protect your accounts. It&#8217;s easy to adjust to and modern tools make it a much simpler task to manage.</p>
<p>Let&#8217;s all &#8212; web professionals and users &#8212; learn with iThemes here, and do better.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 25 Sep 2014 20:01:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: iThemes Confirms it Stored Customer Passwords in Clear-Text";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31475";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wptavern.com/ithemes-confirms-it-stored-customer-passwords-in-clear-text";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4658:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ClearTextPasswordFeaturedImage.png" rel="prettyphoto[31475]"><img class="size-full wp-image-31477" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/ClearTextPasswordFeaturedImage.png?resize=637%2C200" alt="Clear Text Password" /></a>photo credit: <a href="https://www.flickr.com/photos/thegloaming/1402099967/">thegloaming</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a>
<p>The CEO of iThemes, Cory Miller, <a title="http://ithemes.com/2014/09/25/update-2-security-update-for-ithemes-customers/" href="http://ithemes.com/2014/09/25/update-2-security-update-for-ithemes-customers/">published a second update</a> concerning the <a title="http://wptavern.com/ithemes-suffers-security-breach-customers-urged-to-reset-passwords" href="http://wptavern.com/ithemes-suffers-security-breach-customers-urged-to-reset-passwords">security breach</a> that occurred on Tuesday. After news of the breach, <a title="http://ithemes.com/2014/09/23/important-security-update-for-all-customers/comment-page-1/#comment-100073" href="http://ithemes.com/2014/09/23/important-security-update-for-all-customers/comment-page-1/#comment-100073">customers were left wondering</a> whether or not their passwords were stored in clear-text. The latest update confirms that passwords were in fact stored in clear-text and affected approximately 60,000 customers.</p>
<blockquote><p>There is no easy way to say this: We were storing your passwords in clear-text. This directly impacted approximately 60,000 of our users, past and current.</p>
<p>Yes, those credentials were used across our entire platform, from our iThemes membership login to your iThemes Sync login.</p></blockquote>
<p>Passwords stored in clear-text allow hackers to easily obtain them if the database becomes compromised. According to the announcement, storing passwords in clear-text dates back to membership software used in 2009. Since that time, the company has been involved with a large migration process moving from legacy systems to newer technology.</p>
<blockquote><p>Know that it’s not because we did not value your data. As an organization, we have been working on a very large migration process that has required us to interlink legacy systems with the latest technologies. Anyone that has ever gone through that process understands the complexities and challenges.</p>
<p>Frankly put, it’s been something we identified as a potential risk and are working rapidly now to rectify this issue as fast as humanly possible.</p></blockquote>
<p>I asked the CTO of <a title="http://crowdfavorite.com/" href="http://crowdfavorite.com/">CrowdFavorite</a>, <a title="http://chrislema.com/" href="http://chrislema.com/">Chris Lema</a>, who has over 20 years of experience in enterprise and SaaS products, if what iThemes experienced is common. &#8220;I can tell you this isn&#8217;t the first or last time I&#8217;ve heard of legacy systems that needed to be migrated or code that needed to be refactored. Sometimes you do it before anything bad happens. Sometimes you&#8217;re not fast enough. The trick is to prioritize it, even when things are &#8216;<em>working&#8217;</em>.&#8221;</p>
<p>In order to avoid the issues iThemes is working through, Lema offers the following advice. &#8220;Companies that have legacy systems &#8211; especially membership sites or eCommerce sites with users/passwords need to create a strategy for migrating those old systems while keeping everything running. This often means the creation of several interim systems. In other words, the migration isn&#8217;t a straight path but a multi-stop journey.&#8221;</p>
<h2>Honesty is a Virtue</h2>
<p>Customers <a title="http://ithemes.com/2014/09/25/update-2-security-update-for-ithemes-customers/comment-page-1/#comment-100191" href="http://ithemes.com/2014/09/25/update-2-security-update-for-ithemes-customers/comment-page-1/#comment-100191">have expressed disappointment</a> that a company who sells one of the most popular WordPress security plugins failed to adhere to security best practices. However, thanks to Miller&#8217;s honest approach of attacking the issue head on, a lot of those same customers are pledging their support.</p>
<p>Although this is a difficult situation for iThemes and its customers, the way Miller has handled the situation is an excellent example of leadership. The easiest thing to do in situations like these is to sweep it under the rug or go around the issue. While customers have every right to be outraged, Miller&#8217;s human and honest approach has kept a backlash to a minimum.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 25 Sep 2014 16:22:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WPTavern: A New Resource Devoted To WordPress and Photographers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=29165";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wptavern.com/a-new-resource-devoted-to-wordpress-and-photographers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2079:"<p><a title="http://wp-photographers.com/" href="http://wp-photographers.com/">WP Photographers,</a> is a new resource created by Aaron Hockley, to help photographers and WordPress users share their photos and build photography businesses. Whether you&#8217;re a <a title="http://wp-photographers.com/wordpress-basics/" href="http://wp-photographers.com/wordpress-basics/">beginner </a>or a photographer looking for <a title="http://wp-photographers.com/wordpress-web-hosting-photographers/" href="http://wp-photographers.com/wordpress-web-hosting-photographers/">the best webhosting service</a>, WP Photographers has you covered. In addition to guides, Hockley routinely publishes reviews of WordPress themes and plugins related to photography.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WP-PhotographersWebsite.png" rel="prettyphoto[29165]"><img class="size-full wp-image-31439" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/WP-PhotographersWebsite.png?resize=1025%2C657" alt="WP Photographers Front Page" /></a>WP Photographers Front Page
<p>He started the site because there were few resources on the web that discuss the intersection between WordPress and photography. &#8220;Being deep in both worlds I get lots of questions from photographers figuring out WordPress and WordPress folks trying to better use images,&#8221; Hockley told the Tavern. He hopes WP Photographers becomes a valuable resource to photographers and plans on starting a podcast to supplement the content on the site.</p>
<p>As Hockley continues to add relevant content,  it could become the go-to place for budding photographers using WordPress. There are several articles on the subject but it&#8217;s convenient to see a website devoted to the topic.</p>
<p>To learn more about Hockley and the inspiration behind WP Photographers, check out this<a title="http://photofocus.com/2014/09/04/finally-a-wordpress-site-for-photographers/" href="http://photofocus.com/2014/09/04/finally-a-wordpress-site-for-photographers/"> interview</a> on PhotoFocus.com.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Sep 2014 23:37:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Matt: Corporate News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44154";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:36:"http://ma.tt/2014/09/corporate-news/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:120:"<p><a href="http://www.ft.com/cms/s/2/937b06c2-3ebd-11e4-adef-00144feabdc0.html">The Invasion of Corporate News</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Sep 2014 22:05:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"Lorelle on WP: WordPress Social Meetup in Vancouver, Washington, This Weekend";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"http://lorelle.wordpress.com/?p=11895";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://lorelle.wordpress.com/2014/09/24/wordpress-social-meetup-in-vancouver-washington-this-weekend/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:489:"We&#8217;re putting together a WordPress Social Meetup in Vancouver, Washington, just a few minutes from downtown Portland, on Sundays from 4-7, and the first one is this Sunday, Sept. 28, 2014! Part of the WordPress PDX Meetup, we&#8217;re excited to be one of the first to offer a social meetup rather than a formal presentation [&#8230;]<img alt="" border="0" src="http://pixel.wp.com/b.gif?host=lorelle.wordpress.com&blog=72&post=11895&subd=lorelle&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Sep 2014 20:27:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Lorelle VanFossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:100:"WPTavern: GavickPro Releases Free WordPress Portfolio Theme for Design, Art and Photography Websites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31386";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:109:"http://wptavern.com/gavickpro-releases-free-wordpress-portfolio-theme-for-design-art-and-photography-websites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4322:"<p>A few months ago, the folks at GavickPro <a href="http://wptavern.com/gavickpro-abandons-theme-framework-in-favor-of-wordpress-customizer" target="_blank">abandoned their GavernWP Framework</a> in favor of using the WordPress customizer for theme options. The shop&#8217;s customers found the original framework to be too cumbersome and confusing, so the GavickPro team decided to move away from frameworks altogether.</p>
<p>With the customizer in place as the baseline for the next generation of themes, GavickPro has been releasing a string of free products to give potential customers a way to test drive the new approach. <a href="https://www.gavick.com/wordpress-themes/portfolio,174.html" target="_blank">Portfolio</a> is the latest theme release, created to showcase art and photography with a lightweight, minimalist design.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/portfolio-gavickpro.png" rel="prettyphoto[31386]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/portfolio-gavickpro.png?resize=994%2C784" alt="portfolio-gavickpro" class="aligncenter size-full wp-image-31405" /></a></p>
<p>Portfolio items in the this simple theme are essentially just regular posts with a featured image assigned. No extra portfolio plugin is required. If you set the homepage to display the latest posts, it will use the grid layout that you see in the theme&#8217;s <a href="http://www.gavick.com/demo/wordpress/portfolio/" target="_blank">demo</a>. Mousing over a post toggles its title and excerpt into view.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/portfolio-customizer.png" rel="prettyphoto[31386]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/portfolio-customizer.png?resize=225%2C300" alt="portfolio-customizer" class="alignright size-medium wp-image-31416" /></a>The customizer includes options for setting the background and primary color for your site. It also allows you to easily change the number of columns, the date format, and enable/disable word-break.</p>
<p>The Portfolio theme also offers options for selecting from a predefined list of Google Fonts for the header and body. You can also paste in the URL for any other Google Font that you prefer to use.</p>
<p>The theme includes one widget area and support for the gallery, image, link, quote, and video post formats.</p>
<p>A social links menu can be created by adding the following available CSS classes to your menu items:</p>
<ul>
<li>icon-fb</li>
<li>icon-gplus</li>
<li>icon-twitter</li>
<li>icon-youtube</li>
<li>icon-pinterest</li>
<li>icon-rss</li>
</ul>
<p>The theme also includes built-in support for <a href="https://disqus.com/" target="_blank">Disqus</a>. Threaded comments, author boxes, and sharing buttons are all nicely styled to remain in the background with portfolio content in the spotlight.</p>
<p>The Portfolio theme is mobile-friendly and responds well to various devices. Your work will look beautiful, no matter the screen size.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/portfolio-wordpress-theme-responsive.jpg" rel="prettyphoto[31386]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/portfolio-wordpress-theme-responsive.jpg?resize=700%2C625" alt="portfolio-wordpress-theme-responsive" class="aligncenter size-full wp-image-31410" /></a></p>
<p>If you like the content in the <a href="http://www.gavick.com/demo/wordpress/portfolio/" target="_blank">live demo</a>, you can download it as a <a href="http://www.gavick.com/documentation/wordpress-themes/themes-demo-content-wxr-files/" target="_blank">WXR file</a>, which includes the sample menus, posts, and images to help you get started.</p>
<p>The theme is simply named Portfolio and after testing it, I can confirm that all the customization features work as advertised. I&#8217;d recommend it for simple portfolio sites where you don&#8217;t need to have portfolio items separate from the rest of the content on your site. It&#8217;s available to <a href="https://www.gavick.com/wordpress-themes/portfolio,174.html" target="_blank">download</a> for free from the GavickPro website. You can also find the code on <a href="https://github.com/GavickPro/Portfolio-Free-WordPress-Theme" target="_blank">GitHub</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Sep 2014 18:48:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WPTavern: Flox: Privately Hosted Social Networks Powered by WordPress and BuddyPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31029";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://wptavern.com/flox-privately-hosted-social-networks-powered-by-wordpress-and-buddypress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9302:"<p>Every day, millions of people mindlessly pump content into social networks that are owned by someone else. These massive data silos plaster your feed with advertising and blatantly disregard user privacy. It&#8217;s a symbiotic relationship wherein you are the product being sold, but you have no control.</p>
<p>Even Twitter, which many saw as the last vestige of social networking sanity, appears to be inching closer to <a href="http://mashable.com/2014/09/04/twitter-filtered-feed/" target="_blank">filtered feeds</a>, experimenting with an <a href="http://techcrunch.com/2014/09/01/twitters-timeline-could-get-more-algorithmic/" target="_blank">algorithmic approach to the timeline</a> in order to deliver content they deem relevant to you. All the major social outlets are starting to pollute users&#8217; feeds with content they don&#8217;t want to see; it&#8217;s the inevitable byproduct of mining user data for profit.</p>
<p>A growing dissatisfaction with this pollution is leading innovators to create new streams of social interaction, with more realistic business models that deliver an unpolluted experience as the product. Many are turning to private social networks as an alternative to the sprawling networks that invariably attempt to connect you to every passing acquaintance.</p>
<h2>Flox Enters the Market to Provide Hosted Private Networks</h2>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/flox.jpg" rel="prettyphoto[31029]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/flox.jpg?resize=1025%2C516" alt="flox" class="aligncenter size-full wp-image-31141" /></a></p>
<p><a href="https://flox.io/" target="_blank">Flox</a> is a brand new service will soon be launching hosted private networks powered by <a href="https://wordpress.org/" target="_blank">WordPress</a>, <a href="https://buddypress.org/" target="_blank">BuddyPress</a>, and <a href="http://www.idangero.us/framework7/" target="_blank">Framework7</a>. The platform will allow you to host your own social network, completely under your control, with the ability to send status updates, photos, messages, and more, in your own private place on the web. Flox users can be part of multiple networks or &#8220;flocks,&#8221; hence the platform&#8217;s sheep logo.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/flox-logo.png" rel="prettyphoto[31029]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/flox-logo.png?resize=250%2C250" alt="flox-logo" class="alignright size-full wp-image-31394" /></a>Founded by BuddyPress project lead <a href="http://jjj.me/" target="_blank">John James Jacoby</a>, Flox is the first WordPress-powered application to jump into hosting full-featured social networks. Jacoby recently left his engineering position at 10up, to pursue his dream of creating hosted communities. Fortunately, Jake Goldman and the folks at <a href="http://10up.com/" target="_blank">10up</a> were behind him and opted to subsidize the project.</p>
<p>&#8220;Jake and I talked about the idea (again) and came to the conclusion it wasn&#8217;t something Jake saw 10up being responsible for in perpetuity, but was still valuable,&#8221; Jacoby told the Tavern. &#8220;Jake and the 10up execs were kind enough to invest a bit in helping bootstrap it. They’ll be my initial round of beta testers.&#8221;</p>
<p>The unique thing about Flox is that it&#8217;s designed to be a mobile-only network. At the moment, the only way you access it is via your mobile browser. There is no desktop version. Jacoby describes it as &#8220;a mobile experience that acts more like Twitter meets Slack powered by BuddyPress, than it does &#8216;large blogging network conglomerate.\'&#8221; Essentially, it is the &#8220;WordPress.com for BuddyPress,&#8221; but he hopes that it will be much more than that.</p>
<p>The possiblity of hosted BuddyPress communities has been burning in Jacoby&#8217;s head since his earlier days at Automattic. &#8220;The idea goes way back to 2007/8, with the idea of BuddyPress on WordPress.com. When Matt eventually abandoned that idea, I couldn&#8217;t let go of the bigger idea of letting people roll their own WordPress.com’s,&#8221; he said.</p>
<p>Why is Flox mobile only? Jacoby believes this is the way of the future for online social interaction.</p>
<blockquote><p>The idea to go Mobile-only was inspired by a few things: Jake Goldman really wanted a great mobile experience to communicate with 10uppers; I believe we&#8217;re entering an era where many people will use mobile devices as their only machines; my desire to funnel the most relevant and important people in my life into a convenient, easy-to-use, and own-my-own-data place in my pocket.</p></blockquote>
<p>Jacoby is flying solo on the project for now but he hopes to add to his team as the platform gains momentum. &#8220;By the end of the year, my goal is to have at least one full-time employee on it besides myself,&#8221; he said. &#8220;Ideally many more down the line, but we’ll see what I’m able to pull off.&#8221;</p>
<h3>The Technology Behind Flox</h3>
<p>Conversations in Flox include all the native BuddyPress social features distilled into a UI that is highly optimized for mobile. Users have the option to create &#8220;channels&#8221; to further filter the activity stream.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/flox-conversation.png" rel="prettyphoto[31029]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/flox-conversation.png?resize=460%2C818" alt="flox-conversation" class="aligncenter size-full wp-image-31150" /></a></p>
<p>Flox is intended to be an application where its users never see the backend of WordPress. Jacoby hopes to preserve wp-admin to be used strictly as a UI for Flox staff to manage the installation. The idea is that administrators of their own networks will get a purposely crafted experience, without all of the maintenance associated with managing a WordPress site.</p>
<p>Under the hood, each flock is its own network on a multi-network installation of WordPress. &#8220;BuddiOS is the heart of the mobile experience, at least right now,&#8221; Jacoby said. &#8220;Currently, it’s a WordPress theme, though it might eventually turn into a plugin that auto-detects a mobile environment, and adjusts. We’ll see how that experience pans out in the long-term.&#8221;</p>
<p>Outside of WordPress and BuddyPress, Framework7 is the only other technology in the mix right now. &#8220;I started down the AngularJS road but it’s not really the right tool for this job,&#8221; Jacoby said. &#8220;I can see future versions using a restful API, but for what I need and how much work needs to go into that API, I wasn&#8217;t inclined to rush it.&#8221;</p>
<p>Why isn&#8217;t Flox launching with a native app? Jacoby wants to start out by refining the experience of the basic social features before delving further into integrating with native device features. &#8220;I built a &#8216;native app&#8217; using a UIWebView that I&#8217;m using personally, but that alone isn&#8217;t enough to make it into the Apple App store,&#8221; he explained. &#8220;It will need to use something native to the phone first, which will likely be push notifications or settings integration.&#8221;</p>
<p>Jacoby plans to put the BuddiOS WordPress theme up for sale to start, in order to help further subsidize BuddyPress/Flox development. Now that he is focusing on Flox, he has a greater ability to contribute to the open source BuddyPress project, which is entirely volunteer driven. This can only mean good things for the future of BuddyPress.</p>
<h3>Pricing and Launch Information</h3>
<p>Flox is emerging as a fresh alternative to the massive social networks where you have limited control over the content presented to you. Online social networking, in its purest form, is the ability to have authentic interactions with the people you choose. Flox is aiming to restore the simplicity and power of small, focused networks but is also built to scale to accommodate large businesses that require social networking for employees.</p>
<p>Users can create several networks, each with their own members. The platform is designed to make it easy to switch between your various private social networks and <a href="https://flox.io/pricing/" target="_blank">pricing</a> is flexible based on the number of users. Personal networks are free and limited to 5 users in 5 networks. The Business pricing option rings in at $3/user per month and is limited to 25 users. Pro social networks do not have a user limit and receive access to priority support at $10/user per month.</p>
<p>The platform is a promising option for those who want the power of mobile BuddyPress social networking without the hassle of managing their own installations. It also appeals to those who are looking to leave traditional social networks in favor of creating their own.</p>
<p>At the moment, <a href="https://flox.io" target="_blank">Flox</a> is in its early beta period and <a href="https://flox.io/sign-up/" target="_blank">signups</a> are limited to a few testers. The service will be launching soon, putting private social networks in the pockets of users around the world.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Sep 2014 13:07:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WPTavern: How Public Perception of WordPress Influences Developer Contracts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31255";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://wptavern.com/how-public-perception-of-wordpress-influences-developer-contracts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:15284:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/cash.jpg" rel="prettyphoto[31255]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/cash.jpg?resize=1019%2C504" alt="photo credit: Tax Credits - cc" class="size-full wp-image-31371" /></a>photo credit: <a href="https://www.flickr.com/photos/76657755@N04/7658205070/">Tax Credits</a> &#8211; <a href="http://creativecommons.org/licenses/by/2.0/">cc</a>
<p>If the WordPress community is your only barometer of knowing how an open source community works together, then you might want to explore outside a bit further to gain a broader outlook on other cultures. Some of the differences are worth examining.</p>
<p>A few days ago I noticed an interesting observation regarding the relationship between plugin development and project offers in CakePHP vs. WordPress.</p>
<blockquote class="twitter-tweet" width="550"><p>Another CakePHP project offer thanks to two open source plugins of mine from years ago. Three times more often than WP offers.</p>
<p>&mdash; Mario Y. Peshev (@no_fear_inc) <a href="https://twitter.com/no_fear_inc/status/511604514236141568">September 15, 2014</a></p></blockquote>
<p></p>
<p><a href="http://devwp.eu/" target="_blank">Mario Peshev</a> is a WordPress contributor who owns <a href="http://devrix.com/" target="_blank">DevriX</a>, a high-end agency specializing in SaaS development and platform architecture. He is also a co-organizer of WordCamp Sofia and WordCamp Europe 2014.</p>
<p>It seems curious that Peshev would regularly receive more offers for CakePHP work, originating from older code he&#8217;d written, versus requests for WordPress, which powers more than 23% of the web. In his experience, it&#8217;s not just related to CakePHP but many other technologies as well.</p>
<p>&#8220;It&#8217;s not only CakePHP really. CakePHP, CodeIgniter, Java, Django, Drupal, Android even &#8211; all sorts of small extensions, plugins or apps I&#8217;ve built and released publicly get larger attention than my WordPress contributions,&#8221; Peshev told the Tavern.</p>
<p><strong>&#8220;Not only do I get 2-3x more projects with any other platform (even though I haven&#8217;t contributed there for 3+ years), but the proposed rates and budgets are few times higher.&#8221;</strong></p>
<p>His experience seems to suggest that there&#8217;s a disconnect somewhere in how potential customers value the skills of WordPress developers.</p>
<h2>Client Perception of WordPress</h2>
<p>WordPress is heralded the world over as being the most user friendly publishing software on the web. Unfortunately, this can also contribute to unrealistic client expectations when it comes to custom development.</p>
<p>&#8220;The majority of the WordPress users that get in touch with us are: bloggers, small company owners, marketing consultants, sales agents, small and medium-sized businesses,&#8221; Peshev said. &#8220;They are not technical people and don&#8217;t have realistic (according to the market standards) expectations for the type of work they ask for.&#8221;</p>
<p>He outlined a typical scenario that plagues many development agencies. Because users can piece most of their sites together without help, they figure the rest should be easy:</p>
<blockquote><p>A common scenario is: &#8220;We&#8217;ve built our WordPress website ourselves with a premium theme and a few plugins, so we just need those tiny changes applied here and there.&#8221; Their infrastructure is not ready for the types of changes they need, and the fact that 90%+ of their requirements cost $100 or so (for a premium theme + a plugin) doesn&#8217;t justify paying ten times more for the other 10% if that would be 10-20 hours of high-end development. The math just doesn&#8217;t add up for them.</p></blockquote>
<p>These misconceptions play out in various ways, including users feeling entitled when it comes to free plugin and theme features, core updates, and other improvements that seem to arrive magically from the sky. Very few plugin and theme developers can report anything more than meager donations when it comes to contributing free extensions.</p>
<p>For Peshev, creating open source extensions for platforms outside the WordPress ecosystem has been far more rewarding in terms of referrals for work. He detailed a recent request he received in a post titled <a href="http://devwp.eu/15-wordpress-gig/" target="_blank">The $15 WordPress Gig</a>:</p>
<p><strong><em>&#8220;Hello, I’m looking for someone who could customize a WordPress plugin we bought. It’s a car reservation system, we need to change the pricing model and add a few extra SQL tables that would operate with the plugin.&#8221;</em></strong></p>
<p>After requesting a project description and budget, Peshev received the following reply:</p>
<p><strong><em>&#8220;Thanks, the plugin costs $25 so I estimate the change would probably cost around $15.&#8221;</em></strong></p>
<p>While that response may seem shocking to a developer, it makes perfect sense to someone who only has the price tag of the original product as a gauge for judging the value of work related to it.</p>
<h2>Reshaping Client Expectations</h2>
<p>The WordPress community has a unique challenge when it comes to communicating the costs of custom development, given that thousands of free and/or dirt cheap themes and plugins are available. How can a seemingly simple modification be 10x the price of the original plugin?</p>
<p>Some of these issues stem from the way most development agencies attract customers. <strong>&#8220;WordPress is more design and marketing oriented than other communities. Portfolios reveal beautiful and stylish websites and agencies focus on frontend work,&#8221;</strong> Peshev said.</p>
<p>&#8220;Building CRMs, eRPs, eCommerce platforms or other backend-oriented platforms and services is still not a common thing in the WordPress ecosystem, even if it&#8217;s completely possible and some of us build these sorts of projects for larger clients.&#8221;</p>
<p>Peshev believes that since most clients lack technical knowledge, they judge agencies and developers by what they can see. &#8220;<span class="pullquote alignleft">Clients don&#8217;t browse WordPress.org or GitHub portfolios, they are just looking for beautiful designs.</span> Code quality doesn&#8217;t matter unless you deal with eCommerce, and scalability and security are overlooked until it&#8217;s too late.&#8221;</p>
<p>If you sell WordPress development services, you will undoubtedly have to become skilled at reshaping client expectations. When it comes to custom development, experienced developers often recommend giving the potential customer a more familiar frame of reference:</p>
<blockquote class="twitter-tweet" lang="en"><p><a href="https://twitter.com/pollyplummer">@pollyplummer</a> I can buy a suit for $99 \'off the peg\' or pay 10x that for a custom suit that is made perfectly for me.</p>
<p>&mdash; Jonathan Atkinson (@twsjonathan) <a href="https://twitter.com/twsjonathan/status/514573813707599873">September 24, 2014</a></p></blockquote>
<p></p>
<p>There are many different pre-internet era professions that are easier for clients to understand:</p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/BoiteAWeb">@boiteaweb</a> <a href="https://twitter.com/pollyplummer">@pollyplummer</a> if I need electrical work and it takes the electrician 10 mins and a $2 piece I don\'t expect to pay him $10</p>
<p>&mdash; Jonathan Atkinson (@twsjonathan) <a href="https://twitter.com/twsjonathan/status/514575464728244224">September 24, 2014</a></p></blockquote>
<p></p>
<p>What is difficult for customers to grasp, is that development expertise is most similar to the work of a traditional engineer in that it requires applying years of knowledge and experience to devise a technical solution that will hold up in the long run.</p>
<p>A client may see his request as a &#8220;simple tweak to a plugin or theme&#8221; but is unaware of the many obstacles that can make it complicated. Peshev details a few examples in his recent piece on <a href="http://devwp.eu/slippery-slope-wordpress-customizations/" target="_blank">The Slippery Slope of WordPress Customizations</a>:</p>
<ul>
<li>The theme is not written according to the WordPress guidelines</li>
<li>The plugins are not compatible</li>
<li>There have been various manual changes in those plugins</li>
<li>The hosting provider has some limitations</li>
<li>There are PHP/MySQL version issues</li>
<li>The site uses some 3rd party API/service/database that needs special attention</li>
<li>The fixes could cause a regression in another area of the site</li>
<li>A simple functionality has been built with a complex plugin and the change needs to be applied there, which requires hacking the plugin itself </li>
</ul>
<p>For many small to mid-sized development agencies, the majority of incoming requests are directly related to customization work. Developers have to be prepared to educate clients on the realities of building quality WordPress solutions. While client perceptions are a major factor in the size of contracts developers are able to win, Peshev believes that the WordPress community has deeper cultural issues to resolve before the public will change its mind on the value of WordPress development.</p>
<h3>Changing Public Perception by Building a Culture of Contributing</h3>
<p>Because the open source WordPress project is primarily a volunteer-driven effort, a culture of contribution is vital to its continued ability to innovate. It&#8217;s also vital for extension developers if they want to work together to build more elegant solutions. According to Peshev, very few companies and agencies see the value of contributing to the project.</p>
<blockquote><p>While traveling around Europe I&#8217;ve met developers and devops at WordCamps from companies with 400+ employees, where the WordPress department is only 5-10 people strong. Those projects are large online magazines, or platforms for digital and high-tech companies that heavily rely on the WordPress platform, and they rarely invest in WordPress advocates or full-time contributors.</p></blockquote>
<p>Apart from a small number of corporately-funded contributors, the rest are individuals who donate time in the evening after the kids go to bed, over the weekend, or in between their freelance/agency duties.</p>
<p>Yet, many contributions go unrecognized and are often wrongly attributed entirely to Automattic by <a href="http://qz.com/260933/the-case-for-a-distributed-workforce/" target="_blank">every</a> <a href="http://www.fastcolabs.com/3035463/how-matts-machine-works" target="_blank">major</a> <a href="http://techcrunch.com/2014/08/26/automattic-acquires-bruteprotect-to-help-keep-wordpress-users-safe/" target="_blank">tech</a> <a href="http://techcrunch.com/2014/05/05/automattic-raises-160m-to-catch-up-with-the-webs-evolution/" target="_blank">news</a> outlet. These are honest mistakes, but, when left uncorrected, they contribute to the public perception that the project is the work of a handful of people who work for an elite agency, marginalizing the efforts of hundreds of unpaid volunteers.</p>
<p>&#8220;&#8216;WordPress themes&#8217; is the most popular subject in Google searches if you check with the Keyword planner,&#8221; Peshev notes. &#8220;Yet until a week ago there were no paid contributors to the WordPress Theme Review Team. Lots of people haven&#8217;t been noticed at all there, despite the facts that millions of websites run the themes they have reviewed and polished in order to reach to the point that they actually work.&#8221;</p>
<p>He contends that when contributions are undervalued or unrecognized, WordPress developers have little motivation to work together. This applies to product development as well, which spills over into custom development work.</p>
<p>&#8220;Have you noticed how many Lightbox, Gallery or Slider plugins we have out there? <span class="pullquote alignleft">Contributors don&#8217;t help each other and products stay small and simple</span>,&#8221; Peshev siad. &#8220;I have 25+ plugins on GitHub and I&#8217;ve only ever gotten three or four pull requests for any changes, and keep seeing similar plugins popping up every few weeks.</p>
<p>Our culture outside of the core isn&#8217;t contributing, but building everything from scratch or using &#8216;builder&#8217; plugins, which is somewhat justified by the low budgets that prevent us from any research activities which could slow us down (and burn our profits).&#8221;</p>
<p>As a result, many developers opt to go it alone, building custom solutions as quickly as possible on small budgets. Unfortunately, this practice restricts the growth of development agencies.</p>
<p>&#8220;I see a huge gap between the types of WordPress development/design requests,&#8221; Peshev said.</p>
<p>&#8220;The types of WordPress experts that I see out there are either freelancers and small studios with up to 3-4 people, or agencies like Human Made, 10up, WebDevStudios (and Automattic, of course). On one hand, there are the small $500 customization gigs or $3K eCommerce projects. On the other end we have the WordPress.com VIP type of clients and requests that are at least 50 times more expensive than the others.&#8221;</p>
<p>WordPress clients who cannot afford VIP level service turn to smaller companies like Peshev&#8217;s to accommodate their budgets. However, Peshev is frequently approached by clients looking for high-end consultants for other platforms, based on past open source contributions. Unfortunately, when it comes to WordPress work, contributions have done little for bringing in larger projects.</p>
<p>&#8220;I find it challenging to grow from a consultant to a larger and sustainable agency solely with WordPress &#8211; and I see numerous small agencies getting stuck at 4-5 people tops,&#8221; he said.</p>
<h3>Promoting Collaboration and Contribution</h3>
<p>For many dedicated WordPress contributors like Peshev, open source contributions have not led to more work or better contracts, despite the fact that these types of contributions should verify these developers as high-end experts. A little bit of skill and free time are all that are required to contribute to open source software, but time comes at a cost when you&#8217;re struggling to pay the bills.</p>
<p>Peshev&#8217;s observations raise some important questions that are worth considering. In an ecosystem where developers are often in competition with each other to create the same simple extensions for fast cash, it doesn&#8217;t pay to collaborate on more elegant solutions. This contributes to a market flooded with cheap solutions and customers who don&#8217;t value the skills required for WordPress development.</p>
<p>Highly skilled developers, who might otherwise be driven away to other more lucrative platforms, often choose to stick with WordPress because of its unique community. If we can find a way to change the culture to value and reward contributors, they will be better positioned to make a living with WordPress. This allows them to create more stable, secure solutions that raise the quality expectations of users across the web.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Sep 2014 04:29:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: iThemes Suffers Security Breach, Customers Urged To Reset Passwords";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31293";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:86:"http://wptavern.com/ithemes-suffers-security-breach-customers-urged-to-reset-passwords";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2904:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2009/08/ithemeslogo.png" rel="prettyphoto[31293]"><img class="alignright wp-image-2310 size-full" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2009/08/ithemeslogo.png?resize=255%2C69" alt="iThemes Logo" /></a>iThemes published details on a security breach that took place earlier today. According to <a title="http://ithemes.com/2014/09/23/important-security-update-for-all-customers/" href="http://ithemes.com/2014/09/23/important-security-update-for-all-customers/">the announcement</a>, after noticing suspicious activity, they noticed a signification attack on their membership database. iThemes urges all customers to reset their passwords immediately. To protect accounts from any unauthorized access, iThemes has temporarily reset all user passwords. To regain access to your account, you’ll need to <a href="http://ithemes.com/member/password_reset.php">reset your password</a>.</p>
<p>The attackers could gain access to the following customer data:</p>
<ul>
<li>Username</li>
<li>Password</li>
<li>Email address</li>
<li>First and last name (if you set it)</li>
<li>IP address</li>
<li>The names of products you purchased</li>
<li>Coupon codes you might have used</li>
<li>Access times</li>
<li>Payment receipt information (but no other payment info)</li>
</ul>
<p>Since a third-party payment processor is used, credit card information is not at risk of being obtained. iThemes is working to figure out how the attack happened, ensure the security of the rest of their servers, and make sure the site is safe for visitors to browse. The team has outlined a three-step process towards accomplishing these tasks.</p>
<ul>
<li>We are performing a review / audit of our Information Technology (IT) Stack</li>
<li>We are performing a review / audit of our Products and their code base</li>
<li>We are reviewing and updating our Security Incident Response and Detection procedures</li>
</ul>
<p>iThemes is partnering with security service company, <a title="http://sucuri.net/" href="http://sucuri.net/">Sucuri</a>, to help with the discovery process. The CEO of iThemes, Cory Miller, concluded the announcement with the following statement.</p>
<blockquote><p>I deeply apologize for this event. Security is a staple of the service and products we provide and I assure you we will do everything we can to analyze, understand how this occurred and seek to prevent it from happening again.</p>
<p>Know that your personal information is of the utmost priority to me and if you have any questions or concerns, please let us know.</p></blockquote>
<p>Although no business owner wants to go through an experience like this, I give kudos to iThemes for being upfront and honest with their customers instead of waiting for days. If you&#8217;re an iThemes customer, please make the effort to change your password as soon as possible.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Sep 2014 23:21:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: Envato on The State of WordPress Blogging Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31251";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wptavern.com/envato-on-the-state-of-wordpress-blogging-themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1521:"<p>Envato has a nice article covering the <a title="http://marketblog.envato.com/trends/current-state-wordpress-blogging-themes/" href="http://marketblog.envato.com/trends/current-state-wordpress-blogging-themes/">current state</a> of WordPress blogging themes. The article does a nice job highlighting not only the styles over the years but the inspiration behind them as well. The design traits profiled include:</p>
<ul>
<li>Modern Single-Column Layout</li>
<li>Traditional Two-Column Layout</li>
<li>The Journal Layout</li>
<li>The Masonry/Grid Layout</li>
</ul>
<p>My favorite style is a toss-up between the journal and single-column layout. That&#8217;s why I&#8217;m psyched to see the <a title="http://wptavern.com/first-look-at-designs-for-the-twenty-fifteen-default-wordpress-theme" href="http://wptavern.com/first-look-at-designs-for-the-twenty-fifteen-default-wordpress-theme">Twenty Fifteen default theme</a> go with a clean, two-column layout. I think a lot of sites will use it compared to Twenty Fourteen which was more of a magazine style. Here&#8217;s a look at the various styles used by default themes in WordPress over the years starting with Twenty Ten.</p>
<a href="http://wptavern.com/envato-on-the-state-of-wordpress-blogging-themes#gallery-31251-1-slideshow">Click to view slideshow.</a>
<p>Which style is your favorite and are you happy to see the Twenty Fifteen default theme go back to a more traditional two-column layout? What do you think the next WordPress theme design trend will be?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Sep 2014 22:20:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: BuddyPress Feature Plugin Adds Rich Text Fields to Profiles";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=31220";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wptavern.com/buddypress-feature-plugin-adds-rich-text-fields-to-profiles";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4733:"<p>Earlier this year, BuddyPress contributors announced that the project would be adopting the <a href="http://wptavern.com/wordpress-core-development-goes-to-warp-speed-with-features-as-plugins-model" target="_blank">features-as-plugins</a> model to help speed up future development. This is the same development model that has been working well for WordPress core, helping four major features land in the 3.8 release.</p>
<p>The <a href="http://wptavern.com/buddypress-to-adopt-features-as-plugins-model-to-develop-new-media-component" target="_blank">BuddyPress Media Component and Attachment API</a> was the first feature to enter development as a plugin. One of the benefits of using this model, where it makes sense, is that it gets more people involved in creating and testing new features before they are added to BP core.</p>
<h3>Buddypress xProfile Rich Text Field</h3>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/rich-text.jpg" rel="prettyphoto[31220]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/rich-text.jpg?resize=772%2C250" alt="rich-text" class="aligncenter size-full wp-image-31236" /></a></p>
<p><a href="https://wordpress.org/plugins/bp-xprofile-rich-text-field/" target="_blank">Buddypress xProfile Rich Text Field</a> is the second plugin to present itself as a feature plugin for consideration. It adds a rich-text editor custom field type to extended profiles. <a href="http://haystack.co.uk/" target="_blank">Christian Wach</a>, better known as <a href="https://profiles.wordpress.org/needle/" target="_blank">@needle</a>, created the plugin with the hope that it will be included in BP core.</p>
<p>Once installed, you&#8217;ll find a new profile field type called &#8220;Rich Text Area&#8221; as an option when creating a new field. It&#8217;s essentially a multi-line textarea field with a visual editor added in.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/rich-text-field-type.png" rel="prettyphoto[31220]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/rich-text-field-type.png?resize=634%2C338" alt="rich-text-field-type" class="aligncenter size-full wp-image-31222" /></a></p>
<p>Instead of a blank multi-line text box, members will find simple tools for formatting text, links, bullet lists, etc. on the frontend. Having these familiar formatting options available makes it easier for users provide a more readable profile entry, as opposed to a flat block of text.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/rich-text-profile-fields.png" rel="prettyphoto[31220]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/09/rich-text-profile-fields.png?resize=618%2C456" alt="rich-text-profile-fields" class="aligncenter size-full wp-image-31224" /></a></p>
<p>BuddyPress themes that use compatibility mode will automatically work with this plugin. However, if your theme supplies its own BuddyPress template files, you may need to make a few adjustments in order for this plugin to work.</p>
<p>A <a href="https://buddypress.trac.wordpress.org/ticket/5625" target="_blank">ticket</a> is open for discussion regarding adding this feature to BuddyPress 2.2. Christian Wach created a preliminary patch for a Visual Editor field type. BuddyPress core developer Boone Gorges shared his initial <a href="https://buddypress.trac.wordpress.org/timeline?from=2014-09-19T19%3A45%3A34Z&precision=second" target="_blank">thoughts</a> on the patch:</p>
<blockquote><p>We should not have a separate field type for this. IMHO, all multi-line textarea fields should support rich text. In fact, I think we should just turn it on for those fields and not allow it to be turned off (since there&#8217;s a Text tab in addition to the Visual tab), though if others feel differently perhaps we could have an admin toggle to disable on a per-field basis. In any case, I don&#8217;t see a strong case for having a separate field type.</p></blockquote>
<p>This makes sense, as I&#8217;m not sure why you would ever want a textarea field type that doesn&#8217;t have visual editing capabilities. Wach revised his patch to add options to the textarea field type instead of creating a brand new field type. This change appears to be the direction that the feature will take, if it is approved for inclusion in BP core.</p>
<p>In the meantime, you can utilize the <a href="https://wordpress.org/plugins/bp-xprofile-rich-text-field/" target="_blank">Buddypress xProfile Rich Text Field</a> feature plugin to get this working on your site. If the feature is included in BuddyPress 2.2, it will be easy to simply switch the field type to &#8220;multi-line textarea&#8221; when the time comes.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Sep 2014 18:33:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Matt: Checky";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44149";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://ma.tt/2014/09/checky/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:354:"<p><a href="http://www.checkyapp.com/">Checky tells you how many times a day you check your phone</a>, which Mary Meeker said in 2013 that we do <a href="http://www.kpcb.com/insights/2013-internet-trends">150 times a day</a>. In a brilliant act of marketing, Checky is brought to you by the same people as <a href="http://www.calm.com/">Calm.com</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Sep 2014 07:58:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Tue, 07 Oct 2014 19:11:49 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"270791";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Tue, 07 Oct 2014 19:00:16 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 249";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911040210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (473, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1412752309', 'no') ; 
INSERT INTO `wp_options` VALUES (474, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1412709109', 'no') ; 
INSERT INTO `wp_options` VALUES (475, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1412752309', 'no') ; 
INSERT INTO `wp_options` VALUES (476, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 07 Oct 2014 18:43:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast&#039;s WordPress SEO plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"MailPoet Newsletters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wysija-newsletters/#post-32629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Dec 2011 17:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32629@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Send newsletters, post notifications or autoresponders from WordPress easily, and beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"MailPoet Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Google Analytics by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Sep 2007 12:15:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2316@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:124:"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 10 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Broken Link Checker";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/broken-link-checker/#post-2441";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 08 Oct 2007 21:35:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2441@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"This plugin will check your posts, comments and other content for broken links and missing images, and notify you if any are found.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Janis Elsts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Google Analytics Dashboard for WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 17:07:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"50539@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Displays Google Analytics Reports and Real-Time Statistics in your Dashboard. Automatically inserts the tracking code in every page of your website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alin Marcu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WordPress Social Sharing Optimization (with SEO, Video, and eCommerce Integration)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://wordpress.org/plugins/wpsso/#post-62149";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 28 Dec 2013 00:00:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62149@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:143:"Make sure social websites present your content correctly, no matter how your webpage is shared - from buttons, browser add-ons, or pasted URLs.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"JS Morisset";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Tue, 07 Oct 2014 19:11:49 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Tue, 07 Oct 2014 19:18:27 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Tue, 07 Oct 2014 18:43:27 +0000";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911040210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (477, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1412752309', 'no') ; 
INSERT INTO `wp_options` VALUES (478, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1412709109', 'no') ; 
INSERT INTO `wp_options` VALUES (479, '_transient_timeout_plugin_slugs', '1412795509', 'no') ; 
INSERT INTO `wp_options` VALUES (480, '_transient_plugin_slugs', 'a:4:{i:0;s:19:"akismet/akismet.php";i:1;s:51:"all-in-one-wp-migration/all-in-one-wp-migration.php";i:2;s:36:"contact-form-7/wp-contact-form-7.php";i:3;s:39:"backup-with-restore/backupwordpress.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (481, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1412752309', 'no') ; 
INSERT INTO `wp_options` VALUES (482, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2014/09/benny/\'>WordPress 4.0 “Benny”</a> <span class="rss-date">September 4, 2014</span><div class="rssSummary">Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleader Benny Goodman, is available for download or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we’ve put a little extra polish into it. This release brings you a smoother writing and management experience [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://ma.tt/2014/10/tavern-interview/\'>Matt: Tavern Interview</a></li><li><a class=\'rsswidget\' href=\'http://www.poststat.us/wordpress-right-ecommerce/\'>Post Status: Is WordPress right for eCommerce?</a></li><li><a class=\'rsswidget\' href=\'http://ma.tt/2014/10/gambino-mixtape-stn-mtn/\'>Matt: Gambino Mixtape STN MTN</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'http://wordpress.org/plugins/wpsso/\' class=\'dashboard-news-plugin-link\'>WordPress Social Sharing Optimization (with SEO, Video, and eCommerce Integration)</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=wpsso&amp;_wpnonce=f42502a92b&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'WordPress Social Sharing Optimization (with SEO, Video, and eCommerce Integration)\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (486, 'rewrite_rules', 'a:69:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=13&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (500, '_site_transient_timeout_theme_roots', '1412732288', 'yes') ; 
INSERT INTO `wp_options` VALUES (501, '_site_transient_theme_roots', 'a:1:{s:13:"north-star-wp";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (502, '_transient_doing_cron', '1412798537.7042310237884521484375', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 8. October 2014 20:02 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (124 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'page-full.php') ; 
INSERT INTO `wp_postmeta` VALUES (2, 4, '_wp_attached_file', '2014/09/Home_image.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3, 4, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1028;s:6:"height";i:612;s:4:"file";s:22:"2014/09/Home_image.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"Home_image-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"Home_image-300x178.jpg";s:5:"width";i:300;s:6:"height";i:178;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"Home_image-1024x609.jpg";s:5:"width";i:1024;s:6:"height";i:609;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (4, 5, '_wp_attached_file', '2014/09/AboutUs_image.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (5, 5, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1028;s:6:"height";i:492;s:4:"file";s:25:"2014/09/AboutUs_image.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"AboutUs_image-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"AboutUs_image-300x143.jpg";s:5:"width";i:300;s:6:"height";i:143;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"AboutUs_image-1024x490.jpg";s:5:"width";i:1024;s:6:"height";i:490;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (6, 6, '_wp_attached_file', '2014/09/north-star-logo.png') ; 
INSERT INTO `wp_postmeta` VALUES (7, 6, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:296;s:6:"height";i:162;s:4:"file";s:27:"2014/09/north-star-logo.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"north-star-logo-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (8, 7, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (9, 7, '_edit_lock', '1411761307:1') ; 
INSERT INTO `wp_postmeta` VALUES (10, 6, '_wp_attachment_image_alt', 'North Star Counselling') ; 
INSERT INTO `wp_postmeta` VALUES (11, 2, '_edit_lock', '1411777874:1') ; 
INSERT INTO `wp_postmeta` VALUES (12, 2, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (15, 13, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (16, 13, '_wp_page_template', 'homepage.php') ; 
INSERT INTO `wp_postmeta` VALUES (17, 13, '_edit_lock', '1412537190:1') ; 
INSERT INTO `wp_postmeta` VALUES (18, 2, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (19, 2, '_wp_trash_meta_time', '1411778083') ; 
INSERT INTO `wp_postmeta` VALUES (20, 16, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (21, 16, '_edit_lock', '1411780134:1') ; 
INSERT INTO `wp_postmeta` VALUES (24, 19, '_edit_last', '2') ; 
INSERT INTO `wp_postmeta` VALUES (25, 19, '_edit_lock', '1412718037:1') ; 
INSERT INTO `wp_postmeta` VALUES (26, 19, '_wp_page_template', 'page-blue.php') ; 
INSERT INTO `wp_postmeta` VALUES (28, 28, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (29, 28, '_edit_lock', '1412546283:1') ; 
INSERT INTO `wp_postmeta` VALUES (30, 28, '_wp_page_template', 'page-aqua.php') ; 
INSERT INTO `wp_postmeta` VALUES (31, 31, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (32, 31, '_edit_lock', '1412722273:1') ; 
INSERT INTO `wp_postmeta` VALUES (33, 31, '_wp_page_template', 'page-teal.php') ; 
INSERT INTO `wp_postmeta` VALUES (34, 34, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (35, 34, '_edit_lock', '1412546314:1') ; 
INSERT INTO `wp_postmeta` VALUES (36, 34, '_wp_page_template', 'page-green.php') ; 
INSERT INTO `wp_postmeta` VALUES (37, 36, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (38, 36, '_edit_lock', '1412548589:1') ; 
INSERT INTO `wp_postmeta` VALUES (39, 36, '_wp_page_template', 'page-yellow-green.php') ; 
INSERT INTO `wp_postmeta` VALUES (41, 16, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (42, 16, '_wp_trash_meta_time', '1412182113') ; 
INSERT INTO `wp_postmeta` VALUES (43, 7, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (44, 7, '_wp_trash_meta_time', '1412182113') ; 
INSERT INTO `wp_postmeta` VALUES (45, 38, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (46, 38, '_edit_lock', '1412720264:1') ; 
INSERT INTO `wp_postmeta` VALUES (47, 38, 'post-order', '1') ; 
INSERT INTO `wp_postmeta` VALUES (49, 1, '_edit_lock', '1412187770:1') ; 
INSERT INTO `wp_postmeta` VALUES (52, 38, 'question-pre', 'Your first, and most important, question.') ; 
INSERT INTO `wp_postmeta` VALUES (53, 38, 'question-main', 'Can counselling work for me?') ; 
INSERT INTO `wp_postmeta` VALUES (55, 38, 'answer', 'Yes, it can.') ; 
INSERT INTO `wp_postmeta` VALUES (56, 38, 'explanation', 'It helps millions every day in all walks of life, with all kinds of problems. It helps the young and the old, the rich and the poor, the ones who have made it and the ones on their way. It will help you.') ; 
INSERT INTO `wp_postmeta` VALUES (59, 47, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (60, 47, '_edit_lock', '1412349113:1') ; 
INSERT INTO `wp_postmeta` VALUES (61, 47, 'post-order', '2') ; 
INSERT INTO `wp_postmeta` VALUES (62, 47, 'question-pre', 'Your second question is...') ; 
INSERT INTO `wp_postmeta` VALUES (63, 47, 'question-main', 'Can you help me?') ; 
INSERT INTO `wp_postmeta` VALUES (64, 47, 'answer', 'Yes, I can.') ; 
INSERT INTO `wp_postmeta` VALUES (65, 47, 'explanation', 'I have helped many people get through difficult times, overcome barriers, find solutions and go on to become the person they always wanted to be.') ; 
INSERT INTO `wp_postmeta` VALUES (70, 49, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (71, 49, '_edit_lock', '1412349228:1') ; 
INSERT INTO `wp_postmeta` VALUES (72, 49, 'post-order', '3') ; 
INSERT INTO `wp_postmeta` VALUES (73, 49, 'question-pre', 'And finally...') ; 
INSERT INTO `wp_postmeta` VALUES (74, 49, 'question-main', 'Can online counselling work for me?') ; 
INSERT INTO `wp_postmeta` VALUES (75, 49, 'answer', 'Yes, it will.') ; 
INSERT INTO `wp_postmeta` VALUES (76, 49, 'explanation', 'In fact, it’s one of the best ways you can get counselling.
You get the benefit of a professional counsellor on your terms, confidential, convenient, night or day, wherever you are. Communicating through secure email exchanges you will receive a response within two business days.') ; 
INSERT INTO `wp_postmeta` VALUES (78, 51, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (79, 51, '_edit_lock', '1412349204:1') ; 
INSERT INTO `wp_postmeta` VALUES (80, 51, 'post-order', '4') ; 
INSERT INTO `wp_postmeta` VALUES (81, 51, 'question-pre', 'Now, I have a question for you.') ; 
INSERT INTO `wp_postmeta` VALUES (82, 51, 'question-main', 'Why have you come to visit me today?') ; 
INSERT INTO `wp_postmeta` VALUES (83, 51, 'answer', 'You aren\'t here by accident.') ; 
INSERT INTO `wp_postmeta` VALUES (84, 51, 'explanation', 'Like millions of others, you’ve decided counselling may help you get through one of the countless situations life puts us all in, through no fault of our own.
You may be struggling with depression, anxiety, phobias, addiction, PTSD or ADHD, and seeking healthy ways to cope.
Perhaps something in your life is causing you distress, and it seems like there is no place to turn for help.
You may have experienced a loss, and you seek a safe, supportive place to talk about it and get through these uncharted waters/difficult times.
Like so many others, you may be looking for help with relationships, or you may simply want to know yourself better in order to gain more control over your life.
Whatever your reason, North Star is here to be your guiding light.
You’ve made a good decision to seek assistance.
Together, we’ll get through this.') ; 
INSERT INTO `wp_postmeta` VALUES (86, 1, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (87, 1, '_wp_trash_meta_time', '1412213237') ; 
INSERT INTO `wp_postmeta` VALUES (88, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}') ; 
INSERT INTO `wp_postmeta` VALUES (92, 51, 'left-justified', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (102, 62, '_wp_attached_file', '2014/10/north-star-logo.png') ; 
INSERT INTO `wp_postmeta` VALUES (103, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:301;s:6:"height";i:165;s:4:"file";s:27:"2014/10/north-star-logo.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"north-star-logo-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"north-star-logo-300x164.png";s:5:"width";i:300;s:6:"height";i:164;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (104, 62, '_edit_lock', '1412309329:1') ; 
INSERT INTO `wp_postmeta` VALUES (105, 63, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (106, 63, '_edit_lock', '1412343432:1') ; 
INSERT INTO `wp_postmeta` VALUES (107, 63, '_wp_page_template', 'page-secondary.php') ; 
INSERT INTO `wp_postmeta` VALUES (108, 63, 'color', '\'#72AE5C\'') ; 
INSERT INTO `wp_postmeta` VALUES (109, 63, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (110, 63, '_wp_trash_meta_time', '1412343576') ; 
INSERT INTO `wp_postmeta` VALUES (111, 65, '_wp_trash_meta_status', 'auto-draft') ; 
INSERT INTO `wp_postmeta` VALUES (112, 65, '_wp_trash_meta_time', '1412344591') ; 
INSERT INTO `wp_postmeta` VALUES (113, 67, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (114, 67, '_edit_lock', '1412344981:1') ; 
INSERT INTO `wp_postmeta` VALUES (115, 67, '_wp_trash_meta_status', 'draft') ; 
INSERT INTO `wp_postmeta` VALUES (116, 67, '_wp_trash_meta_time', '1412345001') ; 
INSERT INTO `wp_postmeta` VALUES (117, 69, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (119, 69, '_edit_lock', '1412348374:1') ; 
INSERT INTO `wp_postmeta` VALUES (120, 69, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (121, 69, '_wp_trash_meta_time', '1412350151') ; 
INSERT INTO `wp_postmeta` VALUES (122, 71, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (123, 71, '_edit_lock', '1412351403:1') ; 
INSERT INTO `wp_postmeta` VALUES (124, 72, '_wp_attached_file', '2014/10/NorthStar_Lights1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (125, 72, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:854;s:6:"height";i:534;s:4:"file";s:29:"2014/10/NorthStar_Lights1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"NorthStar_Lights1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"NorthStar_Lights1-300x187.jpg";s:5:"width";i:300;s:6:"height";i:187;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (126, 71, '_thumbnail_id', '72') ; 
INSERT INTO `wp_postmeta` VALUES (127, 71, '_wp_page_template', 'page-secondary.php') ; 
INSERT INTO `wp_postmeta` VALUES (128, 71, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (129, 71, '_wp_trash_meta_time', '1412351552') ; 
INSERT INTO `wp_postmeta` VALUES (131, 74, '_wp_attached_file', '2014/09/NorthStar_Lights2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (132, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1185;s:6:"height";i:561;s:4:"file";s:29:"2014/09/NorthStar_Lights2.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"NorthStar_Lights2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"NorthStar_Lights2-300x142.jpg";s:5:"width";i:300;s:6:"height";i:142;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"NorthStar_Lights2-1024x484.jpg";s:5:"width";i:1024;s:6:"height";i:484;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (134, 75, '_wp_attached_file', '2014/09/NorthStar_Lights3.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (135, 75, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1138;s:6:"height";i:612;s:4:"file";s:29:"2014/09/NorthStar_Lights3.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"NorthStar_Lights3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"NorthStar_Lights3-300x161.jpg";s:5:"width";i:300;s:6:"height";i:161;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"NorthStar_Lights3-1024x550.jpg";s:5:"width";i:1024;s:6:"height";i:550;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (137, 76, '_wp_attached_file', '2014/09/NorthStar_Lights4.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (138, 76, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1522;s:6:"height";i:612;s:4:"file";s:29:"2014/09/NorthStar_Lights4.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"NorthStar_Lights4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"NorthStar_Lights4-300x120.jpg";s:5:"width";i:300;s:6:"height";i:120;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"NorthStar_Lights4-1024x411.jpg";s:5:"width";i:1024;s:6:"height";i:411;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (143, 78, '_wp_attached_file', '2014/09/NorthStar_Lights5.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (144, 78, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1197;s:6:"height";i:562;s:4:"file";s:29:"2014/09/NorthStar_Lights5.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"NorthStar_Lights5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"NorthStar_Lights5-300x140.jpg";s:5:"width";i:300;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"NorthStar_Lights5-1024x480.jpg";s:5:"width";i:1024;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (145, 13, '_thumbnail_id', '78') ; 
INSERT INTO `wp_postmeta` VALUES (146, 79, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (147, 79, '_edit_lock', '1412707140:2') ; 
INSERT INTO `wp_postmeta` VALUES (148, 80, '_form', '<p>
    [text* your-name class:contact-input placeholder "Name"] </p>

<p>
    [email* your-email class:contact-input placeholder "Email"] </p>

<p>
    [text* your-subject class:contact-input placeholder "Subject"] </p>

<p>
    [textarea* your-message class:contact-input placeholder "Message"] </p>

<button class="alternate-button wpcf7-form-control wpcf7-submit" type="submit">send</button>') ; 
INSERT INTO `wp_postmeta` VALUES (149, 80, '_mail', 'a:8:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:181:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on North Star Counselling (http://localhost:8888)";s:9:"recipient";s:21:"cheryl@localhost:8888";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:1;s:13:"exclude_blank";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (150, 80, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:123:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on North Star Counselling (http://localhost:8888)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (151, 80, '_messages', 'a:21:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}') ; 
INSERT INTO `wp_postmeta` VALUES (152, 80, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (153, 79, '_wp_page_template', 'page-contact.php') ; 
INSERT INTO `wp_postmeta` VALUES (154, 13, 'lets-begin-link', 'http://northstarcounselling.privacemail.com') ; 
INSERT INTO `wp_postmeta` VALUES (155, 13, 'welcome', 'Welcome to North Star.') ; 
INSERT INTO `wp_postmeta` VALUES (156, 13, 'name', 'I\'m Cheryl McDougall') ; 
INSERT INTO `wp_postmeta` VALUES (157, 13, 'cred', 'MSW RSW') ; 
INSERT INTO `wp_postmeta` VALUES (158, 19, 'secondary_page', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (159, 28, 'secondary_page', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (160, 31, 'secondary_page', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (161, 34, 'secondary_page', 'yes') ; 
INSERT INTO `wp_postmeta` VALUES (162, 36, 'secondary_page', 'yes') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 8. October 2014 20:02 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (103 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2014-09-25 20:16:33', '2014-09-25 20:16:33', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world', '', '', '2014-10-01 19:27:17', '2014-10-02 01:27:17', '', 0, 'http://localhost:8888/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2014-09-25 20:16:33', '2014-09-25 20:16:33', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:
<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Montreal, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>
...or something like this:
<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>
As a new WordPress user, you should go to <a href="http://localhost:8888/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Home Page', '', 'trash', 'open', 'open', '', 'sample-page', '', '', '2014-09-26 20:34:43', '2014-09-27 00:34:43', '', 0, 'http://localhost:8888/?page_id=2', 1, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2014-09-26 15:32:41', '2014-09-26 19:32:41', '', 'Home_image', '', 'inherit', 'open', 'open', '', 'home_image', '', '', '2014-09-26 15:32:41', '2014-09-26 19:32:41', '', 0, 'http://localhost:8888/wp-content/uploads/2014/09/Home_image.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2014-09-26 15:32:42', '2014-09-26 19:32:42', '', 'AboutUs_image', '', 'inherit', 'open', 'open', '', 'aboutus_image', '', '', '2014-09-26 15:32:42', '2014-09-26 19:32:42', '', 0, 'http://localhost:8888/wp-content/uploads/2014/09/AboutUs_image.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2014-09-26 15:33:03', '2014-09-26 19:33:03', '', 'north-star-logo', '', 'inherit', 'open', 'open', '', 'north-star-logo', '', '', '2014-09-26 15:36:32', '2014-09-26 19:36:32', '', 7, 'http://localhost:8888/wp-content/uploads/2014/09/north-star-logo.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2014-09-26 15:57:16', '2014-09-26 19:57:16', '<a href="http://localhost:8888/wp-content/uploads/2014/09/north-star-logo.png"><img class="alignnone" src="http://localhost:8888/wp-content/uploads/2014/09/north-star-logo.png" alt="North Star Counselling" /></a>', 'Header', '', 'trash', 'open', 'open', '', 'header', '', '', '2014-10-01 10:48:33', '2014-10-01 16:48:33', '', 0, 'http://localhost:8888/?p=7', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2014-09-26 15:37:14', '2014-09-26 19:37:14', '<a href="http://localhost:8888/wp-content/uploads/2014/09/north-star-logo.png"><img class="alignnone" src="http://localhost:8888/wp-content/uploads/2014/09/north-star-logo.png" alt="North Star Counselling" /></a>', 'Header', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2014-09-26 15:37:14', '2014-09-26 19:37:14', '', 7, 'http://localhost:8888/?p=8', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2014-09-26 19:56:37', '2014-09-26 23:56:37', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:
<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Montreal, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>
...or something like this:
<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>
As a new WordPress user, you should go to <a href="http://localhost:8888/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Home Page', '', 'inherit', 'open', 'open', '', '2-autosave-v1', '', '', '2014-09-26 19:56:37', '2014-09-26 23:56:37', '', 2, 'http://localhost:8888/?p=9', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2014-09-26 15:55:57', '2014-09-26 19:55:57', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Montreal, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost:8888/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2014-09-26 15:55:57', '2014-09-26 19:55:57', '', 2, 'http://localhost:8888/?p=10', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2014-09-26 16:01:22', '2014-09-26 20:01:22', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:
<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Montreal, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>
...or something like this:
<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>
As a new WordPress user, you should go to <a href="http://localhost:8888/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Home Page', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2014-09-26 16:01:22', '2014-09-26 20:01:22', '', 2, 'http://localhost:8888/?p=12', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2014-09-26 20:08:33', '2014-09-27 00:08:33', '<div class="personal-intro">
Welcome to North Star
<span class="large">I\'m Cheryl McDougall.</span>MSW RSW
</div>

<div class="starting-questions">
Before we go any further,
<span class="large">let me put your mind at rest by answering your three most important questions.</span>
</div>', 'Home Page', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-10-05 13:25:31', '2014-10-05 19:25:31', '', 0, 'http://localhost:8888/?page_id=13', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2014-09-26 20:07:48', '2014-09-27 00:07:48', '', 'HOME', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-09-26 20:07:48', '2014-09-27 00:07:48', '', 13, 'http://localhost:8888/?p=14', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2014-09-26 20:35:18', '2014-09-27 00:35:18', '', 'Home Page', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-09-26 20:35:18', '2014-09-27 00:35:18', '', 13, 'http://localhost:8888/?p=15', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (16, 1, '2014-09-26 20:47:46', '2014-09-27 00:47:46', 'Welcome to North Star.

<span class="large">I\'m Cheryl McDougall.</span>

MSW RSW', 'personal-intro', '', 'trash', 'open', 'open', '', 'personal-intro', '', '', '2014-10-01 10:48:33', '2014-10-01 16:48:33', '', 0, 'http://localhost:8888/?p=16', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2014-09-26 20:47:46', '2014-09-27 00:47:46', 'Welcome to North Star.

<span class="large">I\'m Cheryl McDougall.</span>

MSW RSW', 'personal-intro', '', 'inherit', 'open', 'open', '', '16-revision-v1', '', '', '2014-09-26 20:47:46', '2014-09-27 00:47:46', '', 16, 'http://localhost:8888/?p=17', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (19, 1, '2014-09-29 13:42:29', '2014-09-29 19:42:29', '<h2>Hello. I’m Cheryl, the founder and lead counsellor at North Star.</h2>
I have a Masters Degree in Social Work and I have been counselling people for over 16 years. As a social worker I have a passion for helping people through the challenges they are facing.

People, like you, who want a little assistance in finding alternative solutions in their life. But don’t know where to start. Maybe you are too remote or too busy or have been hesitant to seek guidance. That does not change the fact that everyone needs a little help to find their way.
<h3>Ecounselling is the answer.</h3>
It’s easy, convenient and completely confidential.

We engage in a conversation, just as we would face-to-face, only we will be online. I introduce myself, and then you tell me a bit about yourself. You share with me your issue, and within 2 business days I respond with some ideas, thoughts and options on how you can move forward. We’ll carry on our online conversation as long as you need.
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>
<h3>Why North Star.</h3>
My mission is to guide you through difficulties. This is why I chose the name North Star. The North Star has been a guiding light for people to find their way in the world. We will be the guiding light for you! To help you find the way through the trials and tribulations of life. This is done through a goal directed collaborative approach. Personal change is constant. We will bring awareness and facilitate movement towards goals you have identified.', 'About Us', '', 'publish', 'open', 'closed', '', 'about', '', '', '2014-10-05 17:45:58', '2014-10-05 23:45:58', '', 0, 'http://localhost:8888/?page_id=19', 1, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2014-09-29 13:41:53', '2014-09-29 17:41:53', '<h1>About Us</h1>
<h2>Hello. I’m Cheryl, the founder and lead counsellor at North Star.</h2>
<p>
I have a Masters Degree in Social Work and I have been counselling people for over 16 years. As a social worker I have a passion for helping people through the challenges they are facing.
          </p>
          <p>
            People, like you, who want a little assistance in finding alternative solutions in their life. But don’t know where to start. Maybe you are too remote or too busy or have been hesitant to seek guidance. That does not change the fact that everyone needs a little help to find their way.
          </p>
          <br>
          <h3>
            Ecounselling is the answer.
          </h3>
          <p>
            It’s easy, convenient and completely confidential.
          </p>
          <p>
            We engage in a conversation, just as we would face-to-face, only we will be online. I introduce myself, and then you tell me a bit about yourself. You share with me your issue, and within 2 business days I respond with some ideas, thoughts and options on how you can move forward. We’ll carry on our online conversation as long as you need.
          </p>
          <a href="#">
            <button class="alternate-button">Let\'s begin...</button>
          </a>
          <!-- <a href="#" class="alternate-button">Let\'s begin...</a> -->
          <h3>
            Why North Star.
          </h3>
          <p>
            My mission is to guide you through difficulties. This is why I chose the name North Star. The North Star has been a guiding light for people to find their way in the world. We will be the guiding light for you! To help you find the way through the trials and tribulations of life. This is done through a goal directed collaborative approach. Personal change is constant. We will bring awareness and facilitate movement towards goals you have identified.
          </p>
        </div>', 'About Page', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2014-09-29 13:41:53', '2014-09-29 17:41:53', '', 19, 'http://localhost:8888/?p=20', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2014-09-29 13:42:29', '2014-09-29 17:42:29', '<h1>About Us</h1>
<h2>Hello. I’m Cheryl, the founder and lead counsellor at North Star.</h2>
<p>
     I have a Masters Degree in Social Work and I have been counselling people for over 16 years. As a social worker I have a passion for helping people through the challenges they are facing.
</p>
          <p>
            People, like you, who want a little assistance in finding alternative solutions in their life. But don’t know where to start. Maybe you are too remote or too busy or have been hesitant to seek guidance. That does not change the fact that everyone needs a little help to find their way.
          </p>
          <br>
          <h3>
            Ecounselling is the answer.
          </h3>
          <p>
            It’s easy, convenient and completely confidential.
          </p>
          <p>
            We engage in a conversation, just as we would face-to-face, only we will be online. I introduce myself, and then you tell me a bit about yourself. You share with me your issue, and within 2 business days I respond with some ideas, thoughts and options on how you can move forward. We’ll carry on our online conversation as long as you need.
          </p>
          <a href="#">
            <button class="alternate-button">Let\'s begin...</button>
          </a>
          <!-- <a href="#" class="alternate-button">Let\'s begin...</a> -->
          <h3>
            Why North Star.
          </h3>
          <p>
            My mission is to guide you through difficulties. This is why I chose the name North Star. The North Star has been a guiding light for people to find their way in the world. We will be the guiding light for you! To help you find the way through the trials and tribulations of life. This is done through a goal directed collaborative approach. Personal change is constant. We will bring awareness and facilitate movement towards goals you have identified.
          </p>
        </div>', 'About Page', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2014-09-29 13:42:29', '2014-09-29 17:42:29', '', 19, 'http://localhost:8888/?p=21', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2014-09-29 14:34:02', '2014-09-29 18:34:02', '<h2>Hello. I’m Cheryl, the founder and lead counsellor at North Star.</h2>
I have a Masters Degree in Social Work and I have been counselling people for over 16 years. As a social worker I have a passion for helping people through the challenges they are facing.

People, like you, who want a little assistance in finding alternative solutions in their life. But don’t know where to start. Maybe you are too remote or too busy or have been hesitant to seek guidance. That does not change the fact that everyone needs a little help to find their way.
&nbsp;
<h3>Ecounselling is the answer.</h3>
It’s easy, convenient and completely confidential.

We engage in a conversation, just as we would face-to-face, only we will be online. I introduce myself, and then you tell me a bit about yourself. You share with me your issue, and within 2 business days I respond with some ideas, thoughts and options on how you can move forward. We’ll carry on our online conversation as long as you need.
<a href="#">
<button class="alternate-button">Let\'s begin...</button>
</a>
<h3>Why North Star.</h3>
My mission is to guide you through difficulties. This is why I chose the name North Star. The North Star has been a guiding light for people to find their way in the world. We will be the guiding light for you! To help you find the way through the trials and tribulations of life. This is done through a goal directed collaborative approach. Personal change is constant. We will bring awareness and facilitate movement towards goals you have identified.', 'About Us', '', 'inherit', 'open', 'open', '', '19-autosave-v1', '', '', '2014-09-29 14:34:02', '2014-09-29 18:34:02', '', 19, 'http://localhost:8888/?p=22', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (23, 1, '2014-09-29 14:27:57', '2014-09-29 18:27:57', '<h2>Hello. I’m Cheryl, the founder and lead counsellor at North Star.</h2>
I have a Masters Degree in Social Work and I have been counselling people for over 16 years. As a social worker I have a passion for helping people through the challenges they are facing.

People, like you, who want a little assistance in finding alternative solutions in their life. But don’t know where to start. Maybe you are too remote or too busy or have been hesitant to seek guidance. That does not change the fact that everyone needs a little help to find their way.

&nbsp;
<h3>Ecounselling is the answer.</h3>
It’s easy, convenient and completely confidential.

We engage in a conversation, just as we would face-to-face, only we will be online. I introduce myself, and then you tell me a bit about yourself. You share with me your issue, and within 2 business days I respond with some ideas, thoughts and options on how you can move forward. We’ll carry on our online conversation as long as you need.

<a href="#">
<button class="alternate-button">Let\'s begin...</button>
</a>
<!-- <a href="#" class="alternate-button">Let\'s begin...</a> -->
<h3>Why North Star.</h3>
My mission is to guide you through difficulties. This is why I chose the name North Star. The North Star has been a guiding light for people to find their way in the world. We will be the guiding light for you! To help you find the way through the trials and tribulations of life. This is done through a goal directed collaborative approach. Personal change is constant. We will bring awareness and facilitate movement towards goals you have identified.', 'About Us', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2014-09-29 14:27:57', '2014-09-29 18:27:57', '', 19, 'http://localhost:8888/?p=23', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2014-09-29 14:32:30', '2014-09-29 18:32:30', '<h2>Hello. I’m Cheryl, the founder and lead counsellor at North Star.</h2>
I have a Masters Degree in Social Work and I have been counselling people for over 16 years. As a social worker I have a passion for helping people through the challenges they are facing.

People, like you, who want a little assistance in finding alternative solutions in their life. But don’t know where to start. Maybe you are too remote or too busy or have been hesitant to seek guidance. That does not change the fact that everyone needs a little help to find their way.

<h3>Ecounselling is the answer.</h3>
It’s easy, convenient and completely confidential.

We engage in a conversation, just as we would face-to-face, only we will be online. I introduce myself, and then you tell me a bit about yourself. You share with me your issue, and within 2 business days I respond with some ideas, thoughts and options on how you can move forward. We’ll carry on our online conversation as long as you need.

<a href="#">
<button class="alternate-button">Let\'s begin...</button>
</a>
<!-- <a href="#" class="alternate-button">Let\'s begin...</a> -->
<h3>Why North Star.</h3>
My mission is to guide you through difficulties. This is why I chose the name North Star. The North Star has been a guiding light for people to find their way in the world. We will be the guiding light for you! To help you find the way through the trials and tribulations of life. This is done through a goal directed collaborative approach. Personal change is constant. We will bring awareness and facilitate movement towards goals you have identified.', 'About Us', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2014-09-29 14:32:30', '2014-09-29 18:32:30', '', 19, 'http://localhost:8888/?p=24', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2014-09-29 14:33:00', '2014-09-29 18:33:00', '<h2>Hello. I’m Cheryl, the founder and lead counsellor at North Star.</h2>
I have a Masters Degree in Social Work and I have been counselling people for over 16 years. As a social worker I have a passion for helping people through the challenges they are facing.

People, like you, who want a little assistance in finding alternative solutions in their life. But don’t know where to start. Maybe you are too remote or too busy or have been hesitant to seek guidance. That does not change the fact that everyone needs a little help to find their way.
&nbsp;
<h3>Ecounselling is the answer.</h3>
It’s easy, convenient and completely confidential.

We engage in a conversation, just as we would face-to-face, only we will be online. I introduce myself, and then you tell me a bit about yourself. You share with me your issue, and within 2 business days I respond with some ideas, thoughts and options on how you can move forward. We’ll carry on our online conversation as long as you need.

<a href="#">
<button class="alternate-button">Let\'s begin...</button>
</a>
<!-- <a href="#" class="alternate-button">Let\'s begin...</a> -->
<h3>Why North Star.</h3>
My mission is to guide you through difficulties. This is why I chose the name North Star. The North Star has been a guiding light for people to find their way in the world. We will be the guiding light for you! To help you find the way through the trials and tribulations of life. This is done through a goal directed collaborative approach. Personal change is constant. We will bring awareness and facilitate movement towards goals you have identified.', 'About Us', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2014-09-29 14:33:00', '2014-09-29 18:33:00', '', 19, 'http://localhost:8888/?p=25', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2014-09-29 14:34:53', '2014-09-29 18:34:53', '<h2>Hello. I’m Cheryl, the founder and lead counsellor at North Star.</h2>
I have a Masters Degree in Social Work and I have been counselling people for over 16 years. As a social worker I have a passion for helping people through the challenges they are facing.

People, like you, who want a little assistance in finding alternative solutions in their life. But don’t know where to start. Maybe you are too remote or too busy or have been hesitant to seek guidance. That does not change the fact that everyone needs a little help to find their way.
<br>
<h3>Ecounselling is the answer.</h3>
It’s easy, convenient and completely confidential.

We engage in a conversation, just as we would face-to-face, only we will be online. I introduce myself, and then you tell me a bit about yourself. You share with me your issue, and within 2 business days I respond with some ideas, thoughts and options on how you can move forward. We’ll carry on our online conversation as long as you need.
<a href="#">
<button class="alternate-button">Let\'s begin...</button>
</a>
<h3>Why North Star.</h3>
My mission is to guide you through difficulties. This is why I chose the name North Star. The North Star has been a guiding light for people to find their way in the world. We will be the guiding light for you! To help you find the way through the trials and tribulations of life. This is done through a goal directed collaborative approach. Personal change is constant. We will bring awareness and facilitate movement towards goals you have identified.', 'About Us', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2014-09-29 14:34:53', '2014-09-29 18:34:53', '', 19, 'http://localhost:8888/?p=26', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2014-09-29 14:35:42', '2014-09-29 18:35:42', '<h2>Hello. I’m Cheryl, the founder and lead counsellor at North Star.</h2>
I have a Masters Degree in Social Work and I have been counselling people for over 16 years. As a social worker I have a passion for helping people through the challenges they are facing.

People, like you, who want a little assistance in finding alternative solutions in their life. But don’t know where to start. Maybe you are too remote or too busy or have been hesitant to seek guidance. That does not change the fact that everyone needs a little help to find their way.
&nbsp;
<h3>Ecounselling is the answer.</h3>
It’s easy, convenient and completely confidential.

We engage in a conversation, just as we would face-to-face, only we will be online. I introduce myself, and then you tell me a bit about yourself. You share with me your issue, and within 2 business days I respond with some ideas, thoughts and options on how you can move forward. We’ll carry on our online conversation as long as you need.
<a href="#">
<button class="alternate-button">Let\'s begin...</button>
</a>
<h3>Why North Star.</h3>
My mission is to guide you through difficulties. This is why I chose the name North Star. The North Star has been a guiding light for people to find their way in the world. We will be the guiding light for you! To help you find the way through the trials and tribulations of life. This is done through a goal directed collaborative approach. Personal change is constant. We will bring awareness and facilitate movement towards goals you have identified.', 'About Us', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2014-09-29 14:35:42', '2014-09-29 18:35:42', '', 19, 'http://localhost:8888/?p=27', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2014-09-30 11:22:09', '2014-09-30 17:22:09', '<h2>
	Counselling works to solve a wide range of problems. We work with individuals, couples and families to overcome a number of different issues, including:
</h2>
<ul>
	<li>Anger (non-violent)</li>
	<li>Anxiety</li>
	<li>Assertiveness</li>
	<li>Career and work related issues</li>
	<li>Conflict resolution</li>
	<li>Depression</li>
	<li>Divorce and separation</li>
	<li>Grief and loss</li>
	<li>Isolation</li>
	<li>Intimacy</li>
	<li>Marital and relationship problems</li>
	<li>Midlife transition</li>
	<li>Personal growth</li>
	<li>Self-esteem</li>
	<li>Sexuality – LBGTQ</li>
	<li>Stress management</li>
	<li>Relationships/dating</li>
</ul>
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'How we can help', '', 'publish', 'open', 'closed', '', 'how-we-can-help', '', '', '2014-10-05 15:45:48', '2014-10-05 21:45:48', '', 0, 'http://localhost:8888/?page_id=28', 2, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (29, 1, '2014-09-30 11:22:09', '2014-09-30 17:22:09', '<h2>
	Counselling works to solve a wide range of problems. We work with individuals, couples and families to overcome a number of different issues, including:
</h2>
<ul>
	<li>Anger (non-violent)</li>
	<li>Anxiety</li>
	<li>Assertiveness</li>
	<li>Career and work related issues</li>
	<li>Conflict resolution</li>
	<li>Depression</li>
	<li>Divorce and separation</li>
	<li>Grief and loss</li>
	<li>Isolation</li>
	<li>Intimacy</li>
	<li>Marital and relationship problems</li>
	<li>Midlife transition</li>
	<li>Personal growth</li>
	<li>Self-esteem</li>
	<li>Sexuality – LBGTQ</li>
	<li>Stress management</li>
	<li>Relationships/dating</li>
</ul>', 'How we can help', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2014-09-30 11:22:09', '2014-09-30 17:22:09', '', 28, 'http://localhost:8888/?p=29', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2014-09-30 11:32:52', '2014-09-30 17:32:52', '<h2>
	Counselling works to solve a wide range of problems. We work with individuals, couples and families to overcome a number of different issues, including:
</h2>
<ul>
	<li>Anger (non-violent)</li>
	<li>Anxiety</li>
	<li>Assertiveness</li>
	<li>Career and work related issues</li>
	<li>Conflict resolution</li>
	<li>Depression</li>
	<li>Divorce and separation</li>
	<li>Grief and loss</li>
	<li>Isolation</li>
	<li>Intimacy</li>
	<li>Marital and relationship problems</li>
	<li>Midlife transition</li>
	<li>Personal growth</li>
	<li>Self-esteem</li>
	<li>Sexuality – LBGTQ</li>
	<li>Stress management</li>
	<li>Relationships/dating</li>
</ul>
<a href="#">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'How we can help', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2014-09-30 11:32:52', '2014-09-30 17:32:52', '', 28, 'http://localhost:8888/?p=30', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2014-09-30 13:13:52', '2014-09-30 19:13:52', '<h2>
	Professional Counselling
	Completely Confidential
	Anonymous
	and Secure.
</h2>
<p>
	It is simply taking therapy online to overcome issues like distance and accessability. Also known as e-therapy, <span style="white-space:nowrap;">e-counseling,</span> tele-therapy or cyber-counseling, it emerged on the internet in about 1982.
</p>
<p>
	Distance counselling has been used as far back as the 1920s when Sigmund Freud utilized letters to communicate with his clients. Today online counselling is quite widespread.
</p>
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'What is online counselling', '', 'publish', 'open', 'closed', '', 'what-is-online-counselling', '', '', '2014-10-07 16:43:07', '2014-10-07 22:43:07', '', 0, 'http://localhost:8888/?page_id=31', 3, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2014-09-30 13:13:52', '2014-09-30 19:13:52', '<h2>
	Professional Counselling
	Completely Confidential
	Anonymous
	and Secure.
</h2>
<p>
	It is simply taking therapy online to overcome issues like distance and accessability. Also known as e-therapy, e-counseling, tele-therapy or cyber-counseling, it emerged on the internet in about 1982.
</p>
<p>
	Distance counselling has been used as far back as the 1920s when Sigmund Freud utilized letters to communicate with his clients. Today online counselling is quite widespread.
</p>', 'What is online counselling', '', 'inherit', 'open', 'open', '', '31-revision-v1', '', '', '2014-09-30 13:13:52', '2014-09-30 19:13:52', '', 31, 'http://localhost:8888/?p=32', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (33, 1, '2014-09-30 13:14:50', '2014-09-30 19:14:50', '<h2>
	Professional Counselling
	Completely Confidential
	Anonymous
	and Secure.
</h2>
<p>
	It is simply taking therapy online to overcome issues like distance and accessability. Also known as e-therapy, e-counseling, tele-therapy or cyber-counseling, it emerged on the internet in about 1982.
</p>
<p>
	Distance counselling has been used as far back as the 1920s when Sigmund Freud utilized letters to communicate with his clients. Today online counselling is quite widespread.
</p>
<a href="#">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'What is online counselling', '', 'inherit', 'open', 'open', '', '31-revision-v1', '', '', '2014-09-30 13:14:50', '2014-09-30 19:14:50', '', 31, 'http://localhost:8888/?p=33', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (34, 1, '2014-09-30 13:21:07', '2014-09-30 19:21:07', '<h2>
	Confidential
	Easy
	Convenient
	and Successful.
</h2>
<p>
	Just as we would face-to-face, we engage in a discussion, only we’ll be online. I introduce myself, then you tell me a bit about yourself and your issue, and within 2 business days I respond with some ideas, thoughts and options/suggestions on how you can choose move forward.
</p>
<p>
	Just like emailing a friend back and forth.
</p>
<p>
	We’ll carry on our online discussion as long as needed.
</p>
<p>
	What if you develop a crisis and need immediate assistance
	while working with me? Send me an email marked urgent. I
	check my emails several times a day. However, any serious
	life threatening thoughts to yourself or others should be
	addressed immediately by calling your local crisis line or 9-1-1.
</p>
<a href="http://northstarcounselling.privacemail.com/">
	<button class="alternate-button">Let\'s begin...</button>
</a>', 'How it works', '', 'publish', 'open', 'closed', '', 'how-it-works', '', '', '2014-10-05 15:47:27', '2014-10-05 21:47:27', '', 0, 'http://localhost:8888/?page_id=34', 4, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (35, 1, '2014-09-30 13:21:07', '2014-09-30 19:21:07', '<h2>
	Confidential
	Easy
	Convenient
	and Successful.
</h2>
<p>
	Just as we would face-to-face, we engage in a discussion, only we’ll be online. I introduce myself, then you tell me a bit about yourself and your issue, and within 2 business days I respond with some ideas, thoughts and options/suggestions on how you can choose move forward.
</p>
<p>
	Just like emailing a friend back and forth.
</p>
<p>
	We’ll carry on our online discussion as long as needed.
</p>
<p>
	What if you develop a crisis and need immediate assistance
	while working with me? Send me an email marked urgent. I
	check my emails several times a day. However, any serious
	life threatening thoughts to yourself or others should be
	addressed immediately by calling your local crisis line or 9-1-1.
</p>
<a href="#">
	<button class="alternate-button">Let\'s begin...</button>
</a>', 'How it works', '', 'inherit', 'open', 'open', '', '34-revision-v1', '', '', '2014-09-30 13:21:07', '2014-09-30 19:21:07', '', 34, 'http://localhost:8888/?p=35', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (36, 1, '2014-09-30 13:26:05', '2014-09-30 19:26:05', '<h2>
	Easy, convenient, and for a
	modest fee.
</h2>
<p>
	You’ll find my fees are relatively low for one simple reason: As an on line counsellor, I work out of my home, so I do not need to cover the expensive overhead of an office.
</p>
<p>
	This means you can get effective counselling on your terms.
</p>
<p>
	The first half hour is free. This is a chance to get to know one another and become familiar with your issue.
</p>
<p>
	After that, the fee is $90.00 per hour. Payment is made through a Pay Pal account. If you don’t have one yet, it is very easy to set up.
</p>
<a href="http://northstarcounselling.privacemail.com/">
	<button class="alternate-button">Let\'s begin...</button>
</a>', 'Fees', '', 'publish', 'open', 'closed', '', 'fees', '', '', '2014-10-05 15:47:59', '2014-10-05 21:47:59', '', 0, 'http://localhost:8888/?page_id=36', 5, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (37, 1, '2014-09-30 13:26:05', '2014-09-30 19:26:05', '<h2>
	Easy, convenient, and for a
	modest fee.
</h2>
<p>
	You’ll find my fees are relatively low for one simple reason: As an on line counsellor, I work out of my home, so I do not need to cover the expensive overhead of an office.
</p>
<p>
	This means you can get effective counselling on your terms.
</p>
<p>
	The first half hour is free. This is a chance to get to know one another and become familiar with your issue.
</p>
<p>
	After that, the fee is $90.00 per hour. Payment is made through a Pay Pal account. If you don’t have one yet, it is very easy to set up.
</p>
<a href="#">
	<button class="alternate-button">Let\'s begin...</button>
</a>', 'Fees', '', 'inherit', 'open', 'open', '', '36-revision-v1', '', '', '2014-09-30 13:26:05', '2014-09-30 19:26:05', '', 36, 'http://localhost:8888/?p=37', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (38, 1, '2014-10-01 11:25:45', '2014-10-01 17:25:45', 'It helps millions every day in all walks of life, with all kinds of problems. 
It helps the young and the old, the rich and the poor, the ones who have made it and the ones on their way. It will help you.', 'Question #1', '', 'publish', 'open', 'open', '', 'your-first-and-most-important-question', '', '', '2014-10-03 09:15:57', '2014-10-03 15:15:57', '', 0, 'http://localhost:8888/?p=38', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (39, 1, '2014-10-01 11:10:13', '2014-10-01 17:10:13', '', 'Draft created on October 1, 2014 at 5:10 pm', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2014-10-01 11:10:13', '2014-10-01 17:10:13', '', 38, 'http://localhost:8888/?p=39', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (40, 1, '2014-10-01 11:25:45', '2014-10-01 17:25:45', '<div class="question">
<header>
<span>Your first, and most important question.</span>
<h2>Can counselling work for me?</h2>
</header>
</div>
<a href="#panel1" class="circle">
<i class="fi-arrow-down"></i>
</a>
<div id="panel1" class="content answer">
<span class="large">Yes it can.</span>
<p>
It helps millions every day in all walks of life, with all kinds of problems. It helps the young and the old, the rich and the poor, the ones who have made it and the ones on their way. It will help you.
</p>
</div>', 'Your first, and most important question.', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2014-10-01 11:25:45', '2014-10-01 17:25:45', '', 38, 'http://localhost:8888/?p=40', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2014-10-01 15:29:21', '2014-10-01 21:29:21', '<div class="question">
<header>
<span>Your first, and most important question.</span>
<h2>Can counselling work for me?</h2>
</header>
</div><a href="#panel1" class="circle">
<i class="fi-arrow-down"></i>
</a>
<div id="panel1" class="content answer">
<span class="large">Yes it can.</span>
<p>
It helps millions every day in all walks of life, with all kinds of problems. It helps the young and the old, the rich and the poor, the ones who have made it and the ones on their way. It will help you.
</p>
</div>', 'Your first, and most important question.', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2014-10-01 15:29:21', '2014-10-01 21:29:21', '', 38, 'http://localhost:8888/?p=41', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (42, 1, '2014-10-01 16:00:06', '2014-10-01 22:00:06', '<div class="question">
<header>
<span>Your first, and most important question.</span><h2>Can counselling work for me?</h2>
</header>
</div><a href="#panel1" class="circle"><i class="fi-arrow-down"></i></a>
<div id="panel1" class="content answer">
<span class="large">Yes it can.</span>
<p>
It helps millions every day in all walks of life, with all kinds of problems. It helps the young and the old, the rich and the poor, the ones who have made it and the ones on their way. It will help you.
</p>
</div>', 'Your first, and most important question.', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2014-10-01 16:00:06', '2014-10-01 22:00:06', '', 38, 'http://localhost:8888/?p=42', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (43, 1, '2014-10-01 18:16:40', '2014-10-02 00:16:40', '', 'Your first, and most important question.', '', 'inherit', 'open', 'open', '', '38-autosave-v1', '', '', '2014-10-01 18:16:40', '2014-10-02 00:16:40', '', 38, 'http://localhost:8888/?p=43', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (44, 1, '2014-10-01 16:49:54', '2014-10-01 22:49:54', '<div class="question"><header>Your first, and most important question.
<h2>Can counselling work for me?</h2>
</header></div>
&nbsp;
<div id="panel1" class="content answer">
<span class="large">Yes it can.</span>It helps millions every day in all walks of life, with all kinds of problems. It helps the young and the old, the rich and the poor, the ones who have made it and the ones on their way. It will help you.

</div>', 'Your first, and most important question.', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2014-10-01 16:49:54', '2014-10-01 22:49:54', '', 38, 'http://localhost:8888/?p=44', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (45, 1, '2014-10-01 18:16:53', '2014-10-02 00:16:53', '', 'Question #1', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2014-10-01 18:16:53', '2014-10-02 00:16:53', '', 38, 'http://localhost:8888/?p=45', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (46, 1, '2014-10-01 18:25:00', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-01 18:25:00', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=46', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (47, 1, '2014-10-01 18:45:43', '2014-10-02 00:45:43', 'I have helped many people get through difficult times, overcome barriers, find solutions and go on to become the person they always wanted to be.', 'Question #2', '', 'publish', 'open', 'open', '', 'question-2', '', '', '2014-10-03 09:14:13', '2014-10-03 15:14:13', '', 0, 'http://localhost:8888/?p=47', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (48, 1, '2014-10-01 18:45:43', '2014-10-02 00:45:43', '', 'Question #2', '', 'inherit', 'open', 'open', '', '47-revision-v1', '', '', '2014-10-01 18:45:43', '2014-10-02 00:45:43', '', 47, 'http://localhost:8888/?p=48', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2014-10-01 19:12:17', '2014-10-02 01:12:17', 'In fact, it’s one of the best ways you can get counselling.
You get the benefit of a professional counsellor on your terms, confidential, convenient, night or day, wherever you are. Communicating through secure email exchanges you will receive a response within two business days.', 'Question #3', '', 'publish', 'open', 'open', '', 'question-3', '', '', '2014-10-03 09:16:06', '2014-10-03 15:16:06', '', 0, 'http://localhost:8888/?p=49', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2014-10-01 19:12:17', '2014-10-02 01:12:17', '', 'Question #3', '', 'inherit', 'open', 'open', '', '49-revision-v1', '', '', '2014-10-01 19:12:17', '2014-10-02 01:12:17', '', 49, 'http://localhost:8888/?p=50', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2014-10-01 19:16:18', '2014-10-02 01:16:18', 'Like millions of others, you’ve decided counselling may help you get through one of the countless situations life puts us all in, through no fault of our own.

You may be struggling with depression, anxiety, phobias, addiction, PTSD or ADHD, and seeking healthy ways to cope.

Perhaps something in your life is causing you distress, and it seems like there is no place to turn for help.

You may have experienced a loss, and you seek a safe, supportive place to talk about it and get through these uncharted waters/difficult times.

Like so many others, you may be looking for help with relationships, or you may simply want to know yourself better in order to gain more control over your life.

Whatever your reason, North Star is here to be your guiding light.

You’ve made a good decision to seek assistance.
Together, we’ll get through this.', 'Question #4', '', 'publish', 'open', 'open', '', 'question-4', '', '', '2014-10-03 09:15:42', '2014-10-03 15:15:42', '', 0, 'http://localhost:8888/?p=51', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (52, 1, '2014-10-01 19:16:18', '2014-10-02 01:16:18', '', 'Question #4', '', 'inherit', 'open', 'open', '', '51-revision-v1', '', '', '2014-10-01 19:16:18', '2014-10-02 01:16:18', '', 51, 'http://localhost:8888/?p=52', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2014-10-01 19:27:17', '2014-10-02 01:27:17', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-10-01 19:27:17', '2014-10-02 01:27:17', '', 1, 'http://localhost:8888/?p=53', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (54, 1, '2014-10-02 21:25:28', '2014-10-03 03:25:28', 'Like millions of others, you’ve decided counselling may help you get through one of the countless situations life puts us all in, through no fault of our own.

You may be struggling with depression, anxiety, phobias, addiction, PTSD or ADHD, and seeking healthy ways to cope.

Perhaps something in your life is causing you distress, and it seems like there is no place to turn for help.
You may have experienced a loss, and you seek a safe, supportive place to talk about it and get through these uncharted waters/difficult times.
Like so many others, you may be looking for help with relationships, or you may simply want to know yourself better in order to gain more control over your life.
Whatever your reason, North Star is here to be your guiding light.
You’ve made a good decision to seek assistance.
Together, we’ll get through this.', 'Question #4', '', 'inherit', 'open', 'open', '', '51-autosave-v1', '', '', '2014-10-02 21:25:28', '2014-10-03 03:25:28', '', 51, 'http://localhost:8888/?p=54', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (55, 1, '2014-10-02 21:25:51', '2014-10-03 03:25:51', 'Like millions of others, you’ve decided counselling may help you get through one of the countless situations life puts us all in, through no fault of our own.

You may be struggling with depression, anxiety, phobias, addiction, PTSD or ADHD, and seeking healthy ways to cope.

Perhaps something in your life is causing you distress, and it seems like there is no place to turn for help.

You may have experienced a loss, and you seek a safe, supportive place to talk about it and get through these uncharted waters/difficult times.

Like so many others, you may be looking for help with relationships, or you may simply want to know yourself better in order to gain more control over your life.

Whatever your reason, North Star is here to be your guiding light.

You’ve made a good decision to seek assistance.
Together, we’ll get through this.', 'Question #4', '', 'inherit', 'open', 'open', '', '51-revision-v1', '', '', '2014-10-02 21:25:51', '2014-10-03 03:25:51', '', 51, 'http://localhost:8888/?p=55', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (56, 1, '2014-10-02 21:26:22', '2014-10-03 03:26:22', 'In fact, it’s one of the best ways you can get counselling.
You get the benefit of a professional counsellor on your terms, confidential, convenient, night or day, wherever you are. Communicating through secure email exchanges you will receive a response within two business days.', 'Question #3', '', 'inherit', 'open', 'open', '', '49-revision-v1', '', '', '2014-10-02 21:26:22', '2014-10-03 03:26:22', '', 49, 'http://localhost:8888/?p=56', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (57, 1, '2014-10-02 21:27:24', '2014-10-03 03:27:24', 'I have helped many people get through difficult times, overcome barriers, find solutions and go on to become the person they always wanted to be.', 'Question #2', '', 'inherit', 'open', 'open', '', '47-revision-v1', '', '', '2014-10-02 21:27:24', '2014-10-03 03:27:24', '', 47, 'http://localhost:8888/?p=57', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (58, 1, '2014-10-02 21:27:49', '2014-10-03 03:27:49', 'It helps millions every day in all walks of life, with all kinds of problems. It helps the young and the old, the rich and the poor, the ones who have made it and the ones on their way. It will help you.', 'Question #1', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2014-10-02 21:27:49', '2014-10-03 03:27:49', '', 38, 'http://localhost:8888/?p=58', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (59, 1, '2014-10-02 21:32:11', '2014-10-03 03:32:11', 'It helps millions every day in all walks of life, with all kinds of problems. 
It helps the young and the old, the rich and the poor, the ones who have made it and the ones on their way. It will help you.', 'Question #1', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2014-10-02 21:32:11', '2014-10-03 03:32:11', '', 38, 'http://localhost:8888/?p=59', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (60, 1, '2014-10-02 21:33:49', '2014-10-03 03:33:49', 'I have helped many people get through difficult times, overcome barriers, 
find solutions and go on to become the person they always wanted to be.', 'Question #2', '', 'inherit', 'open', 'open', '', '47-revision-v1', '', '', '2014-10-02 21:33:49', '2014-10-03 03:33:49', '', 47, 'http://localhost:8888/?p=60', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (61, 1, '2014-10-02 21:34:08', '2014-10-03 03:34:08', 'I have helped many people get through difficult times, overcome barriers, find solutions and go on to become the person they always wanted to be.', 'Question #2', '', 'inherit', 'open', 'open', '', '47-revision-v1', '', '', '2014-10-02 21:34:08', '2014-10-03 03:34:08', '', 47, 'http://localhost:8888/?p=61', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (62, 1, '2014-10-02 21:48:55', '2014-10-03 03:48:55', '', 'north-star-logo', '', 'inherit', 'open', 'open', '', 'north-star-logo-2', '', '', '2014-10-02 21:48:55', '2014-10-03 03:48:55', '', 0, 'http://localhost:8888/wp-content/uploads/2014/10/north-star-logo.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (63, 1, '2014-10-02 22:21:12', '2014-10-03 04:21:12', 'Sed ut metus nec dui posuere consequat. Sed vel sodales ex, in placerat odio. Quisque pharetra efficitur velit, et efficitur sem hendrerit condimentum. Integer dignissim augue eget justo tristique, in imperdiet augue suscipit. Nulla eget velit et nisi luctus lacinia. Nulla eleifend tortor ac velit luctus dignissim. In hac habitasse platea dictumst. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Fusce mattis interdum dolor vitae pharetra. Vestibulum sed venenatis purus, at scelerisque magna. Integer ut diam ornare, vestibulum erat vel, cursus est. Nam a ullamcorper justo. Praesent finibus volutpat convallis.

Mauris urna urna, iaculis ullamcorper sem quis, dapibus tristique augue. Praesent semper elit a odio varius consectetur. Aenean facilisis felis sed nulla semper maximus. Maecenas eu ornare sem, nec sagittis libero. Duis quis quam odio. Suspendisse consequat sed nulla at pretium. Maecenas venenatis tortor maximus mi facilisis posuere. Praesent vulputate placerat nunc. Sed ac ligula quis risus efficitur fringilla. Aliquam feugiat eu est in pulvinar. Nulla nisl neque, feugiat et tellus eu, bibendum dignissim ex. Nullam nec gravida elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Pellentesque sed accumsan massa. Pellentesque in purus lacus. Integer tempus urna nec nisi viverra, at feugiat arcu euismod.', 'TEST', '', 'trash', 'open', 'open', '', 'test', '', '', '2014-10-03 07:39:36', '2014-10-03 13:39:36', '', 13, 'http://localhost:8888/?page_id=63', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (64, 1, '2014-10-02 22:21:12', '2014-10-03 04:21:12', 'Sed ut metus nec dui posuere consequat. Sed vel sodales ex, in placerat odio. Quisque pharetra efficitur velit, et efficitur sem hendrerit condimentum. Integer dignissim augue eget justo tristique, in imperdiet augue suscipit. Nulla eget velit et nisi luctus lacinia. Nulla eleifend tortor ac velit luctus dignissim. In hac habitasse platea dictumst. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Fusce mattis interdum dolor vitae pharetra. Vestibulum sed venenatis purus, at scelerisque magna. Integer ut diam ornare, vestibulum erat vel, cursus est. Nam a ullamcorper justo. Praesent finibus volutpat convallis.

Mauris urna urna, iaculis ullamcorper sem quis, dapibus tristique augue. Praesent semper elit a odio varius consectetur. Aenean facilisis felis sed nulla semper maximus. Maecenas eu ornare sem, nec sagittis libero. Duis quis quam odio. Suspendisse consequat sed nulla at pretium. Maecenas venenatis tortor maximus mi facilisis posuere. Praesent vulputate placerat nunc. Sed ac ligula quis risus efficitur fringilla. Aliquam feugiat eu est in pulvinar. Nulla nisl neque, feugiat et tellus eu, bibendum dignissim ex. Nullam nec gravida elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Pellentesque sed accumsan massa. Pellentesque in purus lacus. Integer tempus urna nec nisi viverra, at feugiat arcu euismod.', 'TEST', '', 'inherit', 'open', 'open', '', '63-revision-v1', '', '', '2014-10-02 22:21:12', '2014-10-03 04:21:12', '', 63, 'http://localhost:8888/?p=64', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (65, 1, '2014-10-03 07:56:15', '2014-10-03 13:56:15', '', 'Auto Draft', '', 'trash', 'open', 'open', '', 'auto-draft', '', '', '2014-10-03 07:56:31', '2014-10-03 13:56:31', '', 0, 'http://localhost:8888/?page_id=65', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (66, 1, '2014-10-03 07:56:31', '2014-10-03 13:56:31', '', 'Auto Draft', '', 'inherit', 'open', 'open', '', '65-revision-v1', '', '', '2014-10-03 07:56:31', '2014-10-03 13:56:31', '', 65, 'http://localhost:8888/?p=66', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (67, 1, '2014-10-03 08:03:01', '2014-10-03 14:03:01', '', 'TEST', '', 'trash', 'open', 'open', '', 'test', '', '', '2014-10-03 08:03:21', '2014-10-03 14:03:21', '', 0, 'http://localhost:8888/?page_id=67', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (68, 1, '2014-10-03 08:03:21', '2014-10-03 14:03:21', '', 'TEST', '', 'inherit', 'open', 'open', '', '67-revision-v1', '', '', '2014-10-03 08:03:21', '2014-10-03 14:03:21', '', 67, 'http://localhost:8888/?p=68', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (69, 1, '2014-10-03 08:04:22', '2014-10-03 14:04:22', '', 'Introduction', '', 'trash', 'open', 'open', '', 'introduction', '', '', '2014-10-03 09:29:11', '2014-10-03 15:29:11', '', 0, 'http://localhost:8888/?p=69', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (70, 1, '2014-10-03 08:04:22', '2014-10-03 14:04:22', '', 'Introduction', '', 'inherit', 'open', 'open', '', '69-revision-v1', '', '', '2014-10-03 08:04:22', '2014-10-03 14:04:22', '', 69, 'http://localhost:8888/?p=70', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (71, 1, '2014-10-03 09:42:50', '2014-10-03 15:42:50', '', 'TEST', '', 'trash', 'open', 'open', '', 'test-2', '', '', '2014-10-03 09:52:32', '2014-10-03 15:52:32', '', 13, 'http://localhost:8888/?page_id=71', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (72, 1, '2014-10-03 09:42:45', '2014-10-03 15:42:45', '', 'NorthStar_Lights1', '', 'inherit', 'open', 'open', '', 'northstar_lights1', '', '', '2014-10-03 09:42:45', '2014-10-03 15:42:45', '', 71, 'http://localhost:8888/wp-content/uploads/2014/10/NorthStar_Lights1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (73, 1, '2014-10-03 09:42:50', '2014-10-03 15:42:50', '', 'TEST', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2014-10-03 09:42:50', '2014-10-03 15:42:50', '', 71, 'http://localhost:8888/?p=73', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (74, 1, '2014-10-03 09:58:19', '2014-10-03 15:58:19', '', 'NorthStar_Lights2', '', 'inherit', 'open', 'open', '', 'northstar_lights2', '', '', '2014-10-03 09:58:19', '2014-10-03 15:58:19', '', 13, 'http://localhost:8888/wp-content/uploads/2014/09/NorthStar_Lights2.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (75, 1, '2014-10-03 09:59:42', '2014-10-03 15:59:42', '', 'NorthStar_Lights3', '', 'inherit', 'open', 'open', '', 'northstar_lights3', '', '', '2014-10-03 09:59:42', '2014-10-03 15:59:42', '', 13, 'http://localhost:8888/wp-content/uploads/2014/09/NorthStar_Lights3.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (76, 1, '2014-10-03 10:02:36', '2014-10-03 16:02:36', '', 'NorthStar_Lights4', '', 'inherit', 'open', 'open', '', 'northstar_lights4', '', '', '2014-10-03 10:02:36', '2014-10-03 16:02:36', '', 13, 'http://localhost:8888/wp-content/uploads/2014/09/NorthStar_Lights4.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (78, 1, '2014-10-03 10:05:36', '2014-10-03 16:05:36', '', 'NorthStar_Lights5', '', 'inherit', 'open', 'open', '', 'northstar_lights5', '', '', '2014-10-03 10:05:36', '2014-10-03 16:05:36', '', 13, 'http://localhost:8888/wp-content/uploads/2014/09/NorthStar_Lights5.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (79, 1, '2014-10-03 10:14:34', '2014-10-03 16:14:34', '[contact-form-7 id="80" title="Contact form 1"]', 'Get in touch with us', '', 'publish', 'open', 'open', '', 'contact', '', '', '2014-10-03 12:04:00', '2014-10-03 18:04:00', '', 0, 'http://localhost:8888/?page_id=79', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (80, 1, '2014-10-03 10:13:14', '2014-10-03 16:13:14', '<p>
    [text* your-name class:contact-input placeholder "Name"] </p>

<p>
    [email* your-email class:contact-input placeholder "Email"] </p>

<p>
    [text* your-subject class:contact-input placeholder "Subject"] </p>

<p>
    [textarea* your-message class:contact-input placeholder "Message"] </p>

<button class="alternate-button wpcf7-form-control wpcf7-submit" type="submit">send</button>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on North Star Counselling (http://localhost:8888)
cheryl@localhost:8888


1


[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on North Star Counselling (http://localhost:8888)
[your-email]




Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Number format seems invalid.
This number is too small.
This number is too large.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.
Your answer is not correct.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.', 'Contact form 1', '', 'publish', 'open', 'open', '', 'contact-form-1', '', '', '2014-10-07 12:39:33', '2014-10-07 18:39:33', '', 0, 'http://localhost:8888/?post_type=wpcf7_contact_form&#038;p=80', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (81, 1, '2014-10-03 10:14:34', '2014-10-03 16:14:34', '[contact-form-7 id="80" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '79-revision-v1', '', '', '2014-10-03 10:14:34', '2014-10-03 16:14:34', '', 79, 'http://localhost:8888/?p=81', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (82, 1, '2014-10-03 12:03:33', '2014-10-03 18:03:33', '[contact-form-7 id="80" title="Contact form 1"]', 'Get in touch with us', '', 'inherit', 'open', 'open', '', '79-revision-v1', '', '', '2014-10-03 12:03:33', '2014-10-03 18:03:33', '', 79, 'http://localhost:8888/?p=82', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (83, 1, '2014-10-04 11:26:23', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-04 11:26:23', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=83', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (84, 1, '2014-10-05 13:04:05', '2014-10-05 19:04:05', '<div class="personal-intro">

Welcome to North Star
<span class="large">I\'m Cheryl McDougall.</span>
MSW RSW
</p>
</div>

    <div class="starting-questions">
      <p>
        Before we go any further,
        <span class="large">let me put your mind at rest by answering your three most important questions.</span>
      </p>

</div>', 'Home Page', '', 'inherit', 'open', 'open', '', '13-autosave-v1', '', '', '2014-10-05 13:04:05', '2014-10-05 19:04:05', '', 13, 'http://localhost:8888/13-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (85, 1, '2014-10-05 13:04:45', '2014-10-05 19:04:45', '<div class="personal-intro">
Welcome to North Star
<span class="large">I\'m Cheryl McDougall.</span>
MSW RSW
</p>
</div>

<div class="starting-questions">
Before we go any further,
<span class="large">let me put your mind at rest by answering your three most important questions.</span>
</div>', 'Home Page', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-05 13:04:45', '2014-10-05 19:04:45', '', 13, 'http://localhost:8888/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (86, 1, '2014-10-05 13:13:22', '2014-10-05 19:13:22', '<div class="personal-intro">
<p>Welcome to North Star
<span class="large">I\'m Cheryl McDougall.</span>
MSW RSW
</p>
</div>

<div class="starting-questions">
Before we go any further,
<span class="large">let me put your mind at rest by answering your three most important questions.</span>
</div>', 'Home Page', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-05 13:13:22', '2014-10-05 19:13:22', '', 13, 'http://localhost:8888/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (87, 1, '2014-10-05 13:13:55', '2014-10-05 19:13:55', '<div class="personal-intro">
<p>Welcome to North Star<span class="large">I\'m Cheryl McDougall.</span>MSW RSW</p>
</div>

<div class="starting-questions">
Before we go any further,
<span class="large">let me put your mind at rest by answering your three most important questions.</span>
</div>', 'Home Page', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-05 13:13:55', '2014-10-05 19:13:55', '', 13, 'http://localhost:8888/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (88, 1, '2014-10-05 13:15:03', '2014-10-05 19:15:03', '<div class="personal-intro">

Welcome to North Star<span class="large">I\'m Cheryl McDougall.</span>
MSW RSW

</div>
<div class="starting-questions">Before we go any further,
<span class="large">let me put your mind at rest by answering your three most important questions.</span></div>', 'Home Page', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-05 13:15:03', '2014-10-05 19:15:03', '', 13, 'http://localhost:8888/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (89, 1, '2014-10-05 13:15:32', '2014-10-05 19:15:32', '<div class="personal-intro">
<p>
Welcome to North Star<span class="large">I\'m Cheryl McDougall.</span>
MSW RSW</p>

</div>
<div class="starting-questions">Before we go any further,
<span class="large">let me put your mind at rest by answering your three most important questions.</span></div>', 'Home Page', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-05 13:15:32', '2014-10-05 19:15:32', '', 13, 'http://localhost:8888/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (90, 1, '2014-10-05 13:15:50', '2014-10-05 19:15:50', '<div class="personal-intro">
<p>
Welcome to North Star
<span class="large">I\'m Cheryl McDougall.</span>
MSW RSW</p>

</div>
<div class="starting-questions">Before we go any further,
<span class="large">let me put your mind at rest by answering your three most important questions.</span></div>', 'Home Page', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-05 13:15:50', '2014-10-05 19:15:50', '', 13, 'http://localhost:8888/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2014-10-05 13:16:47', '2014-10-05 19:16:47', '<div class="personal-intro">
<p>Welcome to North Star
<span class="large">I\'m Cheryl McDougall.</span>
MSW RSW</p>

</div>
<div class="starting-questions">
<p>Before we go any further,
<span class="large">let me put your mind at rest by answering your three most important questions.</span></p>
</div>', 'Home Page', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-05 13:16:47', '2014-10-05 19:16:47', '', 13, 'http://localhost:8888/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (92, 1, '2014-10-05 13:17:51', '2014-10-05 19:17:51', '<div class="personal-intro">

Welcome to North Star
<span class="large">I\'m Cheryl McDougall.</span>
MSW RSW

</div>
<div class="starting-questions">

Before we go any further,
<span class="large">let me put your mind at rest by answering your three most important questions.</span>

</div>', 'Home Page', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-05 13:17:51', '2014-10-05 19:17:51', '', 13, 'http://localhost:8888/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (93, 1, '2014-10-05 13:25:31', '2014-10-05 19:25:31', '<div class="personal-intro">
Welcome to North Star
<span class="large">I\'m Cheryl McDougall.</span>MSW RSW
</div>

<div class="starting-questions">
Before we go any further,
<span class="large">let me put your mind at rest by answering your three most important questions.</span>
</div>', 'Home Page', '', 'inherit', 'open', 'open', '', '13-revision-v1', '', '', '2014-10-05 13:25:31', '2014-10-05 19:25:31', '', 13, 'http://localhost:8888/13-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (94, 1, '2014-10-05 15:45:10', '2014-10-05 21:45:10', '<h2>Hello. I’m Cheryl, the founder and lead counsellor at North Star.</h2>
I have a Masters Degree in Social Work and I have been counselling people for over 16 years. As a social worker I have a passion for helping people through the challenges they are facing.

People, like you, who want a little assistance in finding alternative solutions in their life. But don’t know where to start. Maybe you are too remote or too busy or have been hesitant to seek guidance. That does not change the fact that everyone needs a little help to find their way.
&nbsp;
<h3>Ecounselling is the answer.</h3>
It’s easy, convenient and completely confidential.

We engage in a conversation, just as we would face-to-face, only we will be online. I introduce myself, and then you tell me a bit about yourself. You share with me your issue, and within 2 business days I respond with some ideas, thoughts and options on how you can move forward. We’ll carry on our online conversation as long as you need.
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>
<h3>Why North Star.</h3>
My mission is to guide you through difficulties. This is why I chose the name North Star. The North Star has been a guiding light for people to find their way in the world. We will be the guiding light for you! To help you find the way through the trials and tribulations of life. This is done through a goal directed collaborative approach. Personal change is constant. We will bring awareness and facilitate movement towards goals you have identified.', 'About Us', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2014-10-05 15:45:10', '2014-10-05 21:45:10', '', 19, 'http://localhost:8888/19-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (95, 1, '2014-10-05 15:45:48', '2014-10-05 21:45:48', '<h2>
	Counselling works to solve a wide range of problems. We work with individuals, couples and families to overcome a number of different issues, including:
</h2>
<ul>
	<li>Anger (non-violent)</li>
	<li>Anxiety</li>
	<li>Assertiveness</li>
	<li>Career and work related issues</li>
	<li>Conflict resolution</li>
	<li>Depression</li>
	<li>Divorce and separation</li>
	<li>Grief and loss</li>
	<li>Isolation</li>
	<li>Intimacy</li>
	<li>Marital and relationship problems</li>
	<li>Midlife transition</li>
	<li>Personal growth</li>
	<li>Self-esteem</li>
	<li>Sexuality – LBGTQ</li>
	<li>Stress management</li>
	<li>Relationships/dating</li>
</ul>
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'How we can help', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2014-10-05 15:45:48', '2014-10-05 21:45:48', '', 28, 'http://localhost:8888/28-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (96, 1, '2014-10-05 15:46:57', '2014-10-05 21:46:57', '<h2>
	Professional Counselling
	Completely Confidential
	Anonymous
	and Secure.
</h2>
<p>
	It is simply taking therapy online to overcome issues like distance and accessability. Also known as e-therapy, e-counseling, tele-therapy or cyber-counseling, it emerged on the internet in about 1982.
</p>
<p>
	Distance counselling has been used as far back as the 1920s when Sigmund Freud utilized letters to communicate with his clients. Today online counselling is quite widespread.
</p>
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'What is online counselling', '', 'inherit', 'open', 'open', '', '31-revision-v1', '', '', '2014-10-05 15:46:57', '2014-10-05 21:46:57', '', 31, 'http://localhost:8888/31-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (97, 1, '2014-10-05 15:47:27', '2014-10-05 21:47:27', '<h2>
	Confidential
	Easy
	Convenient
	and Successful.
</h2>
<p>
	Just as we would face-to-face, we engage in a discussion, only we’ll be online. I introduce myself, then you tell me a bit about yourself and your issue, and within 2 business days I respond with some ideas, thoughts and options/suggestions on how you can choose move forward.
</p>
<p>
	Just like emailing a friend back and forth.
</p>
<p>
	We’ll carry on our online discussion as long as needed.
</p>
<p>
	What if you develop a crisis and need immediate assistance
	while working with me? Send me an email marked urgent. I
	check my emails several times a day. However, any serious
	life threatening thoughts to yourself or others should be
	addressed immediately by calling your local crisis line or 9-1-1.
</p>
<a href="http://northstarcounselling.privacemail.com/">
	<button class="alternate-button">Let\'s begin...</button>
</a>', 'How it works', '', 'inherit', 'open', 'open', '', '34-revision-v1', '', '', '2014-10-05 15:47:27', '2014-10-05 21:47:27', '', 34, 'http://localhost:8888/34-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (98, 1, '2014-10-05 15:47:59', '2014-10-05 21:47:59', '<h2>
	Easy, convenient, and for a
	modest fee.
</h2>
<p>
	You’ll find my fees are relatively low for one simple reason: As an on line counsellor, I work out of my home, so I do not need to cover the expensive overhead of an office.
</p>
<p>
	This means you can get effective counselling on your terms.
</p>
<p>
	The first half hour is free. This is a chance to get to know one another and become familiar with your issue.
</p>
<p>
	After that, the fee is $90.00 per hour. Payment is made through a Pay Pal account. If you don’t have one yet, it is very easy to set up.
</p>
<a href="http://northstarcounselling.privacemail.com/">
	<button class="alternate-button">Let\'s begin...</button>
</a>', 'Fees', '', 'inherit', 'open', 'open', '', '36-revision-v1', '', '', '2014-10-05 15:47:59', '2014-10-05 21:47:59', '', 36, 'http://localhost:8888/36-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (99, 2, '2014-10-05 17:45:18', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-10-05 17:45:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=99', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (100, 2, '2014-10-05 17:45:58', '2014-10-05 23:45:58', '<h2>Hello. I’m Cheryl, the founder and lead counsellor at North Star.</h2>
I have a Masters Degree in Social Work and I have been counselling people for over 16 years. As a social worker I have a passion for helping people through the challenges they are facing.

People, like you, who want a little assistance in finding alternative solutions in their life. But don’t know where to start. Maybe you are too remote or too busy or have been hesitant to seek guidance. That does not change the fact that everyone needs a little help to find their way.
<h3>Ecounselling is the answer.</h3>
It’s easy, convenient and completely confidential.

We engage in a conversation, just as we would face-to-face, only we will be online. I introduce myself, and then you tell me a bit about yourself. You share with me your issue, and within 2 business days I respond with some ideas, thoughts and options on how you can move forward. We’ll carry on our online conversation as long as you need.
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>
<h3>Why North Star.</h3>
My mission is to guide you through difficulties. This is why I chose the name North Star. The North Star has been a guiding light for people to find their way in the world. We will be the guiding light for you! To help you find the way through the trials and tribulations of life. This is done through a goal directed collaborative approach. Personal change is constant. We will bring awareness and facilitate movement towards goals you have identified.', 'About Us', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2014-10-05 17:45:58', '2014-10-05 23:45:58', '', 19, 'http://localhost:8888/19-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (102, 1, '2014-10-07 16:38:40', '2014-10-07 22:38:40', '<h2>
	Professional Counselling
	Completely Confidential
	Anonymous
	and Secure.
</h2>
<p>
	It is simply taking therapy online to overcome issues like distance and accessability. Also known as e-therapy, <span style="whites">e-counseling,</span> tele-therapy or cyber-counseling, it emerged on the internet in about 1982.
</p>
<p>
	Distance counselling has been used as far back as the 1920s when Sigmund Freud utilized letters to communicate with his clients. Today online counselling is quite widespread.
</p>
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'What is online counselling', '', 'inherit', 'open', 'open', '', '31-autosave-v1', '', '', '2014-10-07 16:38:40', '2014-10-07 22:38:40', '', 31, 'http://localhost:8888/31-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (103, 1, '2014-10-07 16:21:54', '2014-10-07 22:21:54', '<h2>
	Professional Counselling
	Completely Confidential
	Anonymous
	and Secure.
</h2>
<p>
	It is simply taking therapy online to overcome issues like distance and accessability. Also known as e-therapy, <span style="display: inline-block">e-counseling,</span> tele-therapy or cyber-counseling, it emerged on the internet in about 1982.
</p>
<p>
	Distance counselling has been used as far back as the 1920s when Sigmund Freud utilized letters to communicate with his clients. Today online counselling is quite widespread.
</p>
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'What is online counselling', '', 'inherit', 'open', 'open', '', '31-revision-v1', '', '', '2014-10-07 16:21:54', '2014-10-07 22:21:54', '', 31, 'http://localhost:8888/31-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (104, 1, '2014-10-07 16:23:35', '2014-10-07 22:23:35', '<h2>
	Professional Counselling
	Completely Confidential
	Anonymous
	and Secure.
</h2>
<p>
	It is simply taking therapy online to overcome issues like distance and accessability. Also known as e-therapy, e-counseling, tele-therapy or cyber-counseling, it emerged on the internet in about 1982.
</p>
<p>
	Distance counselling has been used as far back as the 1920s when Sigmund Freud utilized letters to communicate with his clients. Today online counselling is quite widespread.
</p>
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'What is online counselling', '', 'inherit', 'open', 'open', '', '31-revision-v1', '', '', '2014-10-07 16:23:35', '2014-10-07 22:23:35', '', 31, 'http://localhost:8888/31-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (105, 1, '2014-10-07 16:37:36', '2014-10-07 22:37:36', '<h2>
	Professional Counselling
	Completely Confidential
	Anonymous
	and Secure.
</h2>
<p>
	It is simply taking therapy online to overcome issues like distance and accessability. Also known as e-therapy, <span style="whitespace: none;">e-counseling,</span> tele-therapy or cyber-counseling, it emerged on the internet in about 1982.
</p>
<p>
	Distance counselling has been used as far back as the 1920s when Sigmund Freud utilized letters to communicate with his clients. Today online counselling is quite widespread.
</p>
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'What is online counselling', '', 'inherit', 'open', 'open', '', '31-revision-v1', '', '', '2014-10-07 16:37:36', '2014-10-07 22:37:36', '', 31, 'http://localhost:8888/31-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (106, 1, '2014-10-07 16:38:49', '2014-10-07 22:38:49', '<h2>
	Professional Counselling
	Completely Confidential
	Anonymous
	and Secure.
</h2>
<p>
	It is simply taking therapy online to overcome issues like distance and accessability. Also known as e-therapy, <span style="white-space:none;">e-counseling,</span> tele-therapy or cyber-counseling, it emerged on the internet in about 1982.
</p>
<p>
	Distance counselling has been used as far back as the 1920s when Sigmund Freud utilized letters to communicate with his clients. Today online counselling is quite widespread.
</p>
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'What is online counselling', '', 'inherit', 'open', 'open', '', '31-revision-v1', '', '', '2014-10-07 16:38:49', '2014-10-07 22:38:49', '', 31, 'http://localhost:8888/31-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (107, 1, '2014-10-07 16:39:37', '2014-10-07 22:39:37', '<h2>
	Professional Counselling
	Completely Confidential
	Anonymous
	and Secure.
</h2>
<p>
	It is simply taking therapy online to overcome issues like distance and accessability. Also known as e-therapy, <span style="white-space:no-wrap;">e-counseling,</span> tele-therapy or cyber-counseling, it emerged on the internet in about 1982.
</p>
<p>
	Distance counselling has been used as far back as the 1920s when Sigmund Freud utilized letters to communicate with his clients. Today online counselling is quite widespread.
</p>
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'What is online counselling', '', 'inherit', 'open', 'open', '', '31-revision-v1', '', '', '2014-10-07 16:39:37', '2014-10-07 22:39:37', '', 31, 'http://localhost:8888/31-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (108, 1, '2014-10-07 16:43:07', '2014-10-07 22:43:07', '<h2>
	Professional Counselling
	Completely Confidential
	Anonymous
	and Secure.
</h2>
<p>
	It is simply taking therapy online to overcome issues like distance and accessability. Also known as e-therapy, <span style="white-space:nowrap;">e-counseling,</span> tele-therapy or cyber-counseling, it emerged on the internet in about 1982.
</p>
<p>
	Distance counselling has been used as far back as the 1920s when Sigmund Freud utilized letters to communicate with his clients. Today online counselling is quite widespread.
</p>
<a href="http://northstarcounselling.privacemail.com/">
<button class="alternate-button">Let\'s begin...</button>
</a>', 'What is online counselling', '', 'inherit', 'open', 'open', '', '31-revision-v1', '', '', '2014-10-07 16:43:07', '2014-10-07 22:43:07', '', 31, 'http://localhost:8888/31-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 8. October 2014 20:02 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (9 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (16, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (38, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (47, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (49, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (51, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (69, 4, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 8. October 2014 20:02 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (4 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'post_format', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'category', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'category', '', 0, 0) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 8. October 2014 20:02 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (4 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'post-format-image', 'post-format-image', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'homepage', 'homepage', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'introduction', 'introduction', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 8. October 2014 20:02 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (39 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'nickname', 'justin_t_brown') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'session_tokens', 'a:3:{s:64:"99bd6e0e5dc852d06a6aabfb6028d83a71aa6d54eb8113d79eb0b51a3ad7dc34";i:1412724197;s:64:"37419625895ee94e2eb208599202092e1321c5f9817456bd0c39982fa3abe602";i:1412724202;s:64:"97bb73491afaa1f6f68febeb8083acf9e6315207a01de2afd9da1427fa5b7805";i:1412893010;}') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'wp_dashboard_quick_press_last_post_id', '83') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'wp_user-settings', 'libraryContent=browse&editor=html&posts_list_mode=list') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'wp_user-settings-time', '1412212739') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'closedpostboxes_page', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (21, 1, 'metaboxhidden_page', 'a:4:{i:0;s:16:"commentstatusdiv";i:1;s:11:"commentsdiv";i:2;s:7:"slugdiv";i:3;s:9:"authordiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (22, 1, 'closedpostboxes_post', 'a:1:{i:0;s:12:"revisionsdiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (23, 1, 'metaboxhidden_post', 'a:5:{i:0;s:11:"postexcerpt";i:1;s:13:"trackbacksdiv";i:2;s:16:"commentstatusdiv";i:3;s:11:"commentsdiv";i:4;s:9:"authordiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (24, 1, 'meta-box-order_post', 'a:3:{s:4:"side";s:61:"submitdiv,formatdiv,categorydiv,tagsdiv-post_tag,postimagediv";s:6:"normal";s:96:"postcustom,revisionsdiv,postexcerpt,trackbacksdiv,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}') ; 
INSERT INTO `wp_usermeta` VALUES (25, 1, 'screen_layout_post', '2') ; 
INSERT INTO `wp_usermeta` VALUES (26, 2, 'nickname', 'admin') ; 
INSERT INTO `wp_usermeta` VALUES (27, 2, 'first_name', 'Administrator') ; 
INSERT INTO `wp_usermeta` VALUES (28, 2, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (29, 2, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (30, 2, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (31, 2, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (32, 2, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (33, 2, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (34, 2, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (35, 2, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (36, 2, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (37, 2, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wp_usermeta` VALUES (38, 2, 'session_tokens', 'a:2:{s:64:"fecc1806b2d7782b7f2f19e789873d60dae8a373c83a6ab30c85b719416ebab1";i:1412725517;s:64:"8e6d9013dc4f8f53a9822b2781a32a58f23a63b2c5ea12b305088f7ad85821fb";i:1412785077;}') ; 
INSERT INTO `wp_usermeta` VALUES (39, 2, 'wp_dashboard_quick_press_last_post_id', '99') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 8. October 2014 20:02 UTC
# Hostname: localhost
# Database: `wordpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (2 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'justin_t_brown', '$P$BBRDIs2JU6/OIs07nOHUkvS7e9z9hY.', 'justin_t_brown', 'brown.jt@gmail.com', '', '2014-09-25 20:16:33', '', 0, 'justin_t_brown') ; 
INSERT INTO `wp_users` VALUES (2, 'admin', '$P$BYCyApVVwJinAZI0n8fv8qA/4WGWeN/', 'admin', 'jb@justinbrown.io', '', '2014-10-05 23:30:24', '', 0, 'Administrator') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

